/* Compatibility build: legacy offline cache retired. */
self.addEventListener("install", function(){self.skipWaiting();});
self.addEventListener("activate", function(event){event.waitUntil(self.clients.claim());});
