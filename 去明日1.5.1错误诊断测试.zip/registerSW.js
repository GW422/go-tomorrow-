/* Compatibility build: service worker disabled to prevent stale script/data mixtures. Saves are unchanged. */
