from pathlib import Path
p=Path('src/vendor/mymy/Apps.tsx');s=p.read_text()
s='import {day2Scenes} from "../../day2Continuation";\n'+s
s=s.replace('    effectiveVisibleCount = day2Start >= 0 ? day2Start + Math.max(0, day2Visible) : visibleCount < 0 ? firstScriptedIndex : visibleCount,','''    contStage = Number(p.ui?.gtContStage ?? -1),
    contVisible = Number(p.ui?.gtContVisible || 0),
    contScene = contStage >= 0 ? day2Scenes[contStage] : undefined,
    jaeminContStart = allJaeminMessages.findIndex(m=>m.id===`gt-cont-${contStage}-0`),
    jaeminOldEnd = allJaeminMessages.findIndex(m=>m.id.startsWith('gt-cont-')),
    effectiveVisibleCount = jaeminContStart>=0 ? jaeminContStart+contVisible : jaeminOldEnd>=0 ? allJaeminMessages.length : day2Start >= 0 ? day2Start + Math.max(0, day2Visible) : visibleCount < 0 ? firstScriptedIndex : visibleCount,''')
s=s.replace('    activeVisibleCount = p.thread === "해찬형" ? haechanEffectiveCount : p.thread === "재민형" ? effectiveVisibleCount : (scriptedMode ? (extraCursors[p.thread] ?? extraStart) : sourceMessages.length),','''    currentContStart = sourceMessages.findIndex(m=>m.id===`gt-cont-${contStage}-0`),
    previousContEnd = sourceMessages.findIndex(m=>m.id.startsWith('gt-cont-')),
    activeVisibleCount = currentContStart>=0 ? currentContStart+contVisible : previousContEnd>=0 ? sourceMessages.length : p.thread === "해찬형" ? haechanEffectiveCount : p.thread === "재민형" ? effectiveVisibleCount : (scriptedMode ? (extraCursors[p.thread] ?? extraStart) : sourceMessages.length),''')
s=s.replace('    if (p.thread === "해찬형") {\n      if (!haechanStartTime)', '''    if (currentContStart>=0 && contScene?.thread===p.thread) {
      p.onUi?.('gtContVisible',contVisible+1);
    } else if (p.thread === "해찬형") {
      if (!haechanStartTime)''')
s=s.replace('    if (p.thread === "재민형") {\n      if (day2Start>=0)', '    if (p.thread === "재민형") {\n      if (day2Start>=0)')
s=s.replace('      if (day2Start>=0) { if(Number(p.ui?.gtDay2ReadCount||0)!==day2Visible)', '''      if (day2Start>=0) { if(Number(p.ui?.gtDay2ReadCount||0)!==day2Visible)''')
s=s.replace('g.title === "재민형" ? allJaeminMessages.slice(0, effectiveVisibleCount) : g.title === "해찬형"', 'g.title === "재민형" ? allJaeminMessages.slice(0, effectiveVisibleCount) : g.title === "해찬형"')
# Ensure other threads with new messages are visible, without exposing the current scene's future lines.
s=s.replace('const displayedItems = g.title === "재민형" ? visibleJaemin : g.title === "해찬형" ? g.items.slice(0, hcVisible) : extraStartForGroup >= 0 ? g.items.slice(0, extraVisibleForGroup) : g.items;', '''const stageStartForGroup=g.items.findIndex(m=>m.id===`gt-cont-${contStage}-0`);
                const anyContForGroup=g.items.some(m=>m.id.startsWith('gt-cont-'));
                const displayedItems = g.title === '재민형' ? visibleJaemin : stageStartForGroup>=0 ? g.items.slice(0,stageStartForGroup+contVisible) : anyContForGroup ? g.items : g.title === '해찬형' ? g.items.slice(0,hcVisible) : extraStartForGroup >= 0 ? g.items.slice(0, extraVisibleForGroup) : g.items;''')
s=s.replace('const visible = g.title === "재민형" ? allJaeminMessages.slice(0, effectiveVisibleCount) : g.title === "해찬형"', '''const currentStageStart=g.items.findIndex(m=>m.id===`gt-cont-${contStage}-0`);
                const visible = g.title === "재민형" ? allJaeminMessages.slice(0, effectiveVisibleCount) : currentStageStart>=0 ? g.items.slice(0,currentStageStart+contVisible) : g.items.some(m=>m.id.startsWith('gt-cont-')) ? g.items : g.title === "해찬형"''')
s=s.replace('const unreadCount = g.title === "재민형" ?', '''const contPending = displayedItems.filter(m=>m.id.startsWith('gt-cont-') && !m.outgoing && !p.ui?.[`gtContRead_${g.title}`]).length;
                const unreadCount = g.title === "재민형" ?''')
# Don't invent a second unread system; use existing read cursor for continuation, and mark read on entering.
s=s.replace('const unread = tab !== "好友" && unreadCount > 0 ? String(unreadCount) : undefined;', '''const finalUnread = anyContForGroup ? displayedItems.slice(readCursors[g.title]??0).filter(m=>m.id.startsWith('gt-cont-')&&!m.outgoing).length + (g.title==='재민형'?unreadCount:0) : unreadCount;
                const unread = tab !== "好友" && finalUnread > 0 ? String(finalUnread) : undefined;''')
s=s.replace('setReadCursors({...readCursors, [g.title]: g.title === "해찬형" ? hcVisible : displayedItems.length});','setReadCursors({...readCursors, [g.title]: g.title === "해찬형" && !anyContForGroup ? hcVisible : displayedItems.length});')
p.write_text(s)
