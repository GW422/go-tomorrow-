import { readFile, writeFile, mkdir, rm } from "node:fs/promises";
import { dirname, join } from "node:path";
import { createHash } from "node:crypto";
import { createServer } from "vite";
const [
  mode = "validate",
  file = process.env.STORY_FILE || "stories/template/story.json",
] = process.argv.slice(2);
const server = await createServer({
  configFile: false,
  optimizeDeps: { noDiscovery: true, entries: [] },
  server: { middlewareMode: true },
  appType: "custom",
});
let source = "",
  json = "",
  lineOffset = 0;
// Map JSON paths to source positions without executing any author code.
function positions(text) {
  let i = 0;
  const out = new Map();
  const ws = () => {
    while (/\s/.test(text[i] || "") && i < text.length) i++;
  };
  const str = () => {
    const a = i++;
    while (i < text.length) {
      if (text[i++] === '"') break;
      if (text[i - 1] === "\\") i++;
    }
    return JSON.parse(text.slice(a, i));
  };
  function value(p) {
    ws();
    out.set(p, i);
    if (text[i] === "{") {
      i++;
      ws();
      while (text[i] !== "}") {
        const key = str();
        ws();
        i++;
        value(p ? p + "." + key : key);
        ws();
        if (text[i] !== ",") break;
        i++;
        ws();
      }
      i++;
    } else if (text[i] === "[") {
      i++;
      ws();
      let n = 0;
      while (text[i] !== "]") {
        value(p + "." + n++);
        ws();
        if (text[i] !== ",") break;
        i++;
        ws();
      }
      i++;
    } else if (text[i] === '"') str();
    else {
      while (i < text.length && !/[\s,}\]]/.test(text[i])) i++;
    }
  }
  value("");
  return out;
}
try {
  source = await readFile(file, "utf8");
  if (Buffer.byteLength(source) > 100 * 1024 * 1024)
    throw Error("脚本不能超过100MB");
  json = source;
  if (/\.md$/i.test(file)) {
    const match = /```json\s*\n([\s\S]*?)```/.exec(source);
    if (!match)
      throw Error(
        "Markdown 需要一个 ```json 剧情数据块；自然语言由创作 AI 转换，不在运行时调用 AI",
      );
    json = match[1];
    lineOffset =
      source.slice(0, match.index + match[0].indexOf(match[1])).split("\n")
        .length - 1;
  }
  const raw = JSON.parse(json);
  // Restore exact original Base64 strings before story validation/compilation.
  // Source-only deduplication: public work.json, app chunks and all UI consumers
  // retain precisely the same data shape and image strings as before.
  const dictionaryPath = join(dirname(file), "image-dictionary.json");
  let imageDictionary;
  try {
    imageDictionary = JSON.parse(await readFile(dictionaryPath, "utf8"));
  } catch (error) {
    if (error?.code !== "ENOENT") throw error;
  }
  if (imageDictionary) {
    if (imageDictionary.format !== "gt-base64-dictionary-v1" || !imageDictionary.images || typeof imageDictionary.images !== "object")
      throw Error("图片字典版本或格式错误");
    const imageMap = imageDictionary.images;
    const restore = (value) => {
      if (typeof value === "string" && /^__GT_BASE64_IMAGE_\d{4}__$/.test(value)) {
        if (!Object.prototype.hasOwnProperty.call(imageMap, value) || !String(imageMap[value]).startsWith("data:image/"))
          throw Error(`图片字典缺失或无效: ${value}`);
        return imageMap[value];
      }
      if (Array.isArray(value)) return value.map(restore);
      if (value && typeof value === "object") {
        for (const key of Object.keys(value)) value[key] = restore(value[key]);
      }
      return value;
    };
    restore(raw);
  }

  const { compileStory, storySchema } = await server.ssrLoadModule(
    "/src/story-engine/compiler.ts",
  );
  const { story, work } = compileStory(raw);
  if (mode === "test" || mode === "build") {
    const { testStory } = await server.ssrLoadModule(
      "/src/story-engine/testStory.ts",
    );
    const errors = testStory(story, work);
    if (errors.length) throw Error(errors.join("\n"));
  }
  if (mode === "schema") {
    const { z } = await import("zod");
    await mkdir("schemas", { recursive: true });
    await writeFile(
      "schemas/story.schema.json",
      JSON.stringify(z.toJSONSchema(storySchema), null, 2) + "\n",
    );
  } else if (mode === "build") {
    await mkdir("public", { recursive: true });
    // Runtime uses gt-boot.json + gt-chunks; avoid duplicating the entire
    // restored Base64 story in the deployed assets.
    await rm("public/work.json", { force: true });
    // Build a small playable core; large independent apps are requested on open.
    // Never change the underlying image strings; the authoring source stays intact.
    const deferredApps = ["instagram", "photos", "twitter", "x"];
    const boot = { ...work, data: { ...work.data } };
    const lazyManifest = { formatVersion: 1, apps: {} };
    await rm("public/gt-chunks", { recursive: true, force: true });
    await mkdir("public/gt-chunks", { recursive: true });
    for (const app of deferredApps) {
      if (!work.data[app]?.length) continue;
      const items = work.data[app];
      const chunks = [];
      // Bound individual downloads and JSON.parse work: max 3 records per chunk.
      for (let offset = 0; offset < items.length; offset += 3) {
        const payload = JSON.stringify(items.slice(offset, offset + 3));
        // Content-addressed filenames allow unchanged chunks to remain cached
        // across UI-only releases and unrelated story edits.
        const digest = createHash("sha256").update(payload).digest("hex").slice(0, 16);
        const filename = `${app}-${String(offset / 3).padStart(3, "0")}-${digest}.json`;
        await writeFile(`public/gt-chunks/${filename}`, payload);
        chunks.push(filename);
      }
      lazyManifest.apps[app] = chunks;
      delete boot.data[app];
    }
    await writeFile("public/gt-boot.json", JSON.stringify(boot));
    await writeFile("public/gt-chunks/manifest.json", JSON.stringify(lazyManifest));
    const blank = compileStory(
      JSON.parse(await readFile("stories/blank/story.json", "utf8")),
    ).work;
    await writeFile(
      "public/blank-work.json",
      JSON.stringify(blank, null, 2) + "\n",
    );
    {
      const preview = compileStory(
        JSON.parse(await readFile("stories/test-preview/story.json", "utf8")),
      ).work;
      await writeFile(
        "public/test-work.json",
        JSON.stringify(preview, null, 2) + "\n",
      );
    }
  } else if (!["validate", "test"].includes(mode))
    throw Error("未知命令 " + mode);
  console.log(
    `${file}: ${mode} 通过 (${work.apps.filter((a) => a.installed).length} Apps, ${Object.values(work.data).flat().length} records, ${work.nodes.length} events, ${story.tests.length} paths)`,
  );
} catch (e) {
  let map = new Map();
  try {
    map = positions(json);
  } catch {}
  const issues = e.issues?.map((i) => ({
    field: i.path.join("."),
    message: i.message,
  })) || [{ field: e.field || "", message: e.message }];
  for (const issue of issues) {
    let field = issue.field;
    while (!map.has(field) && field.includes("."))
      field = field.slice(0, field.lastIndexOf("."));
    const syntaxPosition = /position (\d+)/.exec(issue.message);
    const pos = syntaxPosition
      ? Number(syntaxPosition[1])
      : map.get(field) || 0;
    const line = json.slice(0, pos).split("\n").length + lineOffset;
    console.error(`${file}:${line} [${issue.field || "$"}] ${issue.message}`);
  }
  process.exitCode = 1;
} finally {
  await server.close();
}
