import { createHash } from 'node:crypto';
import { readdir, readFile, writeFile } from 'node:fs/promises';
import { join, relative } from 'node:path';

const root = process.cwd();
const roots = ['src', 'stories', 'assets', 'public', 'scripts'];
const topFiles = ['index.html', 'player.html', 'vite.runtime.config.ts', 'package.json', 'package-lock.json', 'tsconfig.json', 'tsconfig.app.json'];
const excluded = new Set(['src/generated-build-id.ts', 'scripts/build-fingerprint.mjs']);
const files = [];
async function walk(path) {
  let entries;
  try { entries = await readdir(join(root, path), { withFileTypes: true }); } catch { return; }
  for (const entry of entries) {
    const name = join(path, entry.name).replaceAll('\\', '/');
    if (entry.isDirectory()) {
      if (!['node_modules', 'dist', '.git', '.cache'].includes(entry.name)) await walk(name);
    } else if (entry.isFile() && !excluded.has(name)) files.push(name);
  }
}
for (const dir of roots) await walk(dir);
for (const file of topFiles) { try { await readFile(join(root, file)); files.push(file); } catch {} }
files.sort();
const hash = createHash('sha256');
for (const file of files) {
  hash.update(file); hash.update('\0');
  hash.update(await readFile(join(root, file))); hash.update('\0');
}
const id = hash.digest('hex');
await writeFile(join(root, 'src/generated-build-id.ts'), `// Auto-generated: hash of shipped source, story, and asset inputs.\nexport const BUILD_FINGERPRINT = ${JSON.stringify(id)};\n`);
// Keep downloaded story cache across UI-only releases. The work compiler and
// schema are included, so schema/output-format changes still invalidate it.
const storyHash = createHash('sha256');
const storyInputs = files.filter((name) =>
  name.startsWith('stories/') || name.startsWith('src/story-engine/') ||
  ['src/schema.ts','src/registry.ts'].includes(name)
);
for(const name of storyInputs){storyHash.update(name);storyHash.update('\0');storyHash.update(await readFile(join(root,name)));storyHash.update('\0');}
const storyId=storyHash.digest('hex');
await writeFile(join(root,'src/generated-build-id.ts'), `// Auto-generated content IDs; do not edit by hand.\nexport const BUILD_FINGERPRINT = ${JSON.stringify(id)};\nexport const STORY_FINGERPRINT = ${JSON.stringify(storyId)};\n`);
console.log(`Build content fingerprint: ${id.slice(0, 16)} (${files.length} files); story ${storyId.slice(0,16)} (${storyInputs.length} inputs)`);
