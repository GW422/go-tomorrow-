from pathlib import Path
p=Path('/mnt/data/gt_fix/src/vendor/mymy/Apps.tsx')
s=p.read_text()
s=s.replace('import "./adapter.css";', 'import "./adapter.css";\nimport {PlayerPhoto, preparePlayerPhoto} from "../../socialLocal";\nimport {readEvents, scheduleEvents} from "../../socialQueue";')
s=s.replace('  const [photoChoice,setPhotoChoice]=useState("");','  const [photoChoice,setPhotoChoice]=useState("");\n  const [photoPreview,setPhotoPreview]=useState("");\n  const [photoError,setPhotoError]=useState("");\n  const [igQueueRaw,setIgQueueRaw]=useSkinState<string>(p,`gtIgQueue-${p.cycleIndex||1}`,"[]");\n  const [igCommentsRaw,setIgCommentsRaw]=useSkinState<string>(p,`gtIgThread-${p.cycleIndex||1}`,"[]");\n  type ThreadComment={id:string;postId:string;name:string;text:string;parentId?:string};\n  let igThread:ThreadComment[]=[];try{const a=JSON.parse(igCommentsRaw);if(Array.isArray(a))igThread=a;}catch{}\n  const igThreadRef=useRef(igThread);igThreadRef.current=igThread;\n  const igQueue=readEvents(igQueueRaw);\n  const igQueueRef=useRef(igQueue);igQueueRef.current=igQueue;')
start=s.index('  const publishOwn=()=>{',s.index('export function MymyInstagram'))
end=s.index('  const [searchOpen',start)
s=s[:start]+'''  const publishOwn=()=>{
    if(!photoChoice)return;
    const id=`ig-${Date.now()}`;
    const members=["jeno","haechan","chenle","renjun"].filter(()=>Math.random()<0.4);
    setPlayerPostRaw(JSON.stringify([{id,caption:newCaption,media:photoChoice,date:"刚刚",jaemin:true,members},...ownPosts].slice(0,12)));
    const events=[...scheduleEvents(id,"jaemin",1,1200),...scheduleEvents(id,"member",members.length,3200,2200),...scheduleEvents(id,"comment",4,2200,2600)];
    if(Math.random()<.7)events.push(...scheduleEvents(id,"egg-like",1,6800+members.length*2200),...scheduleEvents(id,"egg-unlike",1,8900+members.length*2200));
    setIgQueueRaw(JSON.stringify([...igQueueRef.current,...events]));
    setPostNotice("Your post was shared");
    setSelectedUser(ownProfileName);setView("feed");
    setComposing(false);setNewCaption("");setPhotoChoice("");setPhotoPreview("");
  };
  useEffect(()=>{
    const timer=window.setInterval(()=>{
      const due=igQueueRef.current.find(v=>v.due<=Date.now());
      if(!due)return;
      const next=igQueueRef.current.filter(v=>v.id!==due.id);
      igQueueRef.current=next;setIgQueueRaw(JSON.stringify(next));
      const names=["cloudy__js","moonside_07","jisungdaily","softly_park","dreamnotes_22"];
      if(due.kind==="comment"){
        if(igThreadRef.current.some(c=>c.id===due.id))return;
        const texts=["志晟啊 今天也辛苦了ㅠㅠ","好喜欢这张照片！","今天吃饭了吗？","期待下次直播ㅎㅎ","这张可以多发几张吗？"];
        const comment={id:due.id,postId:due.postId,name:names[due.index%names.length],text:texts[due.index%texts.length],parentId:due.parentId};
        igThreadRef.current=[...igThreadRef.current,comment];setIgCommentsRaw(JSON.stringify(igThreadRef.current));
        addActivity(`${comment.name} commented on your photo`,due.id);
      }else if(due.kind==="egg-like") {setEggNotice(true);addActivity("n8_3m liked your photo",due.id);}
      else if(due.kind==="egg-unlike") {setEggNotice(false);addActivity("n8_3m unliked your photo",due.id);}
      else if(due.kind==="jaemin")addActivity("na.jaemin liked your photo",due.id);
      else if(due.kind==="member")addActivity(`${["jeno","haechan","chenle","renjun"][due.index%4]} liked your photo`,due.id);
    },650);
    return ()=>window.clearInterval(timer);
  },[p.cycleIndex]);
''' +s[end:]
s=s.replace('  const addActivity=(text:string)=>{\n    const next=[{id:`a-${Date.now()}-${Math.random()}`,text,time:"刚刚"},...activityRef.current].slice(0,70);','  const addActivity=(text:string,id=`a-${Date.now()}-${Math.random()}`)=>{\n    if(activityRef.current.some(v=>v.id===id))return;\n    const next=[{id,text,time:"刚刚"},...activityRef.current].slice(0,70);')
s=s.replace('  const ownItems:Item[]=ownPosts.map((v,i)=>makeItem({id:v.id,title:"PARK JISUNG",sender:ownProfileName,body:v.caption,time:v.date,media:v.media,kind:"post",meta:{kind:"post",sortKey:String(100000+i),likes:"8421",comments:"47",displayName:"PARK JISUNG",verified:"true",postsCount:String(96+ownPosts.length),followers:"4.7M",following:"11",bio:"EZzz 😴"}}));','  const ownItems:Item[]=ownPosts.map((v,i)=>makeItem({id:v.id,title:"PARK JISUNG",sender:ownProfileName,body:v.caption,time:v.date,media:v.media,kind:"post",meta:{kind:"post",sortKey:String(100000+i),likes:String(1+v.members.length),comments:String(igThread.filter(c=>c.postId===v.id).length),displayName:"PARK JISUNG",verified:"true",postsCount:String(96+ownPosts.length),followers:"4.7M",following:"11",bio:"EZzz 😴"}}));')
s=s.replace('{image ? <img src={image} alt={alt} /> : <div className="media-placeholder" />}','{image ? <PlayerPhoto src={image} alt={alt} /> : <div className="media-placeholder" />}')
s=s.replace('<img src={url} alt={post.caption || post.profile.displayName} />','<PlayerPhoto src={url} alt={post.caption || post.profile.displayName} />')
old='''<label className="gt-ig-file-label">从相册选择图片<input type="file" accept="image/*" onChange={e=>{const file=e.target.files?.[0];if(!file)return;const reader=new FileReader();reader.onload=()=>{const img=new Image();img.onload=()=>{const c=document.createElement("canvas");const ratio=Math.min(1,650/Math.max(img.width,img.height));c.width=Math.max(1,Math.round(img.width*ratio));c.height=Math.max(1,Math.round(img.height*ratio));c.getContext("2d")?.drawImage(img,0,0,c.width,c.height);setPhotoChoice(c.toDataURL("image/jpeg",.58));};img.src=String(reader.result||"");};reader.readAsDataURL(file);}}/></label>
        {photoChoice&&<img className="gt-ig-compose-preview" src={photoChoice} alt="准备发布的照片"/>}'''
new='''<label className="gt-ig-file-label">从相册选择图片<input type="file" accept="image/*" onChange={async e=>{const file=e.target.files?.[0];if(!file)return;setPhotoError("");try{const saved=await preparePlayerPhoto(file);setPhotoChoice(saved.key);setPhotoPreview(saved.preview);}catch(error){setPhotoError(error instanceof Error?error.message:"图片保存失败");}}}/></label>
        {photoError&&<p role="alert">{photoError}</p>}
        {photoChoice&&<PlayerPhoto className="gt-ig-compose-preview" src={photoChoice} alt="准备发布的照片"/>}'''
assert old in s
s=s.replace(old,new)
# Replace comment sheet with thread state. existing legacy comments retained as separate entries
start=s.index('            <div className="mymy-ig-comments-content">',s.index('export function MymyInstagram'))
end=s.index('          </div>\n        </div>\n      ) : null}',start)
s=s[:start]+'''            <div className="mymy-ig-comments-content">
              {igThread.filter(c=>c.postId===commentsPost.id).map(c=><div key={c.id} className="gt-ig-thread-comment" style={{paddingLeft:c.parentId?24:0}}><span className="gt-ig-thread-avatar">{c.name.slice(0,1).toUpperCase()}</span><div><b>{c.name}</b> {c.text}<small>刚刚　<button type="button" onClick={()=>{setReplyTarget(c.id);setCommentDraft(`@${c.name} `);}}>Reply</button></small></div><Heart size={14}/></div>)}
              {(commentsLocal[commentsPost.id]||[]).map((c,index)=><p key={`legacy-${index}`}><b>jisung</b> {c}</p>)}
              {!igThread.some(c=>c.postId===commentsPost.id)&&!commentsLocal[commentsPost.id]?.length?<p>暂无评论</p>:null}
            </div>
            <form onSubmit={e=>{e.preventDefault();if(!commentDraft.trim())return;const id=`ig-reply-${Date.now()}`;const comment={id,postId:commentsPost.id,name:ownProfileName,text:commentDraft.trim(),parentId:replyTarget||undefined};igThreadRef.current=[...igThreadRef.current,comment];setIgCommentsRaw(JSON.stringify(igThreadRef.current));const count=4+Math.floor(Math.random()*4);setIgQueueRaw(JSON.stringify([...igQueueRef.current,...scheduleEvents(commentsPost.id,"comment",count,1700,2200,id)]));setCommentDraft("");setReplyTarget("");}}>
              <input value={commentDraft} onChange={e=>setCommentDraft(e.target.value)} placeholder={replyTarget?"回复评论…":"添加评论"} aria-label="添加评论" maxLength={500}/><button type="submit">发布</button>
            </form>
''' +s[end:]
s=s.replace('  const [commentDraft, setCommentDraft] = useState("");','  const [commentDraft, setCommentDraft] = useState("");\n  const [replyTarget,setReplyTarget]=useState("");')
p.write_text(s)
print('IG modified',len(s))
