export function compactXCount(value: string | number): string {
  const raw = String(value).trim();
  const normalized = raw.replace(/,/g, "");
  if (!/^\d+(?:\.\d+)?$/.test(normalized)) return raw;
  const n = Number(normalized);
  if (n >= 1000000) return `${(n / 1000000).toFixed(1).replace(/\.0$/, "")}m`;
  if (n >= 1000) return `${(n / 1000).toFixed(1).replace(/\.0$/, "")}k`;
  return raw;
}
