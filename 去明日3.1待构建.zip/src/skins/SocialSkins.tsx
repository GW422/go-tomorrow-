import { compactXCount } from "./compactXCount";
import {PlayerPhoto,preparePlayerPhoto} from "../socialLocal";
import {readEvents,scheduleEvents} from "../socialQueue";
import {fanName,makeFanBatch} from "../socialFans";
import { useSkinState } from "../skinState";
import {
  ArrowDown,
  ArrowUp,
  AtSign,
  Bookmark,
  Camera,
  ChevronRight,
  Grid,
  Hash,
  Heart,
  Home,
  MessageCircle,
  Repeat2,
  User,
  Users,
  Share2,
  ThumbsUp,
} from "lucide-react";
import { useEffect, useRef, useState } from "react";
import type { Item } from "../schema";
import {
  Avatar,
  Empty,
  groupItems,
  Header,
  Media,
  meta,
  SearchBox,
  Tabs,
  useContent,
  type Props,
} from "./shared";
function Actions({ p, item }: { p: Props; item: Item }) {
  const [liked, setLiked] = useSkinState<boolean>(p, `liked-${item.id}`, false),
    [saved, setSaved] = useSkinState<boolean>(p, `saved-${item.id}`, false);
  return (
    <div className="social-actions">
      <button aria-label={`喜欢${item.title}`} onClick={() => setLiked(!liked)}>
        <Heart size={17} fill={liked ? "currentColor" : "none"} />
        {compactXCount(item.likes + (liked ? 1 : 0))}
      </button>
      <button aria-label={`评论${item.title}`} onClick={() => p.onItem(item)}>
        <MessageCircle size={17} />
        {compactXCount(item.comments.length)}
      </button>
      <button aria-label={`详情${item.title}`} onClick={() => p.onItem(item)}>
        <Repeat2 size={17} />
        {compactXCount(meta(item, "reposts", "0"))}
      </button>
      <button aria-label={`收藏${item.title}`} onClick={() => setSaved(!saved)}>
        <Bookmark size={16} fill={saved ? "currentColor" : "none"} />
      </button>
    </div>
  );
}
function PostHeader({ item, p }: { item: Item; p: Props }) {
  return (
    <button className="social-author" onClick={() => p.onItem(item)}>
      <Avatar name={item.sender} />
      <span>
        <strong>{item.sender}</strong>
        <small>{meta(item, "handle", item.time)}</small>
      </span>
    </button>
  );
}
function WeiboActions({ p, item }: { p: Props; item: Item }) {
  const [liked, setLiked] = useSkinState<boolean>(p, `liked-${item.id}`, false);
  return (
    <div className="social-actions weibo-actions">
      <button aria-label={`转发${item.title}`} onClick={() => p.onItem(item)}>
        <Share2 size={17} />
        {meta(item, "reposts", "转发")}
      </button>
      <button aria-label={`评论${item.title}`} onClick={() => p.onItem(item)}>
        <MessageCircle size={17} />
        {item.comments.length || "评论"}
      </button>
      <button
        aria-label={`喜欢${item.title}`}
        aria-pressed={liked}
        onClick={() => setLiked(!liked)}
      >
        <ThumbsUp size={17} fill={liked ? "currentColor" : "none"} />
        {item.likes + (liked ? 1 : 0) || "赞"}
      </button>
    </div>
  );
}
export function WeiboSkin(p: Props) {
  const {q,setQ,items}=useContent(p,"关注");
  const [tab,setTab]=useState("首页");
  const [profile,setProfile]=useState(false);
  const [composer,setComposer]=useState(false);
  const [draft,setDraft]=useState("");
  const [photo,setPhoto]=useState("");
  const [photoError,setPhotoError]=useState("");
  const [queueRaw,setQueueRaw]=useSkinState<string>(p,`gtWeiboQueue-${p.cycleIndex||1}`,"[]");
  const queueRef=useRef(readEvents(queueRaw));queueRef.current=readEvents(queueRaw);
  const [selectedPost,setSelectedPost]=useState("");
  const [legacyDetail,setLegacyDetail]=useState<Item|null>(null);
  const [messageSection,setMessageSection]=useState<"menu"|"mentions"|"comments"|"likes">("menu");
  const [replyDraft,setReplyDraft]=useState("");
  const [replyParent,setReplyParent]=useState("");
  const [mentionOpen,setMentionOpen]=useState(false);
  const [mentionRepliesRaw,setMentionRepliesRaw]=useSkinState<string>(p,`gtWeiboMentionReplies-${p.cycleIndex||1}`,"{}");
  const [mentionReplyDraft,setMentionReplyDraft]=useState("");
  const [mentionTarget,setMentionTarget]=useState("");
  const [likedPlayerPosts,setLikedPlayerPosts]=useSkinState<string[]>(p,`gtWeiboPlayerLikes-${p.cycleIndex||1}`,[]);
  const [socialToast,setSocialToast]=useState("");
  type Mention={id:string;name:string;body:string;comments:{id:string;name:string;text:string;parentId?:string}[]};
  const [mentionsRaw,setMentionsRaw]=useSkinState<string>(p,`gtWeiboMentions-${p.cycleIndex||1}`,"[]");
  let mentions:Mention[]=[];try{const v=JSON.parse(mentionsRaw);if(Array.isArray(v))mentions=v;}catch{}
  const mentionsRef=useRef(mentions);mentionsRef.current=mentions;
  const [mentionDetail,setMentionDetail]=useState("");
  const [banner,setBanner]=useState("");
  const bannerRef=useRef("");
  const showBanner=(body:string)=>{bannerRef.current=body;setBanner(body);window.dispatchEvent(new CustomEvent("gt-social-banner",{detail:{message:`微博：${body}`,force:true}}));};
  const [postedRaw,setPostedRaw]=useSkinState<string>(p,`gtWeiboPlayerPosts-${p.cycleIndex||1}`,"[]");
  const [activityRaw,setActivityRaw]=useSkinState<string>(p,`gtWeiboActivity-${p.cycleIndex||1}`,"[]");
  const [activityRead,setActivityRead]=useSkinState<number>(p,`gtWeiboRead-${p.cycleIndex||1}`,0);
  const [lastSeenActivityId,setLastSeenActivityId]=useSkinState<string>(p,`gtWeiboLastSeen-${p.cycleIndex||1}`,"");
  const [egg,setEgg]=useState(false);
  type FanComment={id:string;name:string;text:string;parentId?:string};
  type PlayerPost={id:string;body:string;comments:FanComment[];likes:number;image?:string};
  type Activity={id:string;body:string};
  let playerPosts:PlayerPost[]=[];let activity:Activity[]=[];
  try {const parsed=JSON.parse(postedRaw);if(Array.isArray(parsed))playerPosts=parsed;}catch{}
  try {const parsed=JSON.parse(activityRaw);if(Array.isArray(parsed))activity=parsed;}catch{}
  const activityRef=useRef(activity);activityRef.current=activity;
  const postsRef=useRef(playerPosts);postsRef.current=playerPosts;
  const commentCopy=(seed:string,index:number,kind:"comment"|"reaction"="comment")=>makeFanBatch(seed,kind==="reaction"?7:50,kind)[index% (kind==="reaction"?7:50)];
  const notify=(body:string,id=`n-${Date.now()}-${Math.random()}`)=>{if(activityRef.current.some(a=>a.id===id))return;const next=[{id,body},...activityRef.current].slice(0,300);activityRef.current=next;setActivityRaw(JSON.stringify(next));if(Math.random()<.2)window.dispatchEvent(new CustomEvent("gt-social-banner",{detail:{message:`微博：${body}`}}));};
  const applyEvent=(event:ReturnType<typeof readEvents>[number])=>{
    if(event.kind==="mention-reaction"){
      const mention=mentionsRef.current.find(m=>m.id===event.postId);
      if(!mention || (mention.comments||[]).some(c=>c.id===event.id))return;
      const comment={id:event.id,name:mention.name,text:makeFanBatch(event.parentId||event.postId,7,"reaction")[event.index%7],parentId:event.parentId};
      const next=mentionsRef.current.map(m=>m.id===event.postId?{...m,comments:[...(m.comments||[]),comment]}:m);
      mentionsRef.current=next;setMentionsRaw(JSON.stringify(next));return;
    }
    const post=postsRef.current.find(v=>v.id===event.postId);
    if(!post)return;
    if(event.kind==="fan"){
      if((post.comments||[]).some(c=>c.id===event.id))return;
      const name=event.parentId?(post.comments||[]).find(c=>c.id===event.parentId)?.name||fanName(event.postId,event.index):fanName(event.postId,event.index);
      const comment={id:event.id,name,text:commentCopy(event.parentId||event.postId,event.index,event.parentId?"reaction":"comment"),parentId:event.parentId};
      const next=postsRef.current.map(v=>v.id===event.postId?{...v,likes:v.likes+1,comments:[...(v.comments||[]),comment]}:v);
      postsRef.current=next;setPostedRaw(JSON.stringify(next.slice(0,24)));
      if(!event.parentId && (Math.random()<.5))notify(`${name} 评论了你的微博`,event.id);
      if(event.parentId && event.index===0)notify(`${name} 回复了你的评论`,event.id);
      if(!event.parentId && event.index%5===0)notify(`${name} 赞了你的微博`,`like-${event.id}`);
    }else if(event.kind==="mention") { /* legacy queue entries are handled by the global mention timer */ }
    else if(event.kind==="egg-like") {setEgg(true);showBanner("n8_3m 赞了你的微博");notify("n8_3m 赞了你的微博",event.id);}
    else if(event.kind==="egg-unlike") {setEgg(false);showBanner("n8_3m 取消了对你微博的赞");notify("n8_3m 取消了对你微博的赞",event.id);}
  };
  useEffect(()=>{
    const timer=window.setInterval(()=>{
      const due=queueRef.current.find(e=>e.due<=Date.now());if(!due)return;
      const next=queueRef.current.filter(e=>e.id!==due.id);
      applyEvent(due);queueRef.current=next;setQueueRaw(JSON.stringify(next));
    },2000);
    return ()=>window.clearInterval(timer);
  },[p.cycleIndex]);
  // Mentions are generated by PhoneRuntime, independent of the active app.
  const publish=()=>{
    if(!draft.trim())return;
    const id=`wb-${Date.now()}`;
    const next=[{id,body:draft.trim(),comments:[],likes:0,image:photo},...postsRef.current];postsRef.current=next;setPostedRaw(JSON.stringify(next.slice(0,24)));
    const events=[...scheduleEvents(id,"fan",50,2000,2000)];
    if(Math.random()<.7)events.push(...scheduleEvents(id,"egg-like",1,11500),...scheduleEvents(id,"egg-unlike",1,13600));
    queueRef.current=[...queueRef.current,...events];setQueueRaw(JSON.stringify(queueRef.current));
    setDraft("");setPhoto("");setComposer(false);setProfile(true);setTab("我");setSocialToast("微博发布成功");
  };
  const reply=(post:PlayerPost,parentId?:string)=>{
    if(!replyDraft.trim())return;
    const id=`self-${Date.now()}`;
    const next=postsRef.current.map(v=>v.id===post.id?{...v,comments:[...(v.comments||[]),{id,name:"志晟_JISUNG",text:replyDraft.trim(),parentId}]}:v);
    postsRef.current=next;setPostedRaw(JSON.stringify(next));setReplyDraft("");
    const events=scheduleEvents(post.id,"fan",4+Math.floor(Math.random()*4),2000,2000,id);
    queueRef.current=[...queueRef.current,...events];setQueueRaw(JSON.stringify(queueRef.current));
  };
  const replyMention=(mention:Mention)=>{
    if(!mentionReplyDraft.trim())return;
    const id=`self-${Date.now()}`;
    const next=mentionsRef.current.map(m=>m.id===mention.id?{...m,comments:[...(m.comments||[]),{id,name:"志晟_JISUNG",text:mentionReplyDraft.trim()}]}:m);
    mentionsRef.current=next;setMentionsRaw(JSON.stringify(next));setMentionReplyDraft("");
    const count=4+Math.floor(Math.random()*4);
    const events=scheduleEvents(mention.id,"mention-reaction",count,2000,2000,id);
    queueRef.current=[...queueRef.current,...events];setQueueRaw(JSON.stringify(queueRef.current));
  };
  const avatar=<img className="gt-wb-avatar" src="./gt-social/jisung-weibo-avatar.jpeg" alt="朴志晟微博头像"/>;
  return <div className="gt-weibo-app">
    {composer?<div className="gt-wb-compose"><header><button onClick={()=>setComposer(false)}>取消</button><b>发微博</b><button onClick={publish} disabled={!draft.trim()}>发布</button></header><textarea value={draft} onChange={e=>setDraft(e.target.value)} placeholder="分享新鲜事…" maxLength={500}/><label className="gt-wb-photo-label">▧ 从相册选择图片<input type="file" accept="image/*" onChange={async e=>{const file=e.target.files?.[0];if(!file)return;setPhotoError("");try{const saved=await preparePlayerPhoto(file);setPhoto(saved.key);}catch(error){setPhotoError(error instanceof Error?error.message:"图片保存失败");}}}/></label>{photoError&&<p role="alert">{photoError}</p>}{photo&&<PlayerPhoto className="gt-wb-photo-preview" src={photo} alt="选择的图片"/>}<div className="gt-wb-tags"><button onClick={()=>setDraft(v=>v+"做了很长的梦")}>做了很长的梦</button><button onClick={()=>setDraft(v=>v+"时间循环真的存在吗？")}>时间循环真的存在吗？</button></div></div>:
    <>
    <header className="gt-wb-top"><button onClick={()=>profile?setProfile(false):p.onBack()}>{profile?"‹":"微博"}</button><b>{profile?"志晟_JISUNG":tab==="我"?"我":"微博"}</b><button onClick={()=>setComposer(true)}>＋</button></header>
    <div className="gt-wb-scroll">
      {banner&&<button className="gt-wb-egg" onClick={()=>setBanner("")}>{banner} ×</button>}{socialToast&&<button className="gt-wb-toast" onClick={()=>setSocialToast("")}>{socialToast} ×</button>}
      {tab==="消息"&&!profile?<div className="gt-wb-notifications">
        <header className="gt-wb-message-header"><b>消息</b><small>{activity.length && activity[0]?.id!==lastSeenActivityId?"有新消息":""}</small></header>
        {messageSection==="menu"?<div className="gt-wb-message-menu">
          <button onClick={()=>{setMessageSection("mentions");setMentionOpen(true);setMentionDetail("");}}><span className="gt-wb-category-icon mention">@</span><b>提及我的</b><span className="gt-wb-category-count">{mentions.length}</span><ChevronRight size={18}/></button>
          <button onClick={()=>setMessageSection("comments")}><span className="gt-wb-category-icon comment">▤</span><b>评论</b><span className="gt-wb-category-count">{activity.filter(a=>/评论|回复/.test(a.body)).length}</span><ChevronRight size={18}/></button>
          <button onClick={()=>setMessageSection("likes")}><span className="gt-wb-category-icon like">♡</span><b>赞</b><span className="gt-wb-category-count">{activity.filter(a=>/赞|取消/.test(a.body)).length}</span><ChevronRight size={18}/></button>
          <div className="gt-wb-message-secondary">留言板 <small>暂无新留言</small></div><div className="gt-wb-message-secondary">活动通知 <small>查看近期动态</small></div>
        </div>:<><button className="gt-wb-message-back" onClick={()=>{if(mentionDetail)setMentionDetail("");else setMessageSection("menu");}}>‹ {mentionDetail?"提及我的":"消息"}</button>
        <h3>{messageSection==="mentions"?"提及我的":messageSection==="comments"?"评论":"赞"}</h3>
        {messageSection==="mentions"?<div className="gt-wb-mentions">{mentions.filter(m=>!mentionDetail||m.id===mentionDetail).map(m=><article className="gt-wb-mention-post" key={m.id}><div className="gt-wb-author"><span className="gt-wb-fan-avatar">{(m.name||"粉丝").charAt(0).toUpperCase()}</span><div><b>{m.name||"粉丝"}</b><small>刚刚 · 来自微博</small></div></div><button className="gt-wb-story" onClick={()=>setMentionDetail(m.id)}><p>{m.body}</p></button>{mentionDetail===m.id&&<><div className="gt-wb-mention-actions"><button onClick={()=>setMentionTarget(m.id)}>回复</button><span>♡　评论　转发</span></div>{(m.comments||[]).map(c=><div className="gt-wb-mention-reply" key={c.id}><b>{c.name||"粉丝"}：</b>{c.text}</div>)}<form className="gt-wb-mention-form" onSubmit={e=>{e.preventDefault();replyMention(m);setMentionTarget("");}}><input aria-label="回复粉丝提及" value={mentionReplyDraft} onChange={e=>setMentionReplyDraft(e.target.value)} placeholder={`回复 @${m.name}`}/><button type="submit">发送</button></form></>}</article>)}</div>:<div className="gt-wb-activity-feed">{activity.filter(a=>messageSection==="likes"?/赞|取消/.test(a.body):/评论|回复/.test(a.body)).map(a=><div className="gt-wb-activity" key={a.id}><span>{messageSection==="likes"?"♡":"▤"}</span><span>{a.body}</span><small>刚刚</small></div>)}</div>}
        </>}
      </div>:
      profile||tab==="我"?<>
        <div className="gt-wb-profile-cover"/>
        <div className="gt-wb-profile"><div className="gt-wb-profile-line">{avatar}<div><h2>志晟_JISUNG <span>👑</span></h2><small>歌手志晟，代表作《ISTJ》</small></div></div><div className="gt-wb-counts"><span><b>750.7K</b> Followers</span><span><b>8</b> Follow</span><span><b>19.3M</b> interaction</span></div><p>V-index Entertainment 61.43 points</p><div className="gt-wb-profile-tabs">Activity　 <b>Weibo</b>　 Opus　 Album</div><div className="gt-wb-all">All Weibo ({102+playerPosts.length}) <span>Filter</span></div></div>
      </>:<>{tab==="发现"&&<div className="gt-wb-discover"><h3>发现 · 热门话题</h3><button onClick={()=>setDraft("#今天的天空# ")}>#今天的天空#</button><button onClick={()=>setDraft("#最近在听的歌# ")}>#最近在听的歌#</button><button onClick={()=>setDraft("#记录生活# ")}>#记录生活#</button><p>看看大家正在讨论什么</p></div>}<div className="gt-wb-feed-tabs"><button onClick={()=>setTab("首页")}>关注</button><button onClick={()=>setTab("发现")}>发现</button><button onClick={()=>setTab("我")}>我</button></div><div className="gt-wb-search"><SearchBox value={q} set={setQ}/></div></>}
      {playerPosts.map(post=><article className="gt-wb-post" key={post.id}><div className="gt-wb-author">{avatar}<div><b>志晟_JISUNG <span>✓</span></b><small>刚刚 · 来自 iPhone</small></div></div><p>{post.body}</p>{post.image&&<PlayerPhoto className="gt-wb-post-image" src={post.image} alt="微博配图"/>}<div className="gt-wb-post-actions"><button onClick={()=>setSelectedPost(selectedPost===post.id?"":post.id)}>↗ 转发</button><button onClick={()=>setSelectedPost(post.id)}>▢ {(post.comments||[]).length||"评论"}</button><button aria-pressed={likedPlayerPosts.includes(post.id)} onClick={()=>setLikedPlayerPosts(likedPlayerPosts.includes(post.id)?likedPlayerPosts.filter(v=>v!==post.id):[...likedPlayerPosts,post.id])}>♡ {post.likes+(likedPlayerPosts.includes(post.id)?1:0)||"赞"}</button></div></article>)}
      {items.filter(i=>!q||`${i.title} ${i.body}`.toLowerCase().includes(q.toLowerCase())).map(i=><article className="gt-wb-post" key={i.id}><div className="gt-wb-author"><Avatar name={i.sender}/><div><b>{i.sender}</b><small>{i.time}</small></div></div><button className="gt-wb-story" onClick={()=>setLegacyDetail(i)}><p>{i.body}</p>{i.media&&<Media item={i}/>}</button><div className="gt-wb-post-actions"><button onClick={()=>p.onItem(i)}>↗ 转发</button><button onClick={()=>setLegacyDetail(i)}>▢ {i.comments?.length||"评论"}</button><button onClick={()=>p.onItem(i)}>♡ {i.likes||"赞"}</button></div></article>)}
    </div>
    {(selectedPost||legacyDetail)&&<div className="gt-wb-detail-overlay"><header><button onClick={()=>{setSelectedPost("");setLegacyDetail(null);setReplyParent("");}}>‹</button><b>志晟_JISUNG</b><span>•••</span></header><div className="gt-wb-detail-scroll"><article className="gt-wb-post"><div className="gt-wb-author">{avatar}<b>志晟_JISUNG</b></div><p>{legacyDetail?.body||playerPosts.find(v=>v.id===selectedPost)?.body}</p></article><div className="gt-wb-detail-tabs"><span>转发</span><b>评论 {legacyDetail?(legacyDetail.comments||[]).length:(playerPosts.find(v=>v.id===selectedPost)?.comments||[]).length}</b><span>赞</span></div>{(legacyDetail?(legacyDetail.comments||[]).map((c,i)=>({id:String(i),name:"粉丝",text:typeof c==="string"?c:"",parentId:""})):(playerPosts.find(v=>v.id===selectedPost)?.comments||[])).map(c=><div className="gt-wb-detail-comment" key={c.id}><span className="gt-wb-fan-avatar">{(c.name||"粉丝").charAt(0).toUpperCase()}</span><div><b>{c.name||"粉丝"}</b><p>{c.text||""}</p><small>刚刚　来自微博</small><button onClick={()=>{setReplyParent(c.id);setReplyDraft(`@${c.name||"粉丝"} `);}}>回复</button></div></div>)}</div>{!legacyDetail&&<form className="gt-wb-detail-compose" onSubmit={e=>{e.preventDefault();const post=playerPosts.find(v=>v.id===selectedPost);if(post)reply(post,replyParent||undefined);setReplyParent("");}}><input value={replyDraft} onChange={e=>setReplyDraft(e.target.value)} placeholder="评论…"/><button type="submit">发送</button></form>}</div>}
    <nav className="gt-wb-bottom"><button onClick={()=>{setTab("首页");setProfile(false);}}>⌂<small>首页</small></button><button onClick={()=>{setTab("发现");setProfile(false);}}>⌕<small>发现</small></button><button onClick={()=>setComposer(true)}>＋<small>发布</small></button><button onClick={()=>{setTab("消息");setProfile(false);setActivityRead(activity.length);setLastSeenActivityId(activity[0]?.id||"");setMentionOpen(false);}}>▣{activity.length>0&&activity[0].id!==lastSeenActivityId&&<i/>}<small>消息</small></button><button onClick={()=>{setTab("我");setProfile(true);}}>●<small>我</small></button></nav>
    </>}
  </div>;
}
export function XSkin(p: Props) {
  const { tab, setTab, q, setQ, items } = useContent(p, "为你推荐");
  return (
    <div className="catalog-skin x-ui">
      <Header p={p} />
      <div className="x-feed-tabs">
        <button
          className={tab === "为你推荐" ? "selected" : ""}
          onClick={() => setTab("为你推荐")}
        >
          为你推荐
        </button>
        <button
          className={tab === "正在关注" ? "selected" : ""}
          onClick={() => setTab("正在关注")}
        >
          正在关注
        </button>
      </div>
      <div className="catalog-scroll">
        <SearchBox value={q} set={setQ} />
        {items
          .filter((i) => tab === "为你推荐" || i.folder === "正在关注")
          .map((i) => (
            <article className="x-post" key={i.id}>
              <Avatar name={i.sender} />
              <div>
                <button className="x-byline" onClick={() => p.onItem(i)}>
                  <strong>{i.sender}</strong>
                  <span>
                    @{meta(i, "handle", i.sender)} · {i.time.slice(5, 10)}
                  </span>
                </button>
                <button className="social-body" onClick={() => p.onItem(i)}>
                  <p>{i.body.length > 260 ? i.body.slice(0,260) + "…" : i.body}</p>
                  {i.body.length > 260 && <span style={{color:"#1684ff"}}>查看全部</span>}
                  {i.media && <Media item={i} />}
                </button>
                <small style={{color:"#7a7a7a"}}>浏览 {compactXCount(meta(i,"views","0"))}</small>
                <Actions p={p} item={i} />
              </div>
            </article>
          ))}
      </div>
      <Tabs
        tabs={["为你推荐", "正在关注"]}
        value={tab}
        set={setTab}
        icons={[<Home />, <Users />]}
      />
    </div>
  );
}
export function ThreadsSkin(p: Props) {
  const { tab, setTab, items } = useContent(p, "为你推荐");
  return (
    <div className="catalog-skin threads-ui">
      <Header p={p} />
      <div className="threads-title">
        <AtSign size={30} />
        <button
          onClick={() => setTab(tab === "为你推荐" ? "正在关注" : "为你推荐")}
        >
          {tab} ⌄
        </button>
      </div>
      <div className="catalog-scroll">
        {(tab === "个人主页"
          ? items
          : items.filter((i) => tab !== "正在关注" || i.folder === "正在关注")
        ).map((i) => (
          <article className="threads-post" key={i.id}>
            <div className="thread-avatar">
              <Avatar name={i.sender} />
              <i />
            </div>
            <div>
              <div className="threads-byline">
                <strong>{i.sender}</strong>
                <small>{i.time.slice(5, 10)}</small>
              </div>
              <button className="social-body" onClick={() => p.onItem(i)}>
                <p>{i.body}</p>
                {i.media && <Media item={i} />}
              </button>
              <Actions p={p} item={i} />
              <button className="thread-replies" onClick={() => p.onItem(i)}>
                {i.comments.length} 条回复
              </button>
            </div>
          </article>
        ))}
        <Empty items={items} />
      </div>
      <Tabs
        tabs={["为你推荐", "正在关注", "个人主页"]}
        value={tab}
        set={setTab}
        icons={[<Home />, <Users />, <User />]}
      />
    </div>
  );
}
export function FacebookSkin(p: Props) {
  const { tab, setTab, q, setQ, items } = useContent(p, "动态");
  const stories = items.filter((i) => i.folder === "Story");
  return (
    <div className="catalog-skin facebook-ui">
      <Header p={p} />
      <Tabs
        tabs={["动态", "好友", "个人主页"]}
        value={tab}
        set={setTab}
        icons={[<Home />, <Users />, <User />]}
      />
      <div className="catalog-scroll">
        <SearchBox value={q} set={setQ} />
        {tab === "动态" ? (
          <>
            <button
              className="fb-compose"
              disabled={!p.creator}
              onClick={p.onAdd}
            >
              <Avatar name={p.owner ?? "我"} />
              分享新动态
            </button>
            <div className="fb-stories">
              {stories.map((i) => (
                <button key={i.id} onClick={() => p.onItem(i)}>
                  <Media item={i} />
                  <strong>{i.sender}</strong>
                </button>
              ))}
            </div>
            {items
              .filter((i) => i.folder !== "Story")
              .map((i) => (
                <article className="fb-post" key={i.id}>
                  <PostHeader p={p} item={i} />
                  <button className="social-body" onClick={() => p.onItem(i)}>
                    <p>{i.body}</p>
                    {i.media && <Media item={i} />}
                  </button>
                  <Actions p={p} item={i} />
                </article>
              ))}
          </>
        ) : tab === "好友" ? (
          <div className="fb-friends">
            {[...new Set(items.map((i) => i.sender))].map((s) => (
              <button
                key={s}
                onClick={() => p.onItem(items.find((i) => i.sender === s)!)}
              >
                <Avatar name={s} />
                <strong>{s}</strong>
              </button>
            ))}
          </div>
        ) : (
          <>
            <div className="fb-cover" />
            <div className="fb-profile">
              <Avatar name={p.owner ?? "我"} />
              <h1>{p.owner ?? "我"}</h1>
            </div>
            {items
              .filter((i) => i.folder === "个人主页")
              .map((i) => (
                <button
                  key={i.id}
                  className="fb-profile-note"
                  onClick={() => p.onItem(i)}
                >
                  {i.title}
                  <p>{i.body}</p>
                </button>
              ))}
          </>
        )}
      </div>
    </div>
  );
}
export function RedbookSkin(p: Props) {
  const { tab, setTab, q, setQ, items } = useContent(p, "发现");
  const list =
    tab === "收藏"
      ? items.filter((i) => i.favorite)
      : tab === "关注"
        ? items.filter((i) => i.folder === "关注")
        : items;
  return (
    <div className="catalog-skin redbook-ui">
      <Header p={p} />
      <div className="redbook-top">
        {["关注", "发现", "收藏"].map((t) => (
          <button
            key={t}
            className={tab === t ? "selected" : ""}
            onClick={() => setTab(t)}
          >
            {t}
          </button>
        ))}
      </div>
      <div className="catalog-scroll">
        <SearchBox value={q} set={setQ} />
        <div className="redbook-masonry">
          {list.map((i) => (
            <button key={i.id} onClick={() => p.onItem(i)}>
              <Media item={i} />
              <strong>{i.title}</strong>
              <div>
                <Avatar name={i.sender} />
                <small>{i.sender}</small>
                <Heart size={12} />
                <small>{i.likes}</small>
              </div>
            </button>
          ))}
        </div>
        <Empty items={list} />
      </div>
      <Tabs
        tabs={["发现", "收藏"]}
        value={tab}
        set={setTab}
        icons={[<Home />, <Bookmark />]}
      />
    </div>
  );
}
export function PinterestSkin(p: Props) {
  const { tab, setTab, q, setQ, items } = useContent(p, "发现");
  const [board, setBoard] = useState("");
  const list = board
    ? items.filter((i) => (i.folder || "未分类") === board)
    : items;
  return (
    <div className="catalog-skin pinterest-ui">
      <Header p={p} />
      <div className="catalog-scroll">
        {tab === "收藏板" && !board ? (
          <>
            <h1>收藏板</h1>
            <div className="pinterest-boards">
              {groupItems(items).map((g) => (
                <button key={g} onClick={() => setBoard(g)}>
                  <Media
                    item={items.find((i) => (i.folder || "未分类") === g)!}
                  />
                  <strong>{g}</strong>
                </button>
              ))}
            </div>
          </>
        ) : (
          <>
            <SearchBox value={q} set={setQ} />
            {board && (
              <button
                className="pinterest-board-title"
                onClick={() => setBoard("")}
              >
                {board} · 返回收藏板
              </button>
            )}
            <div className="pinterest-pins">
              {list.map((i) => (
                <button key={i.id} onClick={() => p.onItem(i)}>
                  <Media item={i} />
                  <strong>{i.title}</strong>
                </button>
              ))}
            </div>
            <Empty items={list} />
          </>
        )}
      </div>
      <Tabs
        tabs={["发现", "收藏板"]}
        value={tab}
        set={(t) => {
          setTab(t);
          setBoard("");
        }}
        icons={[<Home />, <Grid />]}
      />
    </div>
  );
}
export function RedditSkin(p: Props) {
  const { tab, setTab, q, setQ, items } = useContent(p, "首页");
  const [sort, setSort] = useState("最新");
  const list = [...items].sort((a, b) =>
    sort === "热门" ? b.likes - a.likes : b.time.localeCompare(a.time),
  );
  return (
    <div className="catalog-skin reddit-ui">
      <Header p={p} />
      <div className="reddit-community">
        <Hash size={21} />
        <button onClick={() => setTab(tab === "首页" ? "社区" : "首页")}>
          {tab} ⌄
        </button>
        <select
          aria-label="帖子排序"
          value={sort}
          onChange={(e) => setSort(e.target.value)}
        >
          <option>最新</option>
          <option>热门</option>
        </select>
      </div>
      <div className="catalog-scroll">
        <SearchBox value={q} set={setQ} />
        {tab === "社区"
          ? groupItems(items).map((g) => (
              <button
                className="reddit-sub"
                key={g}
                onClick={() => {
                  setQ(g === "未分类" ? "" : g);
                  setTab("首页");
                }}
              >
                <Hash size={22} />
                {g}
                <small>
                  {items.filter((i) => (i.folder || "未分类") === g).length} 帖
                </small>
              </button>
            ))
          : list.map((i) => <RedditPost key={i.id} p={p} item={i} />)}
        <Empty items={items} />
      </div>
      <Tabs
        tabs={["首页", "社区"]}
        value={tab}
        set={setTab}
        icons={[<Home />, <Users />]}
      />
    </div>
  );
}
function RedditPost({ p, item: i }: { p: Props; item: Item }) {
  const [vote, setVote] = useSkinState<number>(p, `vote-${i.id}`, 0);
  return (
    <article className="reddit-post">
      <button className="reddit-byline" onClick={() => p.onItem(i)}>
        r/{meta(i, "community", i.folder || "story")} · u/{i.sender}
      </button>
      <button className="social-body" onClick={() => p.onItem(i)}>
        <h3>{i.title}</h3>
        <p>{i.body}</p>
        {i.media && <Media item={i} />}
      </button>
      <div className="reddit-actions">
        <button
          aria-label={`赞同${i.title}`}
          onClick={() => setVote(vote === 1 ? 0 : 1)}
        >
          <ArrowUp size={17} />
        </button>
        <span>{Number(meta(i, "votes", String(i.likes))) + vote}</span>
        <button
          aria-label={`反对${i.title}`}
          onClick={() => setVote(vote === -1 ? 0 : -1)}
        >
          <ArrowDown size={17} />
        </button>
        <button onClick={() => p.onItem(i)}>
          <MessageCircle size={16} />
          {i.comments.length} 评论
        </button>
      </div>
    </article>
  );
}
export function ForumSkin(p: Props) {
  const { tab, setTab, q, setQ, items } = useContent(p, "帖子");
  const [board, setBoard] = useState("");
  const list = board
    ? items.filter((i) => (i.folder || "未分类") === board)
    : items;
  return (
    <div className="catalog-skin forum-ui">
      <Header p={p} />
      <div className="forum-banner">
        <Hash size={27} />
        <strong>{board || "论坛"}</strong>
        <span>{items.length} 个主题</span>
      </div>
      <div className="catalog-scroll">
        <SearchBox value={q} set={setQ} />
        {tab === "版块"
          ? groupItems(items).map((g) => (
              <button
                className="forum-board"
                key={g}
                onClick={() => {
                  setBoard(g);
                  setTab("帖子");
                }}
              >
                <FolderIcon />
                <div>
                  <strong>{g}</strong>
                  <small>
                    {items.filter((i) => (i.folder || "未分类") === g).length}{" "}
                    个主题
                  </small>
                </div>
                <ChevronRight size={16} />
              </button>
            ))
          : list.map((i) => (
              <button
                className="forum-topic"
                key={i.id}
                onClick={() => p.onItem(i)}
              >
                <strong>
                  {meta(i, "status") && <em>{meta(i, "status")}</em>}
                  {i.title}
                </strong>
                <p>{i.body.split("\n")[0]}</p>
                <div>
                  <span>
                    {i.sender} · {i.time.slice(5, 16)}
                  </span>
                  <span>
                    {meta(i, "views", "—")} 浏览 · {i.comments.length} 回复
                  </span>
                </div>
              </button>
            ))}
      </div>
      <Tabs
        tabs={["帖子", "版块"]}
        value={tab}
        set={(t) => {
          setTab(t);
          setBoard("");
        }}
        icons={[<MessageCircle />, <Grid />]}
      />
    </div>
  );
}
function FolderIcon() {
  return <Hash size={27} />;
}
export function SnapchatSkin(p: Props) {
  const { tab, setTab, items } = useContent(p, "快拍");
  const [index, setIndex] = useState(0);
  const list = items.filter((i) =>
    tab === "回忆"
      ? i.favorite || i.folder === "回忆"
      : tab === "聊天"
        ? i.folder === "聊天"
        : i.folder !== "聊天",
  );
  const i = list[index % Math.max(list.length, 1)];
  return (
    <div className="catalog-skin snapchat-ui">
      <Header p={p} />
      <div className="snap-content">
        {tab === "聊天" ? (
          <div className="snap-chats">
            {list.map((x) => (
              <button key={x.id} onClick={() => p.onItem(x)}>
                <Avatar name={x.sender} />
                <div>
                  <strong>{x.sender}</strong>
                  <small>{x.body}</small>
                </div>
                <Camera size={20} />
              </button>
            ))}
          </div>
        ) : i ? (
          <>
            <Media item={i} />
            <button className="snap-author" onClick={() => p.onItem(i)}>
              <Avatar name={i.sender} />
              {i.sender}
            </button>
            <button
              className="snap-next"
              aria-label="下一条快拍"
              onClick={() => {
                setIndex((n) => n + 1);
                p.onRead(i.id);
              }}
            >
              <ChevronRight size={25} />
            </button>
            <button className="snap-caption" onClick={() => p.onItem(i)}>
              {i.body}
            </button>
          </>
        ) : (
          <p className="catalog-empty">暂无{tab}</p>
        )}
      </div>
      <Tabs
        tabs={["聊天", "快拍", "回忆"]}
        value={tab}
        set={(t) => {
          setTab(t);
          setIndex(0);
        }}
        icons={[<MessageCircle />, <Camera />, <ImageIcon />]}
      />
    </div>
  );
}
function ImageIcon() {
  return <Grid />;
}
