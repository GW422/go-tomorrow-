import {useState} from "react";
import { Play, Pause, ChevronLeft, Search, MoreHorizontal, RotateCcw, RotateCw, AudioLines, Trash2, Mic } from "lucide-react";
import type { SkinProps } from "../AppSkins";
import "./voice-memos.css";
export function VoiceMemosSkin(p:SkinProps){
 const [selected,setSelected]=useState("");
 const [revealed,setRevealed]=useState(false);
 const [playing,setPlaying]=useState(false);
 const [progress,setProgress]=useState(0);
 const records=p.items.filter(i=>i.kind==="note" || i.kind==="audio");
 const chosen=records.find(i=>i.id===selected);
 const format=(n:number)=>`${Math.floor(n/60)}:${String(Math.floor(n%60)).padStart(2,"0")}`;
 const duration=(s:string)=>{const v=s.split(":").map(Number);return v.length===2?v[0]*60+v[1]:0;};
 const total=chosen?duration(chosen.meta.duration||"0:00"):0;
 return <div className="gt-voice-app">
   <header className="gt-voice-top"><button onClick={p.onBack} aria-label="返回"><ChevronLeft size={23}/></button><div><button className="gt-voice-pill">选择</button><button className="gt-voice-pill" aria-label="搜索"><Search size={20}/></button></div></header>
   <main><h1>所有录音</h1><div className="gt-voice-list">{records.map(i=><div key={i.id} className="gt-voice-record">
     <button className="gt-voice-row" onClick={()=>{setSelected(i.id===selected?"":i.id);setRevealed(false);setPlaying(false);setProgress(0);p.onRead(i.id);}}><span><b>{i.title}</b><small>2026/10/22</small></span><span className="gt-voice-duration">{i.id===selected?<MoreHorizontal size={19}/>:i.meta.duration||"录音"}</span></button>
     {chosen?.id===i.id&&<div className="gt-voice-expand">
       <input type="range" min={0} max={total||1} value={progress} aria-label="录音进度" onChange={e=>setProgress(Number(e.target.value))}/>
       <div className="gt-voice-times"><span>{format(progress)}</span><span>-{format(Math.max(0,total-progress))}</span></div>
       <div className="gt-voice-controls"><button aria-label="转写" onClick={()=>setRevealed(v=>!v)}><AudioLines color="#237aff"/></button><button aria-label="后退15秒" onClick={()=>setProgress(v=>Math.max(0,v-15))}><RotateCcw/><small>15</small></button><button aria-label={playing?"暂停":"播放"} onClick={()=>{setPlaying(v=>!v);setRevealed(true);}}>{playing?<Pause fill="currentColor"/>:<Play fill="currentColor"/>}</button><button aria-label="前进15秒" onClick={()=>setProgress(v=>Math.min(total,v+15))}><RotateCw/><small>15</small></button><button aria-label="录音信息"><MoreHorizontal color="#237aff"/></button></div>
       {revealed&&<div className="gt-voice-transcript">{i.body.split("\n").map((line,j)=><p key={j} style={{animationDelay:`${j*.55}s`}}>{line}</p>)}</div>}
     </div>}
   </div>)}</div></main><button className="gt-voice-record-button" aria-label="录音按钮（剧情中不可录制）"><span/></button>
 </div>;
}
