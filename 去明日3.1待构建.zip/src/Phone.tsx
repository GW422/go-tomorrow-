import {appendWeiboMention} from "./weiboMentions";
import { GlobalMusicProvider, GlobalMusicCard } from "./GlobalMusic";
import { BUILD_FINGERPRINT } from "./generated-build-id";
import { day2Scenes, day2SceneBoundary } from "./day2Continuation";
import {day3PauseBeforeLine} from "./day3Continuation";
import { Day2Experience } from "./Day2Experience";
import { day2Chat } from "./day2Story";
import { day2XPosts } from "./day2X";
import { StatusGlyph } from "./ios/StatusGlyph";
import { SocialDetail, socialDetailApps } from "./skins/SocialDetails";
import { NativeCalculator } from "./ios/Calculator";
import { HomeLauncher } from "./launcher/HomeLauncher";
import { useDeviceLayout } from "./launcher/layout";
import "./launcher/launcher.css";
import { NativeDetail, nativeDetailApps } from "./ios/Details";
import "./ios/details.css";
import {
  SystemNotifications,
  notificationContent,
} from "./SystemNotifications";
import {
  readLauncherOrigin,
  AppWindow,
  screenOrigin,
} from "./vendor/ios-web/Launcher";
import {
  DeviceLock,
  ControlCenter,
  DeviceKeyboard,
  KeyboardContext,
  NativeSettings,
} from "./DeviceSystem";
import { AppArtwork, hasNativeArtwork } from "./AppArtwork";
import { getFields } from "./fields";
import { catalogSkins } from "./skins/catalog";
import "./skins/skins.css";
import "./ios18.css";
import "./device-system.css";
import "./ios/tokens.css";
import "./ios/reference.css";
import "./ios/status-bar.css";
import { WeChatSkin, WhatsAppSkin } from "./AppSkins";
import { RichText } from "./RichText";
import {
  useEffect,
  useState,
  useRef,
  Suspense,
  type CSSProperties,
} from "react";
import { AnimatePresence } from "motion/react";
import {
  ChevronLeft,
  Plus,
  Search,
  LockKeyhole,
  Heart,
  MessageCircle,
  MoreHorizontal,
  ArrowUp,
  Folder,
  Image as ImageIcon,
  Phone as PhoneIcon,
} from "lucide-react";
import { getApp, type AppPlugin } from "./registry";
import {
  initialRuntime,
  safeMedia,
  type Work,
  type Item,
  itemSchema,
  type Runtime,
  type UiValue,
} from "./schema";
import { dispatch, choose, visible, advance } from "./engine";
import { db } from "./persistence";
export function AppIcon({
  id,
  name,
  small = false,
  custom = "",
  date,
  time,
  unread = 0,
}: {
  id: string;
  name?: string;
  small?: boolean;
  custom?: string;
  date?: string;
  time?: string;
  unread?: number;
}) {
  const a = getApp(id);
  const Icon = a.icon;
  return (
    <span className={`app-icon-wrap ${small ? "small" : ""}`}>
      <span className="app-icon" style={{ background: a.color }}>
        {custom ? (
          safeMedia(custom) ? (
            <img src={safeMedia(custom)} alt="自定义图标" />
          ) : (
            <span>{custom.slice(0, 2)}</span>
          )
        ) : id === "voice_memos" ? (
          <span className="gt-voice-icon"><span className="gt-voice-wave"/></span>
        ) : hasNativeArtwork(id) ? (
          <AppArtwork id={id} date={date} time={time} />
        ) : (
          <Icon size={small ? 21 : 28} strokeWidth={1.65} />
        )}
      </span>
      {unread > 0 && <span className="kakao-unread-badge">{unread > 99 ? "99+" : unread}</span>}
      {name && <span className="app-name">{name}</span>}
    </span>
  );
}
type PhoneProps = Omit<Parameters<typeof PhoneRuntime>[0], "deviceLayout">;
export function Phone(props: PhoneProps) {
  const deviceLayout = useDeviceLayout(props.work, props.creator);
  return (
    <GlobalMusicProvider><PhoneRuntime
      {...props}
      work={deviceLayout.work}
      deviceLayout={deviceLayout}
    /></GlobalMusicProvider>
  );
}
function PhoneRuntime({
  deviceLayout,
  work,
  creator = false,
  onEdit,
  onAdd,
  onSettings,
  onOpen,
  runtime: external,
  onRuntime,
  onDemandApp,
  loadingApps,
}: {
  deviceLayout: ReturnType<typeof useDeviceLayout>;
  work: Work;
  creator?: boolean;
  onEdit?: (app: string, item: Item) => void;
  onAdd?: (app: string) => void;
  onSettings?: () => void;
  onOpen?: (app: string) => void;
  runtime?: Runtime;
  onRuntime?: (s: Runtime) => void;
  onDemandApp?: (app: string) => void;
  loadingApps?: string[];
}) {
  const [app, setApp] = useState("");
  const [homeRequest, setHomeRequest] = useState(0);
  const [locked, setLocked] = useState(!creator);
  const [pinOpen, setPinOpen] = useState(false);
  const [quickCamera, setQuickCamera] = useState(false);
  const [keyboard, setKeyboard] = useState(false);
  const [recent, setRecent] = useState<string[]>([]);
  const appSnapshots = useRef(new Map<string, HTMLElement>());
  const [banner, setBanner] = useState("");
  const noticesSeen = useRef(0);
  const bannerQueue = useRef<string[]>([]);
  const bannerTimer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  const bannerActive = useRef(false);
  const lastBannerAt=useRef(0);
  const appForBanners=useRef("");
  appForBanners.current=app;
  const bannerRefText=useRef("");
  bannerRefText.current=banner;
  const dismissBanner=()=>{setBanner("");if(bannerTimer.current)clearTimeout(bannerTimer.current);bannerActive.current=false;window.setTimeout(()=>showQueuedBanner(),250);};
  const showQueuedBanner = () => {
    if (bannerActive.current) return;
    if(!bannerQueue.current.length)return;
    const focused=appForBanners.current==="kakao" || !!document.querySelector(".gt-wb-compose,.gt-ig-compose,.gt-instagram-compose");
    const gap=focused?10000:7000;
    const wait=gap-(Date.now()-lastBannerAt.current);
    if(wait>0){bannerTimer.current=window.setTimeout(showQueuedBanner,wait);return;}
    const next = bannerQueue.current.shift();
    if (!next) return;
    bannerActive.current = true;
    lastBannerAt.current=Date.now();
    setBanner(next);
    bannerTimer.current = window.setTimeout(() => {
      setBanner("");
      bannerTimer.current = window.setTimeout(() => {
        bannerActive.current = false;
        showQueuedBanner();
      }, 330);
    }, 1500);
  };
  const enqueueBanner = (message: string) => {
    // Incoming KakaoTalk takes priority over social activity, even if a social
    // banner is currently visible. Other social events remain queued.
    if (message.startsWith("KakaoTalk：")) {
      bannerQueue.current.unshift(message);
      if (bannerActive.current && !bannerRefText.current.startsWith("KakaoTalk：")) {
        if (bannerTimer.current) clearTimeout(bannerTimer.current);
        bannerActive.current = false;
        setBanner("");
        lastBannerAt.current = 0;
      }
    } else bannerQueue.current.push(message);
    // Keep recent alerts responsive when mentions arrive faster than banners dismiss.
    if (bannerQueue.current.length > 6) bannerQueue.current.splice(0, bannerQueue.current.length - 6);
    showQueuedBanner();
  };
  useEffect(()=>{
    const onSocial=(event:Event)=>{
      const detail=(event as CustomEvent<{message:string;force?:boolean}>).detail;
      if(!detail?.message)return;
      if(detail.force){
        // Never drop the mysterious account's like/unlike alerts.
        bannerQueue.current.unshift(detail.message);
        showQueuedBanner();
      }else enqueueBanner(detail.message);
    };
    window.addEventListener("gt-social-banner",onSocial);
    return ()=>window.removeEventListener("gt-social-banner",onSocial);
  },[]);
  useEffect(() => () => {
    if (bannerTimer.current) clearTimeout(bannerTimer.current);
  }, []);
  const [contextApp, setContextApp] = useState("");
  const [deviceScale, setDeviceScale] = useState(0.84);
  const shell = useRef<HTMLDivElement>(null);
  const gesture = useRef({ x: 0, y: 0, time: 0, zone: "" });
  const [launchOrigin, setLaunchOrigin] = useState(screenOrigin);

  const beginUnlock = () => {
    setPinError("");
    setQuickCamera(false);
    if (work.phone.passcode) setPinOpen(true);
    else unlock();
  };
  const pressTimer = useRef<ReturnType<typeof setTimeout> | undefined>(
    undefined,
  );
  const gestureConsumed = useRef(false);
  const [pinError, setPinError] = useState("");
  const [folder, setFolder] = useState("");
  const [panel, setPanel] = useState("");
  const [own, setOwn] = useState(() => initialRuntime(work));
  const [ready, setReady] = useState(creator || !!external);
  const [loadError, setLoadError] = useState("");
  const [gtUpdatePrompt, setGtUpdatePrompt] = useState(false);
  useEffect(() => {
    const el = shell.current;
    if (!el) return;
    // Fit against the *actual CSS viewport*, not screen.width/height alone.
    // Some iOS browsers report a wider parent after zoom or after a failed app
    // render. Never let that overflow enlarge the entire simulated phone.
    const fit = () => {
      const viewportWidth = Math.min(
        window.innerWidth || Infinity,
        document.documentElement.clientWidth || Infinity,
      );
      const parentWidth = el.parentElement?.clientWidth || viewportWidth;
      const availableWidth = Math.min(viewportWidth, parentWidth);
      // screen dimensions are stable while the software keyboard is open.
      const screenHeight = Math.max(window.screen.width, window.screen.height);
      const availableHeight = Math.min(screenHeight, window.innerHeight || screenHeight);
      const reservedHeight = creator ? 170 : external ? 150 : 120;
      setDeviceScale(Math.max(0.25, Math.min(
        1,
        (availableWidth - 24) / 407,
        (availableHeight - reservedHeight) / 866,
      )));
    };
    const observer = new ResizeObserver(fit);
    if (el.parentElement) observer.observe(el.parentElement);
    window.addEventListener("resize", fit);
    window.addEventListener("orientationchange", fit);
    fit();
    return () => {
      window.removeEventListener("resize", fit);
      window.removeEventListener("orientationchange", fit);
      observer.disconnect();
    };
  }, [creator, ready]);
  const s = external ?? own;
  // The scripted KakaoTalk inbox belongs to the phone, not the open chat view.
  const kakaoItems = (work.data.kakao ?? []).filter((m) => m.title === "재민형" && m.meta.placeholder !== "true");
  const firstScriptedReply = kakaoItems.findIndex((m) => m.meta.scriptedReply === "true");
  const firstScriptedMessage = kakaoItems.findIndex((m) => m.meta.scriptedDay === "true");
  const initialKakaoCount = firstScriptedMessage >= 0 ? firstScriptedMessage : Math.max(0, firstScriptedReply);
  const day2Ui = s.ui?.calendar ?? {};
  const day2Active = Boolean(day2Ui.gtDay2Active);
  const day3Active = Boolean(day2Ui.gtDay3Active);
  const day2Mode = String(day2Ui.gtDay2Mode || "note");
  const day2ChatCount = Number(day2Ui.gtDay2ChatCount || 0);
  const [day2NoteVisible,setDay2NoteVisible] = useState(true);
  const [day2BannerVisible,setDay2BannerVisible] = useState(false);
  const [day2GateWarning,setDay2GateWarning] = useState(false);
  const [day2NotesListKey,setDay2NotesListKey] = useState(0);
  const day2Choices:number[] = (()=>{try{return JSON.parse(String(day2Ui.gtDay2Choices||"[]"));}catch{return [];}})();
  const day2Set = (patch:Record<string, UiValue>) => {
    const current=runtimeRef.current;
    update({...current,ui:{...current.ui,calendar:{...current.ui?.calendar,...patch}}});
  };
  const kakaoUi = s.ui?.kakao ?? {};
  const gtClock = String(kakaoUi.gtClock || "");
  const deliveredCount = typeof kakaoUi.mymyKktVisible === "number" && kakaoUi.mymyKktVisible >= 0
    ? kakaoUi.mymyKktVisible : initialKakaoCount;
  const kakaoReadCount = typeof kakaoUi.mymyKktReadCount === "number" ? kakaoUi.mymyKktReadCount : Math.max(0, firstScriptedReply);
  const kakaoScriptedUnread = kakaoItems.slice(Math.max(0, kakaoReadCount), deliveredCount)
    .filter((m) => m.meta.scriptedDay === "true" && !m.outgoing).length;
  const readKakaoThreads = Array.isArray(kakaoUi.mymyKktReadThreads) ? kakaoUi.mymyKktReadThreads : [];
  const unreadByThread = new Map<string, number>();
  for (const title of new Set((work.data.kakao ?? []).map(item => item.title))) {
    if (title === "재민형" || title === "해찬형") continue;
    const all = (work.data.kakao ?? []).filter(item => item.title === title && item.meta.placeholder !== "true");
    let cursors:Record<string,number>={};
    try { cursors=JSON.parse(String(kakaoUi.gtExtraCursors || "{}")); } catch {}
    const first=all.findIndex(m=>m.id.startsWith("gt-day1-v3-"));
    const visible=first<0 ? all.length : (cursors[title] ?? first);
    const items=all.slice(0,visible);
    if (readKakaoThreads.includes(title)) {
      let reads:Record<string,number>={};
      try { reads=JSON.parse(String(kakaoUi.mymyKktReadCursors || "{}")); } catch {}
      unreadByThread.set(title,items.slice(reads[title]??visible).filter(m=>!m.outgoing).length);
      continue;
    }
    let trailing = 0;
    for (let i = items.length - 1; i >= 0 && !items[i].outgoing; i--) trailing++;
    unreadByThread.set(title, trailing);
  }
  // Haechan delivery and unread cursors are scoped to the same persisted KakaoTalk UI state.
  const hcItems = (work.data.kakao ?? []).filter(m => m.title === "해찬형" && m.meta.placeholder !== "true");
  const hcFirstScripted = hcItems.findIndex(m => m.meta.scriptedDay === "true");
  const hcStartIndex = hcFirstScripted < 0 ? -1 : hcFirstScripted;
  const hcVisibleCount = typeof kakaoUi.mymyHaechanCount === "number" && kakaoUi.mymyHaechanCount >= 0
    ? kakaoUi.mymyHaechanCount : Math.max(0, hcStartIndex);
  const hcReadCursors: Record<string, number> = (() => {
    try { return JSON.parse(String(kakaoUi.mymyKktReadCursors || "{}")); }
    catch { return {}; }
  })();
  const hcReadFrom = Math.max(0, hcReadCursors["해찬형"] ?? hcVisibleCount);
  const hcUnread = hcItems.slice(hcReadFrom, hcVisibleCount).filter(m => !m.outgoing).length +
    (!day2Active && !readKakaoThreads.includes("해찬형") && hcReadCursors["해찬형"] === undefined ? (() => {
      let n = 0;
      for (let i = Math.min(hcVisibleCount, hcItems.length) - 1; i >= 0 && !hcItems[i].outgoing; i--) n++;
      return n;
    })() : 0);
  const contSceneForUnread = day2Scenes[Number(day2Ui.gtContStage ?? -1)];
  const day2JaeminUnread = day2Active && !day3Active ? (3 - Math.min(3,Number(kakaoUi.gtDay2OpeningRead||0))) + day2Chat.slice(Math.max(0,Number(kakaoUi.gtDay2ReadCount||0)), Number(kakaoUi.gtDay2Visible||0)).filter(([who])=>who!=="朴志晟").length : 0;
  const contUnread = day2Active && contSceneForUnread ? contSceneForUnread.lines.slice(Math.max(0,Number(kakaoUi.gtContRead||0)),Number(kakaoUi.gtContVisible||0)).filter(([who])=>who!=="朴志晟").length : 0;
  const kakaoUnread = day2Active
    ? day2JaeminUnread + contUnread
    : kakaoScriptedUnread + hcUnread + [...unreadByThread.values()].reduce((sum, n) => sum + n, 0);
  const unreadForApp = (id: string) => id === "kakao" ? kakaoUnread :
    (work.data[id] ?? []).filter(item => !item.outgoing && !item.read && !s.read.includes(item.id)).length;

  const runtimeRef = useRef(s);
  runtimeRef.current = s;
  const update = (next: Runtime) => {
    runtimeRef.current = next;
    setOwn(next);
    onRuntime?.(next);
  };
  // Keep @ mentions running while the phone is mounted, regardless of the open app.
  // The timer never lives in the Weibo component, so app switches cannot stop it.
  useEffect(() => {
    if (creator || !ready) return;
    let active = true;
    let timeout: ReturnType<typeof setTimeout> | undefined;
    const tick = () => {
      if (!active) return;
      const current = runtimeRef.current;
      const cycle = current.ui?.calendar?.gtDay3Active ? 3 : current.ui?.calendar?.gtDay2Active ? 2 : 1;
      const result = appendWeiboMention(current.ui?.weibo ?? {}, cycle);
      update({...current, ui:{...current.ui, weibo:result.ui}});
      enqueueBanner(`微博：${result.notification}`);
      schedule();
    };
    const schedule = () => {timeout = window.setTimeout(tick, 7000);};
    schedule();
    return () => {active = false; if(timeout !== undefined)window.clearTimeout(timeout);};
  }, [creator, ready]);

  useEffect(() => {
    let active = true;
    if (creator || external) return;
    void db.saves
      .get(work.id)
      .then((saved) => {
        if (!active) return;
        if (saved) {
          const previous = saved.state;
          const previousVersion = String(previous.ui?.kakao?.gtStoryVersion || "");
          setOwn({...previous, revision: work.updatedAt});
          if (previousVersion !== BUILD_FINGERPRINT) setGtUpdatePrompt(true);
        } else {
          const fresh = dispatch(work, initialRuntime(work), "start");
          setOwn({...fresh,ui:{...fresh.ui,kakao:{...fresh.ui?.kakao,gtStoryVersion:BUILD_FINGERPRINT}}});

        }
        setReady(true);
      })
      .catch(() => {
        setOwn(dispatch(work, initialRuntime(work), "start"));
        setLoadError("无法读取本地存档。本次仍可游玩。");
        setReady(true);
      });
    return () => {
      active = false;
    };
  }, [work.id, work.updatedAt, creator, external]);
  useEffect(() => {
    if (!creator && !external && ready)
      void db.saves
        .put({ id: work.id, state: own })
        .catch(() => setLoadError("存档失败，请检查浏览器存储权限。"));
  }, [own, creator, work.id, external, ready]);
  useEffect(() => {
    if (creator || !ready) return;
    const interval = setInterval(() => {
      const previous = runtimeRef.current;
      const next = advance(work, previous, 1000);
      runtimeRef.current = next;
      const changed =
        next.time !== previous.time ||
        next.trace.join() !== previous.trace.join() ||
        (next.scheduled?.length ?? 0) !== (previous.scheduled?.length ?? 0) ||
        (next.scheduled?.length ?? 0) > 0 ||
        Math.floor((next.elapsedMs ?? 0) / 5000) !==
          Math.floor((previous.elapsedMs ?? 0) / 5000);
      if (changed) update(next);
    }, 1000);
    return () => clearInterval(interval);
  }, [creator, ready, work.id, work.updatedAt]);
  // Deliver only scripted incoming lines; stop at each required player reply.
  // Persist the cursor with the existing save system so reloading cannot resend messages.
  useEffect(() => {
    if (creator || !ready || locked || day2Active || firstScriptedReply < 0) return;
    const cursor = deliveredCount;
    const next = kakaoItems[cursor];
    if (!next || next.meta.scriptedDay !== "true" || next.meta.scriptedReply === "true") return;
    if (next.id.startsWith("gt-day1-v3-") && (next.meta.gtStage === "jaemin-chat-1" ? gtClock !== "23:29" : gtClock !== "23:59")) return;
    const timer = window.setTimeout(() => {
      const current = runtimeRef.current;
      const ui = current.ui?.kakao ?? {};
      const now = typeof ui.mymyKktVisible === "number" && ui.mymyKktVisible >= 0
        ? ui.mymyKktVisible : initialKakaoCount;
      if (now !== cursor) return;
      const inChat = document.querySelector('.mymy-kakao .msgs') !== null;
      update({
        ...current,
        ui: { ...current.ui, kakao: { ...ui, mymyKktVisible: cursor + 1,
          ...(inChat ? { mymyKktReadCount: cursor + 1 } : {}),
          ...(next.body.trim() === "睡着了吗？" && next.id.startsWith("gt-day1-v3-")
            ? { gtLastMessageDelivered: true } : {}) } },
      });
      if (!inChat && !locked && work.phone.notifications && !next.outgoing) {
        enqueueBanner(`KakaoTalk：재민형：${next.body}`);
      }
    }, cursor === initialKakaoCount ? 2000 : 1400);
    return () => window.clearTimeout(timer);
  }, [creator, ready, deliveredCount, firstScriptedReply, initialKakaoCount, locked, work.id, gtClock]);
  // Haechan uses the same paced background delivery as Jaemin.
  useEffect(() => {
    if (creator || !ready || locked || day2Active || hcStartIndex < 0) return;
    const cursor = hcVisibleCount;
    const next = hcItems[cursor];
    if (!next || next.meta.scriptedDay !== "true" || next.meta.scriptedReply === "true") return;
    if (next.id.startsWith("gt-day1-v3-") && (next.meta.gtStage === "haechan-chat-1" ? gtClock !== "20:12" : gtClock !== "20:28")) return;
    if (next.meta.delayedFollowup === "true" && !kakaoUi.mymyHaechanFinishedAt) return;
    const timer = window.setTimeout(() => {
      const current = runtimeRef.current;
      const ui = current.ui?.kakao ?? {};
      const now = typeof ui.mymyHaechanCount === "number" && ui.mymyHaechanCount >= 0 ? ui.mymyHaechanCount : hcStartIndex;
      if (now !== cursor) return;
      const inChat = document.querySelector('.mymy-kakao .msgs[data-thread="해찬형"]') !== null;
      update({...current, ui:{...current.ui, kakao:{...ui, mymyHaechanCount:cursor+1,
        ...(inChat ? {mymyKktReadCursors:JSON.stringify({...(() => { try { return JSON.parse(String(ui.mymyKktReadCursors || "{}")); } catch { return {}; } })(), "해찬형":cursor+1})} : {})}}});
      if (!inChat && !locked && work.phone.notifications && !next.outgoing) enqueueBanner(`KakaoTalk：해찬형：${next.body}`);
    }, next.meta.delayedFollowup === "true" ? Math.max(0, 30000 - (Date.now() - Number(kakaoUi.mymyHaechanFinishedAt || Date.now()))) : 1400);
    return () => window.clearTimeout(timer);
  }, [creator, ready, locked, hcVisibleCount, hcStartIndex, work.id, kakaoUi.mymyHaechanFinishedAt, gtClock]);
  // Day 1 v3 staged conversations. All cursors live in the existing Dexie save.
  const gtExtra: Record<string, number> = (() => { try { return JSON.parse(String(kakaoUi.gtExtraCursors || "{}")); } catch { return {}; } })();
  const gtThreads = ["천러", "드림💚"];
  const gtGroup = (title: string) => (work.data.kakao ?? []).filter(m => m.title === title && m.meta.placeholder !== "true");
  const gtCount = (title: string) => { const items = gtGroup(title); const start = items.findIndex(m => m.id.startsWith("gt-day1-v3-")); return gtExtra[title] ?? (start < 0 ? items.length : start); };
  const gtDone = (title: string) => gtCount(title) >= gtGroup(title).length;
  const gtStageDone = (title: string, stage: string, count: number) => {
    const items = gtGroup(title);
    let last = -1;
    for (let i = items.length - 1; i >= 0; i--) {
      if (items[i].meta.gtStage === stage) { last = i; break; }
    }
    return last >= 0 && count > last;
  };
  const gtOldDone = deliveredCount >= (kakaoItems.findIndex(m => m.id.startsWith("gt-day1-v3-")) < 0 ? kakaoItems.length : kakaoItems.findIndex(m => m.id.startsWith("gt-day1-v3-"))) &&
    hcVisibleCount >= (hcItems.findIndex(m => m.id.startsWith("gt-day1-v3-")) < 0 ? hcItems.length : hcItems.findIndex(m => m.id.startsWith("gt-day1-v3-")));
  const gtMailOpened = Boolean(s.ui?.mail?.gtOpened);
  const gtInstagramOpened = Boolean(s.ui?.instagram?.gtOpened || s.ui?.ins?.gtOpened);
  useEffect(() => {
    if (creator || !ready || locked || day2Active) return;
    // Every later stage uses the same persisted 20-second transition gate.
    const transitions = [
      {key:"gtEveningReadyAt",from:"13:56",to:"20:12",done:gtStageDone("천러","chele-chat-1",gtCount("천러")) && gtDone("드림💚") && gtInstagramOpened},
      {key:"gtLateReadyAt",from:"20:28",to:"23:29",done:gtStageDone("해찬형","haechan-chat-2",hcVisibleCount)},
      {key:"gtMidnightReadyAt",from:"23:29",to:"23:59",done:gtStageDone("재민형","jaemin-chat-1",deliveredCount)},
    ];
    const pending=transitions.find(t=>t.from===gtClock && t.done);
    if (!pending) return;
    const current=runtimeRef.current;
    const ui=current.ui?.kakao ?? {};
    if (!ui[pending.key]) {
      update({...current,ui:{...current.ui,kakao:{...ui,[pending.key]:Date.now()}}});
      return;
    }
    const remaining=Math.max(0,20000-(Date.now()-Number(ui[pending.key])));
    const timer=window.setTimeout(()=>{
      const latest=runtimeRef.current;
      if (String(latest.ui?.kakao?.gtClock)!==pending.from) return;
      update({...latest,time:pending.to,ui:{...latest.ui,kakao:{...latest.ui?.kakao,gtClock:pending.to}}});
    },remaining);
    return ()=>window.clearTimeout(timer);
  }, [creator,ready,locked,gtClock,gtInstagramOpened,hcVisibleCount,deliveredCount,JSON.stringify(gtExtra),kakaoUi.gtEveningReadyAt,kakaoUi.gtLateReadyAt,kakaoUi.gtMidnightReadyAt]);
  // The morning Jaemin + Haechan conversations must BOTH finish before the
  // afternoon transition. Save the timer origin so refresh cannot skip it.
  useEffect(() => {
    if (creator || !ready || locked || gtClock || !gtOldDone || kakaoUi.gtAfternoonReadyAt) return;
    const current = runtimeRef.current;
    update({...current,ui:{...current.ui,kakao:{...current.ui?.kakao,gtAfternoonReadyAt:Date.now()}}});
  },[creator,ready,locked,gtClock,gtOldDone,kakaoUi.gtAfternoonReadyAt]);
  useEffect(() => {
    if (creator || !ready || locked || gtClock || !gtOldDone || !kakaoUi.gtAfternoonReadyAt) return;
    const remaining = Math.max(0,20000-(Date.now()-Number(kakaoUi.gtAfternoonReadyAt)));
    const timer = window.setTimeout(()=>{
      const current=runtimeRef.current;
      if (current.ui?.kakao?.gtClock || !current.ui?.kakao?.gtAfternoonReadyAt) return;
      update({...current,time:"13:56",ui:{...current.ui,kakao:{...current.ui?.kakao,gtClock:"13:56"}}});
    },remaining);
    return ()=>window.clearTimeout(timer);
  },[creator,ready,locked,gtClock,gtOldDone,kakaoUi.gtAfternoonReadyAt]);
  useEffect(() => {
    if (creator || !ready || gtClock !== "20:12" || kakaoUi.gtHaechan1FinishedAt || !gtStageDone("해찬형", "haechan-chat-1", hcVisibleCount)) return;
    const current=runtimeRef.current;
    update({...current,ui:{...current.ui,kakao:{...current.ui?.kakao,gtHaechan1FinishedAt:Date.now()}}});
  },[creator,ready,gtClock,hcVisibleCount,kakaoUi.gtHaechan1FinishedAt]);
  useEffect(() => {
    if (creator || !ready || gtClock !== "20:12" || !kakaoUi.gtHaechan1FinishedAt) return;
    const remaining=Math.max(0,20000-(Date.now()-Number(kakaoUi.gtHaechan1FinishedAt)));
    const timer=window.setTimeout(()=>{
      const current=runtimeRef.current;
      if (String(current.ui?.kakao?.gtClock) !== "20:12") return;
      update({...current,time:"20:28",ui:{...current.ui,kakao:{...current.ui?.kakao,gtClock:"20:28"}}});
    },remaining);
    return ()=>window.clearTimeout(timer);
  },[creator,ready,gtClock,kakaoUi.gtHaechan1FinishedAt]);
  // Schedule each conversation independently: the group notification must not
  // cancel the Chenle timer, and opening one thread must not stall the other.
  useEffect(() => {
    if (creator || !ready || locked || !gtClock) return;
    const timers: number[] = [];
    for (const title of gtThreads) {
      const items = gtGroup(title);
      const cursor = gtCount(title);
      const next = items[cursor];
      if (!next || next.meta.scriptedReply === "true") continue;
      if (title === "천러" && (!gtMailOpened || gtClock !== "13:56")) continue;
      if (title === "드림💚" && !kakaoUi.gtGroupTriggered) continue;
      const timer = window.setTimeout(() => {
        const current = runtimeRef.current;
        const ui = current.ui?.kakao ?? {};
        let cursors: Record<string, number> = {};
        try { cursors = JSON.parse(String(ui.gtExtraCursors || "{}")); } catch { /* old save */ }
        const start = items.findIndex(m => m.id.startsWith("gt-day1-v3-"));
        if ((cursors[title] ?? start) !== cursor) return;
        update({...current, ui:{...current.ui, kakao:{...ui,
          gtExtraCursors:JSON.stringify({...cursors,[title]:cursor+1})}}});
        if (!document.querySelector(`.mymy-kakao .msgs[data-thread="${title}"]`) && work.phone.notifications)
          enqueueBanner(`KakaoTalk：${title}：${next.body}`);
      }, title === "드림💚" && cursor === items.findIndex(m => m.id.startsWith("gt-day1-v3-")) ? 500 : 1400);
      timers.push(timer);
    }
    return () => timers.forEach(timer => window.clearTimeout(timer));
  },[creator,ready,locked,gtClock,gtMailOpened,kakaoUi.gtGroupTriggered,JSON.stringify(gtExtra)]);
  // Trigger the group on Jisung's outgoing “啊可是”, not on a received line.
  useEffect(() => {
    if (creator || !ready || day2Active || !gtClock || kakaoUi.gtGroupTriggered) return;
    const items = gtGroup("천러");
    const last = items.slice(0, gtCount("천러")).at(-1);
    if (last?.outgoing !== true || last.body.trim() !== "啊可是") return;
    const current = runtimeRef.current;
    update({...current,ui:{...current.ui,kakao:{...current.ui?.kakao,gtGroupTriggered:true}}});
  },[creator,ready,gtClock,JSON.stringify(gtExtra),kakaoUi.gtGroupTriggered]);
  // Day 2 uses the existing KakaoTalk skin, reply presets, contacts and notification queue.
  const contStage = Number(day2Ui.gtContStage ?? -1);
  const contVisible = Number(kakaoUi.gtContVisible || 0);
  const contStarted = Boolean(day2Ui.gtContStarted);
  const contScene = contStage >= 0 && (day3Active || contStage < day2SceneBoundary) ? day2Scenes[contStage] : undefined;
  useEffect(()=>{ if(!day2Active || Number(kakaoUi.gtContStage??-1)===contStage)return; const current=runtimeRef.current; update({...current,ui:{...current.ui,kakao:{...current.ui?.kakao,gtContStage:contStage}}}); },[day2Active,contStage,kakaoUi.gtContStage]);
  // Scene cursor, visibility and timing are persisted with the same runtime save.
  useEffect(()=>{
    if (!day2Active || locked || !ready || !contScene || contStarted) return;
    const timer=window.setTimeout(()=>{
      const current=runtimeRef.current;
      if(Number(current.ui?.calendar?.gtContStage ?? -1)!==contStage)return;
      update({...current,time:contScene.time,ui:{...current.ui,calendar:{...current.ui?.calendar,gtContStarted:true}}});
    },contScene.wait);
    return()=>window.clearTimeout(timer);
  },[day2Active,locked,ready,contStage,contStarted]);
  useEffect(()=>{
    if (!day2Active || locked || !ready || !contScene || !contStarted || contVisible>=contScene.lines.length)return;
    const [who,line]=contScene.lines[contVisible];
    if(who==='朴志晟')return;
    const timer=window.setTimeout(()=>{
      const current=runtimeRef.current;const k=current.ui?.kakao??{};
      if(Number(k.gtContVisible||0)!==contVisible)return;
      update({...current,ui:{...current.ui,kakao:{...k,gtContVisible:contVisible+1}}});
      if(!document.querySelector(`.mymy-kakao .msgs[data-thread="${contScene.thread}"]`))enqueueBanner(`KakaoTalk：${contScene.thread}：${line}`);
    },day3Active && contStage===day2SceneBoundary+1 && contVisible===day3PauseBeforeLine ? 5000 : contScene.id === "renjun-after-haechan" && contVisible === 0 ? 0 : contStage===2 && contVisible===0 ? 5000 : 1200);
    return()=>window.clearTimeout(timer);
  },[day2Active,day3Active,locked,ready,contStage,contVisible,contStarted]);
  useEffect(()=>{
    if (!day2Active || !contScene || !contStarted || contVisible<contScene.lines.length)return;
    const timer=window.setTimeout(()=>{
      const current=runtimeRef.current;
      if(Number(current.ui?.calendar?.gtContStage??-1)!==contStage)return;
      update({...current,ui:{...current.ui,calendar:{...current.ui?.calendar,gtContStage:contStage+1,gtContStarted:false},kakao:{...current.ui?.kakao,gtContStage:contStage+1,gtContVisible:0,gtContRead:0}}});
    },150);
    return()=>window.clearTimeout(timer);
  },[day2Active,contStage,contVisible,contStarted]);
  const day2Visible = Number(kakaoUi.gtDay2Visible || 0);
  useEffect(()=>{
    if(!day2Active || day3Active || locked || !ready || !day2Ui.gtDay2Notified || day2Visible>=day2Chat.length)return;
    const next=day2Chat[day2Visible];
    if(next[0]==="朴志晟")return;
    const timer=window.setTimeout(()=>{
      const current=runtimeRef.current;
      const k=current.ui?.kakao??{};
      if(Number(k.gtDay2Visible||0)!==day2Visible)return;
      update({...current,ui:{...current.ui,kakao:{...k,gtDay2Visible:day2Visible+1}}});
      if(!document.querySelector('.mymy-kakao .msgs[data-thread="재민형"]'))enqueueBanner(`KakaoTalk：재민형：${next[1]}`);
    },1400);
    return()=>window.clearTimeout(timer);
  },[day2Active,locked,ready,day2Visible,day2Ui.gtDay2Notified]);
  useEffect(()=>{
    if(!day2Active || day3Active || locked || day2Ui.gtDay2Notified || app!=="notes" || !day2NoteVisible)return;
    const timer=window.setTimeout(()=>{
      const current=runtimeRef.current;
      update({...current,ui:{...current.ui,calendar:{...current.ui?.calendar,gtDay2Notified:true},kakao:{...current.ui?.kakao,gtDay2Visible:0,gtDay2ReadCount:0}}});
      enqueueBanner("KakaoTalk：재민형：志晟啊");
    },4000);
    return()=>window.clearTimeout(timer);
  },[day2Active,locked,day2Ui.gtDay2Notified,app,day2NoteVisible]);
  useEffect(()=>{
    if(!day2Active || day3Active || day2Ui.gtDay2ChatDone || !day2Ui.gtDay2Notified || day2Visible<day2Chat.length)return;
    const timer=window.setTimeout(()=>{
      const current=runtimeRef.current;
      update({...current,ui:{...current.ui,calendar:{...current.ui?.calendar,gtDay2ChatDone:true}}});
      setApp("notes");setDay2NoteVisible(true);
    },2000);
    return()=>window.clearTimeout(timer);
  },[day2Active,day2Visible,day2Ui.gtDay2ChatDone]);
  const event = (event: string, target: string) => {
    if (!creator) update(dispatch(work, runtimeRef.current, event, target));
  };
  const captureApp = () => {
    if (!app) return;
    const current = shell.current?.querySelector<HTMLElement>(".app-screen");
    if (!current) return;
    const snapshot = current.cloneNode(true) as HTMLElement;
    snapshot.style.transform = "none";
    snapshot.style.opacity = "1";
    snapshot.style.filter = "none";
    snapshot.style.borderRadius = "0";
    snapshot.querySelectorAll("audio").forEach((el) => el.remove());
    snapshot.querySelectorAll("video").forEach((el) => {
      el.removeAttribute("autoplay");
      el.removeAttribute("src");
    });
    snapshot.querySelectorAll("[id]").forEach((el) => el.removeAttribute("id"));
    appSnapshots.current.set(app, snapshot);
    for (const id of appSnapshots.current.keys())
      if (!recent.includes(id) && id !== app) appSnapshots.current.delete(id);
  };
  const open = (id: string) => {
    if (!work.apps.some((a) => a.id === id && a.installed)) return;
    setApp(id);
    setKeyboard(false);
    setRecent((v) => [id, ...v.filter((a) => a !== id)].slice(0, 8));
    setFolder("");
    setPanel("");
    onOpen?.(id);
    onDemandApp?.(id);
    event("openApp", id);
    if (["mail","instagram","ins","x","twitter","notes"].includes(id)) {
      const current=runtimeRef.current;update({...current,ui:{...current.ui,[id]:{...current.ui?.[id],gtOpened:true}}});
    }
  };
  const installedApps = work.apps.filter((a) => a.installed);
  const apps = installedApps.filter((a) => a.visible);
  const unlock = (pin = "") => {
    if (!work.phone.passcode || pin === work.phone.passcode) {
      setLocked(false);
      setPinOpen(false);
      if (runtimeRef.current.ui?.calendar?.gtDay2Active && !runtimeRef.current.ui?.calendar?.gtDay3Active && !runtimeRef.current.ui?.calendar?.gtDay2Notified) {setApp("notes");setDay2NoteVisible(true);}
      event("password", pin);
    } else {
      setPinError("密码不正确");
      setPinOpen(true);
    }
  };
  useEffect(() => {
    if (app && !work.apps.some((a) => a.id === app && a.installed)) setApp("");
  }, [app, work.apps]);
  const displayTime = creator ? work.phone.time : s.time || work.phone.time;
  const plugin = getApp(app);
  useEffect(() => {
    const count = s.notifications.length;
    if (!locked && work.phone.notifications && count > noticesSeen.current) {
      s.notifications.slice(noticesSeen.current).forEach(enqueueBanner);
    }
    noticesSeen.current = count;
  }, [s.notifications.length, locked, work.phone.notifications]);
  const dismissNotice = (index: number) =>
    update({
      ...runtimeRef.current,
      notifications: runtimeRef.current.notifications.filter(
        (_, i) => i !== index,
      ),
    });
  if (!ready) return <div className="phone-loading">正在恢复进度…</div>;
  return (
    <div
      ref={shell}
      style={{ "--phone-scale": deviceScale } as CSSProperties}
      className={`phone-shell ios18 ${work.phone.theme === "dark" ? "dark-phone" : ""}`}
    >
      <KeyboardContext.Provider value={setKeyboard}>
        <div
          className={`phone-screen wallpaper-${work.phone.wallpaper} ${locked ? "is-locked" : ""} ${app ? "in-app" : ""} ${keyboard ? "keyboard-open" : ""}`}
          data-app={app}
          onDragStart={(e) => e.preventDefault()}
          onPointerDown={(e) => {
            gestureConsumed.current = false;
            const button = (e.target as HTMLElement).closest<HTMLElement>(
              "[data-app-id]",
            );
            if (button) {
              pressTimer.current = setTimeout(() => {
                gestureConsumed.current = true;
                setContextApp(button.dataset.appId || "");
              }, 550);
            }
            const box = e.currentTarget.getBoundingClientRect(),
              x = (e.clientX - box.left) / deviceScale,
              y = (e.clientY - box.top) / deviceScale;
            gesture.current = {
              x,
              y,
              time: Date.now(),
              zone: y < 58 ? "top" : y > 818 ? "bottom" : locked ? "lock" : "",
            };
          }}
          onPointerMove={(e) => {
            if (Math.abs(e.movementX) > 5 || Math.abs(e.movementY) > 5)
              clearTimeout(pressTimer.current);
          }}
          onPointerCancel={() => clearTimeout(pressTimer.current)}
          onPointerUp={(e) => {
            clearTimeout(pressTimer.current);
            const box = e.currentTarget.getBoundingClientRect(),
              y = (e.clientY - box.top) / deviceScale,
              g = gesture.current;
            const dy = y - g.y;
            if (g.zone === "top" && dy > 65)
              setPanel(g.x > 230 ? "control" : "notification");
            else if ((g.zone === "bottom" || g.zone === "lock") && dy < -55) {
              gestureConsumed.current = true;
              if (!locked) captureApp();
              setKeyboard(false);
              if (panel) {
                setPanel("");
              } else if (locked) {
                beginUnlock();
              } else if (g.zone === "bottom" && Date.now() - g.time > 450) {
                captureApp();
                setPanel("switcher");
              } else {
                setApp("");
                setPanel("");
                setFolder("");
              }
            }
          }}
          onClickCapture={(e) => {
            const target = (e.target as HTMLElement).closest(
              ".home-app-grid button,.dock button",
            );
            if (target) {
              setLaunchOrigin(
                readLauncherOrigin(target as HTMLElement, e.currentTarget),
              );
            }
          }}
        >
          <div className="wallpaper-orb orb-one" />
          <div className="wallpaper-orb orb-two" />
          <div className="status-bar">
            <button
              onClick={() =>
                setPanel(panel === "notification" ? "" : "notification")
              }
              className="status-time"
              aria-label="通知中心"
            >
              {displayTime}
              <StatusGlyph kind="silent" />
            </button>
            <div className="dynamic-island" />
            <button
              className="signals"
              onClick={() => setPanel(panel === "control" ? "" : "control")}
              aria-label="控制中心"
            >
              <StatusGlyph kind="cellular" />
              <StatusGlyph kind="wifi" />
              <span
                className={`ios-battery${work.phone.battery <= 20 ? " low-battery" : ""}`}
              >
                <span style={{ width: `${work.phone.battery}%` }} />
                <b>{work.phone.battery}</b>
              </span>
            </button>
          </div>
          <AnimatePresence mode="wait">
            {locked && !(quickCamera && app === "camera") ? (
              <DeviceLock
                work={
                  s.date
                    ? { ...work, phone: { ...work.phone, date: s.date } }
                    : work
                }
                time={displayTime}
                notices={s.notifications}
                onDismiss={dismissNotice}
                pinOpen={pinOpen}
                setPinOpen={setPinOpen}
                error={pinError}
                onUnlock={unlock}
                onLight={() => setPanel("light")}
                onCamera={() => {
                  setQuickCamera(true);
                  open("camera");
                }}
              />
            ) : app && app !== "appstore" ? (
              <AppWindow
                key={app==="notes" ? `${app}-${day2NotesListKey}` : app}
                className={`app-screen engine-${plugin.engine} skin-${app}`}
                creator={creator}
                origin={launchOrigin}
              >
                {loadingApps?.includes(app) ? <div role="status" className="gt-deferred-loading">正在准备此应用的内容…</div> : <AppContent
                  app={plugin}
                  name={
                    work.apps.find((a) => a.id === app)?.name ?? plugin.name
                  }
                  items={[
                    ...(day2Active && app==="notes" ? [
                      ...(work.data.notes ?? []).filter(item=>!item.body.includes("梦里渽民哥是律师")),
                      ...(work.data.notes?.[0] ? [{...work.data.notes[0],id:"gt-day2-magic-note",title:"梦见了渽民哥是魔法师",body:"为期又是30天，还是很长的梦，还是渽民哥。这次依然有系统，系统还是让我攻略他，告诉我，没有达到100%好感度我就会死\n这系统骗人，根本不是这样",time:"2026-10-22 07:23"}] : []),
                    ] : day2Active && (app==="twitter" || app==="x") ? [
                      ...(() => { const old = work.data[app] ?? []; const added = day2XPosts.map(post => itemSchema.parse(post)); return old.length ? [old[0],...added.slice(0,1),...old.slice(1,Math.max(1,Math.ceil(old.length/3))),...added.slice(1,2),...old.slice(Math.max(1,Math.ceil(old.length/3)),Math.max(1,Math.ceil(old.length*2/3))),...added.slice(2,3),...old.slice(Math.max(1,Math.ceil(old.length*2/3))),...added.slice(3)] : added; })(),
                    ] : day3Active && app==="kakao" ? [
                      ...(work.data.kakao??[]).filter(message=>{const date=String(message.time||'').slice(0,10);if(date!=="2026-10-22")return true;const clock=String(message.time||'').match(/(?:^|\s)(\d{2}:\d{2})(?::\d{2})?$/)?.[1];return Boolean(clock&&clock<"07:23");}),
                      ...(["志晟啊","看你有黑眼圈了","没休息好吗？"].map((line,i)=>({...((work.data.kakao??[]).find(m=>m.title==="재민형")??(work.data.kakao??[])[0]),id:`gt-day3-opening-${i}`,title:"재민형",body:line,time:"2026-10-22 07:23",outgoing:false,meta:{scriptedDay:"true",gtStage:"day3-opening"}}))),
                      ...day2Scenes.flatMap((scene,sceneIndex)=>sceneIndex<day2SceneBoundary||sceneIndex>contStage?[]:scene.lines.map(([who,line],i)=>{const contact=who==='罗渽民'?'재민형':who==='李楷灿'?'해찬형':who==='钟辰乐'?'천러':who==='李帝努'?'제노형':who==='黄仁俊'?'RJ':who;const base=(work.data.kakao??[]).find(m=>m.title===contact&&!m.outgoing)??(work.data.kakao??[])[0];return {...base,id:`gt-cont-${sceneIndex}-${i}`,title:scene.thread,body:line,time:`2026-10-22 ${scene.time}`,sender:who==='朴志晟'?'朴志晟':contact,avatar:who==='朴志晟'?'':base?.avatar,outgoing:who==='朴志晟',meta:{...base?.meta,scriptedDay:'true',scriptedReply:who==='朴志晟'?'true':'false',gtStage:'day3-cont'}};})),
                    ] : day2Active && app==="kakao" ? [
                      // Day 2 is a second iteration of October 22. Preserve the
                      // historical messages before 07:23 for every thread, but hide
                      // Day 1 messages at and after 07:23. Keep source data untouched.
                      ...(work.data.kakao ?? []).filter(message => {
                        const date = String(message.time || "").slice(0, 10);
                        if (date !== "2026-10-22") return true;
                        const clock = String(message.time || "").match(/(?:^|\s)(\d{2}:\d{2})(?::\d{2})?$/)?.[1];
                        return Boolean(clock && clock < "07:23");
                      }),
                      ...(["志晟啊","看你有黑眼圈了","没休息好吗？"].map((line,i)=>({...((work.data.kakao??[]).find(m=>m.id===`day1-00${i+1}`)??(work.data.kakao??[]).find(m=>m.title==="재민형")??(work.data.kakao??[])[0]),id:`gt-day2-opening-${i}`,title:"재민형",body:line,time:"2026-10-22 07:23",outgoing:false,meta:{scriptedDay:"true",gtStage:"day2-opening"}}))),
                      ...day2Scenes.flatMap((scene,sceneIndex)=>sceneIndex>contStage?[]:scene.lines.map(([who,line],i)=>{const contact=who==='罗渽民'?'재민형':who==='李楷灿'?'해찬형':who==='钟辰乐'?'천러':who==='李帝努'?'제노형':who==='黄仁俊'?'RJ':who;const base=(work.data.kakao??[]).find(m=>m.title===contact&&!m.outgoing)??(work.data.kakao??[]).find(m=>m.title===scene.thread)??(work.data.kakao??[])[0];return {...base,id:`gt-cont-${sceneIndex}-${i}`,title:scene.thread,body:line,time:`2026-10-22 ${scene.time}`,sender:who==='朴志晟'?'朴志晟':contact,avatar:who==='朴志晟'?'':base?.avatar,outgoing:who==='朴志晟',meta:{...base?.meta,scriptedDay:'true',scriptedReply:who==='朴志晟'?'true':'false',gtStage:'day2-cont'}};})),
                      ...day2Chat.map(([who,line],i)=>({...((work.data.kakao??[]).find(m=>m.title==="재민형")??(work.data.kakao??[])[0]),id:`gt-day2-jaemin-${i}`,title:"재민형",body:line,time:"2026-10-22 07:23",sender:who,outgoing:who==="朴志晟",meta:{scriptedDay:"true",scriptedReply:who==="朴志晟"?"true":"false",gtStage:"day2-jaemin"}})),
                    ] : (work.data[app] ?? [])),
                    ...(s.messages[app] ?? []),
                  ]}
                  creator={creator}
                  state={s}
                  onRead={(id) => {if(day2Active && id==="gt-day2-magic-note")setDay2NoteVisible(true);event("read", id);}}
                  onEdit={(item) => onEdit?.(app, item)}
                  onAdd={() => onAdd?.(app)}
                  onBack={() => {if(day2Active && app==="notes")setDay2NoteVisible(false);setApp("");}}
                  onSettings={onSettings}
                  onUi={(key, value) => {
                    if (key === "gtGateReady" && value === true) { const current=runtimeRef.current; update({...current,ui:{...current.ui,calendar:{...current.ui?.calendar,gtGateReady:true}}}); return; }
                    if (key === "gtTomorrow" && value === true && !day2Active) {
                      const current=runtimeRef.current;

                      update({...current,read:current.read.filter(id=>id!=="mail-mystery-1"),ui:{...current.ui,calendar:{...current.ui?.calendar,gtTomorrow:false,gtGateReady:true,gtDay2Active:true,gtDay3Active:false,gtDay2Mode:"transition",gtDay2ChatCount:0,gtDay2Choices:"[]",gtDay2ChatDone:false,gtDay2Notified:false},kakao:{...current.ui?.kakao,gtDay2Visible:0,gtDay2ReadCount:0,gtDay2OpeningRead:0,mymyKktReadThreads:current.ui?.kakao?.mymyKktReadThreads ?? [],mymyKktReadCursors:current.ui?.kakao?.mymyKktReadCursors ?? "{}"},mail:{...current.ui?.mail,gtOpened:false}}});
                      window.setTimeout(()=>{const latest=runtimeRef.current;update({...latest,time:"07:23",date:"2026-10-22",ui:{...latest.ui,calendar:{...latest.ui?.calendar,gtDay2Mode:"note"}}});setApp("");setLocked(true);setDay2NoteVisible(true);},1400);
                      return;
                    }
                    if (key === "gtDay3Start" && value === true && day2Active && !day3Active && Number(runtimeRef.current.ui?.calendar?.gtContStage??-1)>=day2SceneBoundary) {
                      const old=runtimeRef.current;const oldK=old.ui?.kakao??{};
                      update({...old,read:old.read.filter(id=>id!=="mail-mystery-1"),ui:{...old.ui,calendar:{...old.ui?.calendar,gtDay3Active:true,gtDay2Mode:"transition",gtContStage:day2SceneBoundary,gtContStarted:false},kakao:{...oldK,gtContStage:day2SceneBoundary,gtContVisible:0,gtContRead:0,gtDay2OpeningRead:3,gtDay2Visible:0,gtDay2ReadCount:0},mail:{...old.ui?.mail,gtOpened:false}}});
                      window.setTimeout(()=>{const latest=runtimeRef.current;update({...latest,date:"2026-10-22",time:"07:49",ui:{...latest.ui,calendar:{...latest.ui?.calendar,gtDay2Mode:"day3"}}});setApp("");setLocked(true);},1400);
                      return;
                    }
                    if (key === "gtDay2Continue" && value === true && day2Active) {
                      // The end screen is only a temporary detour; keep the save unchanged.
                      setApp("");
                      return;
                    }
                    if (key === "gtDay2Reset" && value === true && day2Active) {
                      // Re-enter the second October 22 from its lock screen. Use a fresh
                      // Day 2 runtime so no old chat cursors, read flags or scene timers
                      // leak into the new run. The completed Day 1 gate remains unlocked.
                      const fresh = dispatch(work, initialRuntime(work), "start");
                      update({...fresh,date:"2026-10-22",time:"07:23",ui:{...fresh.ui,
                        calendar:{...fresh.ui?.calendar,gtGateReady:true,gtTomorrow:false,
                          gtDay2Active:true,gtDay3Active:false,gtDay2Mode:"note",gtDay2ChatCount:0,
                          gtDay2Choices:"[]",gtDay2ChatDone:false,gtDay2Notified:false,
                          gtDay2NoteComplete:false,gtContStage:-1,gtContStarted:false},
                        kakao:{...fresh.ui?.kakao,gtStoryVersion:BUILD_FINGERPRINT,
                          gtDay2Visible:0,gtDay2ReadCount:0,gtDay2OpeningRead:0,
                          gtContStage:-1,gtContVisible:0,gtContRead:0},
                        mail:{...fresh.ui?.mail,gtOpened:false}}});
                      setApp("");setLocked(true);setDay2NoteVisible(true);
                      setDay2NotesListKey(n=>n+1);
                      return;
                    }
                    if (key === "gtRestart" && value === true) {
                      const fresh = dispatch(work, initialRuntime(work), "start");
                      update(fresh);
                      setApp(""); setLocked(true);
                      // Save the fresh runtime rather than deleting the just-reset save.
                      return;
                    }
                    const current = runtimeRef.current;
                    update(
                      dispatch(
                        work,
                        {
                          ...current,
                          ui: {
                            ...current.ui,
                            [app]: { ...current.ui?.[app], [key]: value },
                          },
                        },
                        "variable",
                        `ui:${app}:${key}`,
                      ),
                    );
                  }}
                  work={work}
                />}
              </AppWindow>
            ) : (
              <HomeLauncher
                key={
                  "home-" + homeRequest + (app === "appstore" ? "store" : "")
                }
                storeOpen={app === "appstore"}
                closeStore={() => setApp("")}
                work={work}
                layout={deviceLayout.layout}
                change={deviceLayout.change}
                importLayout={deviceLayout.importLayout}
                error={deviceLayout.error}
                open={open}
                onFolder={setFolder}
                search={() => setPanel("search")}
                time={displayTime}
                unread={unreadForApp}
                icon={(a, small) => (
                  <AppIcon
                    unread={unreadForApp(a.id)}
                    key={a.id}
                    id={a.id}
                    name={small ? undefined : a.name}
                    small={small}
                    custom={a.icon}
                    date={s.date || work.phone.date}
                    time={s.time}
                  />
                )}
                clearApp={(id) =>
                  update({
                    ...runtimeRef.current,
                    messages: Object.fromEntries(
                      Object.entries(runtimeRef.current.messages).filter(
                        ([app]) => app !== id,
                      ),
                    ),
                  })
                }
              />
            )}
          </AnimatePresence>
          {day2Active && !day3Active && !locked && app==="notes" && day2NoteVisible && (
            <Day2Experience
              mode="note"
              chatCount={day2Ui.gtDay2ChatDone ? day2Chat.length : 0}
              choices={day2Choices}
              onChatCount={()=>{}}
              onChoice={(i,v)=>{const next=[...day2Choices];next[i]=v;day2Set({gtDay2Choices:JSON.stringify(next)});}}
              onChatFinished={()=>{}}
              onNoteFinished={()=>{
                const current=runtimeRef.current;
                if(current.ui?.calendar?.gtDay2NoteComplete)return;
                update({...current,time:'07:36',ui:{...current.ui,calendar:{...current.ui?.calendar,gtDay2NoteComplete:true,gtContStage:0,gtContStarted:false},kakao:{...current.ui?.kakao,gtContStage:0,gtContVisible:0,gtContRead:0}}});
              }}
              noteFinished={Boolean(day2Ui.gtDay2NoteComplete)}
              onExit={()=>{setDay2NoteVisible(false);setDay2NotesListKey(n=>n+1);}}
            />
          )}
          {folder && (
            <div className="folder-overlay" onClick={() => setFolder("")}>
              <h2>{folder}</h2>
              <div className="folder-apps" onClick={(e) => e.stopPropagation()}>
                {apps
                  .filter((a) => a.folder === folder)
                  .map((a) => (
                    <button key={a.id} onClick={() => open(a.id)}>
                      <AppIcon id={a.id} name={a.name} custom={a.icon} unread={unreadForApp(a.id)} />
                    </button>
                  ))}
              </div>
              <button className="glass-btn" onClick={() => setFolder("")}>
                关闭文件夹
              </button>
            </div>
          )}
          <GlobalMusicCard />
          {panel === "control" && (
            <ControlCenter
              battery={work.phone.battery}
              network={work.phone.network}
              close={() => setPanel("")}
            />
          )}
          {panel && panel !== "control" && panel !== "switcher" && (
            <div
              className={`system-panel ${panel === "light" ? "flash-on" : ""}`}
            >
              <button className="panel-close" onClick={() => setPanel("")}>
                关闭 <ChevronLeft size={14} />
              </button>
              {panel === "notification" ? (
                <>
                  <h2>通知中心</h2>
                  {work.phone.notifications && s.notifications.length ? (
                    <SystemNotifications
                      notices={s.notifications}
                      apps={work.apps}
                      onOpen={() => {
                        setPanel("");
                        if (locked) beginUnlock();
                        else if (installedApps.some((a) => a.id === "messages"))
                          open("messages");
                      }}
                      onDismiss={dismissNotice}
                    />
                  ) : (
                    <p>没有新通知</p>
                  )}
                </>
              ) : panel === "search" ? (
                <>
                  <h2>搜索 App</h2>
                  <AppSearch apps={installedApps} open={open} />
                </>
              ) : (
                <h2>手电筒已打开</h2>
              )}
            </div>
          )}
          {day2GateWarning && <div className="story-overlay" role="alert" style={{pointerEvents:"none",background:"transparent"}}><p style={{background:"#252525",color:"white",padding:18,borderRadius:12}}>您还没有完成前置剧情，请完成后再试</p></div>}
          {!creator && gtUpdatePrompt && ready && (
            <div className="story-overlay" role="dialog" aria-modal="true" aria-label="剧情更新">
              <h3>《去明日》已更新</h3>
              <p>检测到游戏已更新，是否继续体验？</p>
              <button onClick={() => {
                const current=runtimeRef.current;
                const ui=current.ui ?? {};
                const oldKakao=ui.kakao ?? {};
                const oldCalendar=ui.calendar ?? {};
                const wasFinished=Boolean(oldCalendar.gtTomorrow || oldCalendar.gtGateReady);
                update({...current,ui:{...ui,kakao:{...oldKakao,gtStoryVersion:BUILD_FINGERPRINT},calendar:{...oldCalendar,gtTomorrow:false,gtGateReady:wasFinished}}});
                if(wasFinished && !oldCalendar.gtDay2Active){setApp("calendar");setLocked(false);}
                setGtUpdatePrompt(false);
              }}>是，继续体验</button>
              <button onClick={() => {
                if (!window.confirm("确定从头开始吗？当前进度将被清除。")) return;
                const fresh=dispatch(work,initialRuntime(work),"start");
                update({...fresh,ui:{...fresh.ui,kakao:{...fresh.ui?.kakao,gtStoryVersion:BUILD_FINGERPRINT}}});
                setApp("");setLocked(true);setGtUpdatePrompt(false);
              }}>不，我要从头开始</button>
              <button onClick={() => {
                const current=runtimeRef.current;
                if (!Boolean(current.ui?.calendar?.gtGateReady || current.ui?.calendar?.gtTomorrow || current.ui?.calendar?.gtDay2Active)) { setGtUpdatePrompt(false);setDay2GateWarning(true);window.setTimeout(()=>setDay2GateWarning(false),3500);return; }
                const fresh=dispatch(work,initialRuntime(work),"start");
                const oldUi=current.ui??{};
                const resetKakao={...(fresh.ui?.kakao??{}),gtStoryVersion:BUILD_FINGERPRINT,gtDay2Visible:0,gtDay2ReadCount:0,gtDay2OpeningRead:0,mymyKktReadThreads:fresh.ui?.kakao?.mymyKktReadThreads ?? [],mymyKktReadCursors:fresh.ui?.kakao?.mymyKktReadCursors ?? "{}"};
                const resetCalendar={...(fresh.ui?.calendar??{}),gtTomorrow:false,gtGateReady:true,gtDay2Active:false,gtDay3Active:false,gtDay2Mode:"",gtDay2ChatCount:0,gtDay2Choices:"[]",gtDay2ChatDone:false,gtDay2Notified:false,gtDay2NoteComplete:false};
                update({...fresh,date:"2026-10-22",time:"07:23",read:fresh.read.filter(id=>id!=="mail-mystery-1"),ui:{...fresh.ui,kakao:resetKakao,calendar:resetCalendar,mail:{...fresh.ui?.mail,gtOpened:false}}});
                setApp("calendar");setLocked(false);setDay2NoteVisible(true);setDay2NotesListKey(n=>n+1);setGtUpdatePrompt(false);
              }}>不，我要从day2开始</button>
            </div>
          )}
          {!creator && s.choices.length > 0 && !locked && (
            <div className="story-overlay">
              <span className="eyebrow">故事来到一个岔路口</span>
              <h3>你会如何选择？</h3>
              {s.choices.map((c) => (
                <button
                  key={c.target}
                  onClick={() => update(choose(work, s, c.target))}
                >
                  {c.label}
                  <ArrowUp size={15} />
                </button>
              ))}
            </div>
          )}
          {!creator && s.endings.length > 0 && !locked && (
            <div className="story-overlay ending">
              <span className="eyebrow">ENDING · {s.endings.length}</span>
              <h2>故事在这里停泊。</h2>
              <p>{s.endings[s.endings.length - 1]}</p>
              <button
                onClick={() => {
                  update(dispatch(work, initialRuntime(work), "start"));
                  setApp("");
                  setLocked(true);
                }}
              >
                重新开始
              </button>
            </div>
          )}
          {!creator && s.incomingCall && (
            <div className="incoming-call-screen">
              <small>
                {s.incomingCall.status === "ringing" ? "来电" : "通话中"} ·
                作品内模拟
              </small>
              <div className="incoming-avatar">
                {s.incomingCall.caller.slice(0, 1)}
              </div>
              <h2>{s.incomingCall.caller}</h2>
              {s.incomingCall.status === "answered" &&
                (() => {
                  const record = work.data.phone?.find(
                    (i) => i.id === s.incomingCall?.target,
                  );
                  return record?.kind === "audio" && safeMedia(record.media) ? (
                    <audio controls src={safeMedia(record.media)} />
                  ) : (
                    <p>这是一通虚构来电。</p>
                  );
                })()}
              <div className="incoming-actions">
                <button
                  className="decline-call"
                  onClick={() => {
                    const call = runtimeRef.current.incomingCall;
                    if (call)
                      update(
                        dispatch(
                          work,
                          { ...runtimeRef.current, incomingCall: null },
                          call.status === "ringing"
                            ? "callDeclined"
                            : "callEnded",
                          call.target || call.caller,
                        ),
                      );
                  }}
                >
                  <PhoneIcon size={25} />
                  <span>
                    {s.incomingCall.status === "ringing" ? "拒接" : "挂断"}
                  </span>
                </button>
                {s.incomingCall.status === "ringing" && (
                  <button
                    className="accept-call"
                    onClick={() => {
                      const call = runtimeRef.current.incomingCall;
                      if (call)
                        update(
                          dispatch(
                            work,
                            {
                              ...runtimeRef.current,
                              incomingCall: { ...call, status: "answered" },
                            },
                            "callAnswered",
                            call.target || call.caller,
                          ),
                        );
                    }}
                  >
                    <PhoneIcon size={25} />
                    <span>接听</span>
                  </button>
                )}
              </div>
            </div>
          )}
          {banner && !locked && (
            <button
              className="device-banner"
              onTouchStart={e=>{(e.currentTarget as HTMLElement).dataset.touchStartY=String(e.touches[0]?.clientY||0);}}
              onTouchEnd={e=>{const start=Number((e.currentTarget as HTMLElement).dataset.touchStartY||0);if(start && start-(e.changedTouches[0]?.clientY||0)>25){dismissBanner();(e.currentTarget as HTMLElement).dataset.swiped="true";}}}
              onClick={e => {
                if((e.currentTarget as HTMLElement).dataset.swiped==="true"){(e.currentTarget as HTMLElement).dataset.swiped="";return;}
                dismissBanner();
                if (banner.startsWith("KakaoTalk：")) open("kakao");
                else if(banner.startsWith("微博："))open("weibo");
                else if(banner.startsWith("Instagram："))open("instagram");
                else setPanel("notification");
              }}
            >
              <AppIcon
                id={banner.startsWith("KakaoTalk：") ? "kakao" : banner.startsWith("微博：") ? "weibo" : banner.startsWith("Instagram：") ? "instagram" : notificationContent(banner, work.apps).appId}
                small
              />
              <span>
                <strong>{banner.startsWith("KakaoTalk：") ? `KakaoTalk · ${banner.split("：")[1]}` : banner.startsWith("微博：") ? "微博 · 通知" : banner.startsWith("Instagram：") ? "Instagram · 通知" : notificationContent(banner, work.apps).title}</strong>
                <span>{banner.startsWith("KakaoTalk：") ? banner.replace(/^KakaoTalk：[^：]+：/, "") : banner.startsWith("微博：") ? banner.slice(3) : banner.startsWith("Instagram：") ? banner.slice("Instagram：".length) : notificationContent(banner, work.apps).body}</span>
              </span>
            </button>
          )}
          {panel === "switcher" && (
            <div className="device-switcher">
              <div className="switcher-cards">
                {recent
                  .filter(
                    (id) =>
                      installedApps.some((a) => a.id === id) &&
                      appSnapshots.current.has(id),
                  )
                  .map((id) => (
                    <button
                      className="recent-app-card"
                      key={id}
                      onClick={() => open(id)}
                    >
                      <span className="recent-app-label">
                        <AppIcon id={id} small />
                        <strong>
                          {work.apps.find((a) => a.id === id)?.name}
                        </strong>
                      </span>
                      <span className="recent-app-window">
                        <span
                          className="recent-app-snapshot"
                          aria-hidden="true"
                          inert
                          ref={(el) => {
                            const snapshot = appSnapshots.current.get(id);
                            if (el && snapshot)
                              el.replaceChildren(snapshot.cloneNode(true));
                          }}
                        />
                      </span>
                    </button>
                  ))}
              </div>
              <button className="switcher-done" onClick={() => setPanel("")}>
                完成
              </button>
            </div>
          )}
          {contextApp && (
            <div
              className="home-context-shade"
              onClick={() => setContextApp("")}
            >
              <div className="home-context-menu">
                <AppIcon id={contextApp} />
                <strong>
                  {work.apps.find((a) => a.id === contextApp)?.name}
                </strong>
                <button
                  onClick={() => {
                    open(contextApp);
                    setContextApp("");
                  }}
                >
                  打开 App
                </button>
                <button
                  onClick={() => {
                    setContextApp("");
                    setPanel("search");
                  }}
                >
                  在 App 库中查看
                </button>
                <button onClick={() => setContextApp("")}>取消</button>
              </div>
            </div>
          )}
          {keyboard && <DeviceKeyboard close={() => setKeyboard(false)} />}
          {loadError && (
            <button className="runtime-error" onClick={() => setLoadError("")}>
              {loadError}
            </button>
          )}
          <button
            className="home-indicator"
            aria-label="返回桌面"
            onClick={() => {
              if (gestureConsumed.current) return;
              if (locked) {
                beginUnlock();
                return;
              }
              captureApp();
              setHomeRequest((n) => n + 1);
              setKeyboard(false);
              setApp("");
              setFolder("");
              setPanel("");
            }}
          />
          <div className="screen-dimmer" />
          <div className="hardware-reflection" />
        </div>
      </KeyboardContext.Provider>
    </div>
  );
}
function AppSearch({
  apps,
  open,
}: {
  apps: Work["apps"];
  open: (id: string) => void;
}) {
  const [q, set] = useState("");
  return (
    <>
      <input
        autoFocus
        value={q}
        placeholder="App 名称"
        onChange={(e) => set(e.target.value)}
      />
      {apps
        .filter((a) => a.name.toLowerCase().includes(q.toLowerCase()))
        .map((a) => (
          <button
            className="search-result"
            key={a.id}
            onClick={() => open(a.id)}
          >
            <AppIcon id={a.id} small />
            {a.name}
          </button>
        ))}
    </>
  );
}
function Media({ item }: { item: Item }) {
  const src = safeMedia(item.media);
  return src ? (
    item.kind === "audio" ? (
      <audio controls src={src} />
    ) : item.kind === "video" ? (
      <video controls playsInline src={src} />
    ) : (
      <img loading="lazy" src={src} alt={item.title} />
    )
  ) : (
    <div
      className={`original-art art-${item.id.includes("ticket") ? "ticket" : "rain"}`}
    >
      <span>
        {item.id.includes("ticket") ? "城南 / SOUTHBOUND" : "after the rain"}
      </span>
      <strong>{item.id.includes("ticket") ? "09 · 01" : "雨 后"}</strong>
      <small>
        {item.id.includes("ticket")
          ? "16:30 · 一张未完成的约定"
          : "a little moment of quiet"}
      </small>
    </div>
  );
}
function AppContent({
  app,
  name,
  items,
  creator,
  state,
  onRead,
  onEdit,
  onAdd,
  onBack,
  onSettings,
  onUi,
  work,
}: {
  app: AppPlugin;
  name: string;
  items: Item[];
  creator: boolean;
  state: Runtime;
  onRead: (id: string) => void;
  onEdit: (item: Item) => void;
  onAdd: () => void;
  onBack: () => void;
  onSettings?: () => void;
  onUi?: (key: string, value: UiValue) => void;
  work: Work;
}) {
  const [detail, setDetail] = useState<Item | null>(null);
  const [thread, setThread] = useState("");
  const [tab, setTab] = useState(app.tabs[0]);
  const [q, setQ] = useState("");
  const [pw, setPw] = useState("");
  const [unlocks, setUnlocks] = useState<string[]>([]);
  const [pwError, setPwError] = useState("");
  const [likes, setLikes] = useState<string[]>([]);
  const shown = items
    .filter((i) => creator || visible(i, state))
    .filter((i) =>
      (i.title + i.body + i.sender).toLowerCase().includes(q.toLowerCase()),
    );
  const filtered =
    tab === "收藏"
      ? shown.filter((i) => i.favorite)
      : tab === app.tabs[0]
        ? shown
        : shown.filter((i) => i.folder === tab);
  const kakaoState = state.ui?.kakao ?? {};
  const getCursor = (key: string, fallback: number) => typeof kakaoState[key] === "number" ? Number(kakaoState[key]) : fallback;
  const messagesOf = (title: string) => (work.data.kakao ?? []).filter(m => m.title === title && m.meta.placeholder !== "true");
  const stageEnd = (title: string) => messagesOf(title).length;
  const extraCursors:Record<string,number> = (() => { try { return JSON.parse(String(kakaoState.gtExtraCursors || "{}")); } catch { return {}; } })();
  const initialScript = (title:string) => {const i=messagesOf(title).findIndex(m=>m.meta.scriptedDay === "true");return i<0?messagesOf(title).length:i;};
  const extraInitial = (title:string) => {const i=messagesOf(title).findIndex(m=>m.id.startsWith("gt-day1-v3-"));return i<0?messagesOf(title).length:i;};
  const gtChatComplete = [
    getCursor("mymyKktVisible",initialScript("재민형"))>=stageEnd("재민형"),
    getCursor("mymyHaechanCount",initialScript("해찬형"))>=stageEnd("해찬형"),
    (extraCursors["천러"]??extraInitial("천러"))>=stageEnd("천러"),
    (extraCursors["드림💚"]??extraInitial("드림💚"))>=stageEnd("드림💚"),
  ].every(Boolean);
  const notes = work.data.notes ?? [];
  const mail = work.data.mail ?? [];
  // The last Jaemin message is the definitive Day 1 story-completion event.
  // Keep the other exploration requirements, but do not block on stale chat cursors.
  const jaeminMessages = messagesOf("재민형");
  const finalMessageIndex = jaeminMessages.findIndex(m =>
    m.id.startsWith("gt-day1-v3-") && m.body.trim() === "睡着了吗？");
  const finalMessageDelivered = Boolean(kakaoState.gtLastMessageDelivered) ||
    (finalMessageIndex >= 0 &&
      getCursor("mymyKktVisible", initialScript("재민형")) > finalMessageIndex);
  const gtGateReady = Boolean(state.ui?.calendar?.gtGateReady) || (finalMessageDelivered &&
    Boolean(state.ui?.notes?.gtOpened) &&
    Boolean(state.ui?.mail?.gtOpened) &&
    mail.every(m => m.outgoing || m.read || state.read.includes(m.id)) &&
    Boolean(state.ui?.twitter?.gtOpened || state.ui?.x?.gtOpened) &&
    Boolean(state.ui?.instagram?.gtOpened || state.ui?.ins?.gtOpened));
  const read = (i: Item) => {
    if (creator) {
      onEdit(i);
      return;
    }
    setDetail(i);
    if (!i.password || unlocks.includes(i.id)) onRead(i.id);
  };
  const chats = [...new Set(shown.map((i) => i.title))];
  const back = () => {
    if (detail) setDetail(null);
    else if (thread) setThread("");
    else onBack();
  };
  const Skin =
    app.id === "wechat"
      ? WeChatSkin
      : app.id === "whatsapp"
        ? WhatsAppSkin
        : (catalogSkins[app.id as keyof typeof catalogSkins] ?? null);
  const detailView = detail ? (
    <div className="phone-content detail-content">
      {detail.password && !creator && !unlocks.includes(detail.id) ? (
        <div className="locked-note">
          <LockKeyhole size={36} />
          <h3>这条内容已锁定</h3>
          <input
            type="password"
            placeholder="内容密码"
            value={pw}
            onChange={(e) => setPw(e.target.value)}
          />
          <button
            onClick={() => {
              if (pw === detail.password) {
                setUnlocks([...unlocks, detail.id]);
                onRead(detail.id);
                setPwError("");
              } else setPwError("密码不正确");
            }}
          >
            解锁内容
          </button>
          <small>{pwError}</small>
        </div>
      ) : (
        <>
          <small className="detail-meta">
            {detail.time} · {detail.sender}
          </small>
          <h2>{detail.title}</h2>
          {app.id === "files" && detail.title.toLowerCase().endsWith(".png") && !detail.media && <div className="file-image-preview"><ImageIcon size={76} strokeWidth={1.5}/></div>}
          {(detail.media || ["media", "social"].includes(app.engine)) && (
            <Media item={detail} />
          )}
          <RichText value={detail.richText} fallback={detail.body} />
          <dl className="item-metadata">
            {getFields(app.id)
              .filter((f) => detail.meta?.[f.key])
              .map((f) => (
                <div key={f.key}>
                  <dt>{f.label}</dt>
                  <dd>{detail.meta[f.key]}</dd>
                </div>
              ))}
          </dl>
          {detail.folder && (
            <span className="folder-label">
              <Folder size={12} />
              {detail.folder}
            </span>
          )}
          {detail.comments.map((c, i) => (
            <p key={i} className="comment">
              {c}
            </p>
          ))}
        </>
      )}
    </div>
  ) : null;
  if (Skin)
    return (
      <>
        <div className="catalog-slot" hidden={!!detail}>
          <Suspense fallback={<div className="catalog-loading">正在打开…</div>}>
            <Skin
              appId={app.id}
              owner={work.phone.owner}
              virtualTime={state.time}
              phoneDate={work.phone.date}
              cycleIndex={state.ui?.calendar?.gtDay3Active ? 3 : state.ui?.calendar?.gtDay2Active ? 2 : 1}
              ui={app.id === "calendar" ? {...state.ui?.[app.id],gtGateReady,gtDay2EndReady: Boolean(state.ui?.calendar?.gtDay2Active) && Number(state.ui?.calendar?.gtContStage ?? -1) >= (state.ui?.calendar?.gtDay3Active ? day2Scenes.length : day2SceneBoundary),gtDay3Active:Boolean(state.ui?.calendar?.gtDay3Active)} : state.ui?.[app.id]}
              onUi={creator ? undefined : onUi}
              name={name}
              items={shown.map(item => ({...item, read: item.read || state.read.includes(item.id)}))}
              creator={creator}
              onRead={onRead}
              onItem={read}
              onAdd={onAdd}
              onBack={onBack}
              thread={thread}
              onThread={setThread}
            />
          </Suspense>
        </div>
        {detail &&
          (socialDetailApps.has(app.id) &&
          (!detail.password || unlocks.includes(detail.id)) ? (
            <SocialDetail
              app={app.id}
              item={detail}
              back={back}
              owner={work.phone.owner}
              ui={state.ui?.[app.id]}
              onUi={onUi}
            />
          ) : nativeDetailApps.has(app.id) &&
            (!detail.password || unlocks.includes(detail.id)) ? (
            <NativeDetail app={app.id} item={detail} back={back} />
          ) : (
            <>
              <div className="app-nav">
                <button aria-label="返回" onClick={back}>
                  <ChevronLeft size={23} />
                </button>
                <strong>{detail.title}</strong>
                <span />
              </div>
              {detailView}
            </>
          ))}
      </>
    );
  return (
    <>
      <div className="app-nav">
        <button onClick={back} aria-label="返回">
          <ChevronLeft size={23} />
          {detail || thread ? "返回" : ""}
        </button>
        <strong>{thread || name}</strong>
        <button
          onClick={
            creator
              ? onAdd
              : () =>
                  document
                    .querySelector<HTMLInputElement>(
                      ".app-screen .phone-search input",
                    )
                    ?.focus()
          }
          aria-label={creator ? "新增内容" : "搜索内容"}
        >
          {creator ? <Plus size={22} /> : <Search size={20} />}
        </button>
      </div>
      {app.id === "settings" && !detail ? (
        <NativeSettings
          work={work}
          items={items}
          creator={creator}
          onItem={read}
          onSettings={onSettings}
        />
      ) : app.id === "calculator" && !detail ? (
        <NativeCalculator
          items={shown}
          onRead={read}
          ui={state.ui?.[app.id]}
          onUi={onUi}
        />
      ) : detail ? (
        detailView
      ) : app.engine === "messaging" && thread ? (
        <div className="chat-content">
          <div className="chat-time">2026 年 9 月 1 日</div>
          {shown
            .filter((i) => i.title === thread)
            .map((i) => (
              <button
                key={i.id}
                className={`message-row ${i.outgoing ? "outgoing" : ""}`}
                onClick={() => (creator ? onEdit(i) : onRead(i.id))}
              >
                <span className="avatar">{i.sender.slice(0, 1)}</span>
                <span className="bubble">
                  {i.kind === "image" ||
                  i.kind === "audio" ||
                  i.kind === "video" ? (
                    <Media item={i} />
                  ) : i.kind === "transfer" ? (
                    <span className="transfer">
                      ¥ {i.body}
                      <small>虚构转账记录</small>
                    </span>
                  ) : (
                    i.body
                  )}
                  <small>
                    {i.time.slice(-5)} {i.read ? "✓✓" : ""}
                  </small>
                  {creator && (i.hidden || i.unlock) && (
                    <LockKeyhole size={12} />
                  )}
                </span>
              </button>
            ))}
          {creator ? (
            <button className="chat-compose" onClick={onAdd}>
              ＋ 添加一条消息
            </button>
          ) : (
            <div className="chat-compose muted">
              根据剧情推进，互动回复将在这里出现。
            </div>
          )}
        </div>
      ) : (
        <div
          className={`phone-content ${app.engine === "social" ? "feed-content" : ""}`}
        >
          {app.engine !== "media" && (
            <div className="phone-search">
              <Search size={15} />
              <input
                placeholder={`搜索${name}`}
                value={q}
                onChange={(e) => setQ(e.target.value)}
              />
            </div>
          )}
          {app.engine === "messaging" ? (
            chats.map((t) => {
              const list = shown.filter((i) => i.title === t),
                last = list[list.length - 1];
              return (
                <button
                  className="contact-row"
                  key={t}
                  onClick={() => {
                    setThread(t);
                    onRead(t);
                  }}
                >
                  <span className="avatar" style={{ background: app.color }}>
                    {t.slice(0, 1)}
                  </span>
                  <span>
                    <strong>{t}</strong>
                    <p>{last.body}</p>
                  </span>
                  <small>{last.time.slice(-5)}</small>
                </button>
              );
            })
          ) : app.engine === "media" ? (
            <>
              <div className="media-heading">
                <h1>{tab}</h1>
                <p>{filtered.length} 个故事片段</p>
              </div>
              <div className="media-grid">
                {filtered.map((i) => (
                  <button key={i.id} onClick={() => read(i)}>
                    <Media item={i} />
                    <span>
                      {i.title} {creator && i.hidden ? "· 隐藏" : ""}
                    </span>
                  </button>
                ))}
              </div>
            </>
          ) : app.engine === "social" ? (
            filtered.map((i) => (
              <article className="social-post" key={i.id}>
                <div className="post-author">
                  <span className="avatar" style={{ background: app.color }}>
                    {i.sender.slice(0, 1)}
                  </span>
                  <div>
                    <strong>{i.sender}</strong>
                    <small>{i.time}</small>
                  </div>
                  <button aria-label="查看帖子详情" onClick={() => read(i)}>
                    <MoreHorizontal size={20} />
                  </button>
                </div>
                <button className="post-image" onClick={() => read(i)}>
                  <Media item={i} />
                </button>
                <div className="post-actions">
                  <button
                    aria-label="虚构点赞"
                    onClick={() =>
                      setLikes(
                        likes.includes(i.id)
                          ? likes.filter((id) => id !== i.id)
                          : [...likes, i.id],
                      )
                    }
                  >
                    <Heart
                      size={22}
                      fill={likes.includes(i.id) ? "#d67670" : "none"}
                    />
                  </button>
                  <button aria-label="查看评论" onClick={() => read(i)}>
                    <MessageCircle size={22} />
                  </button>
                  <small>
                    {i.likes + (likes.includes(i.id) ? 1 : 0)} 次虚构喜欢
                  </small>
                </div>
                <button className="post-text" onClick={() => read(i)}>
                  <strong>{i.title}</strong>
                  <p>{i.body}</p>
                </button>
              </article>
            ))
          ) : (
            filtered.map((i) => (
              <button
                key={i.id}
                className={`record-row ${app.engine === "document" ? "document-row" : ""}`}
                onClick={() => read(i)}
              >
                <div className="record-symbol">
                  {app.engine === "records" ? (
                    <app.icon size={20} />
                  ) : (
                    <span>{i.title.slice(0, 1)}</span>
                  )}
                </div>
                <div>
                  <strong>{i.title}</strong>
                  <p>{i.body.split("\n")[0]}</p>
                  <small>
                    {i.time} {i.folder && `· ${i.folder}`}
                  </small>
                </div>
                {i.password || i.hidden ? (
                  <LockKeyhole size={14} />
                ) : (
                  <ChevronLeft className="chevron-right" size={16} />
                )}
              </button>
            ))
          )}
          {!filtered.length && app.engine !== "messaging" && (
            <div className="empty-app">
              <app.icon size={36} />
              <h3>这一页还很安静</h3>
              <p>
                {creator
                  ? "添加属于这个 App 的故事内容。"
                  : "暂时没有可浏览的内容。"}
              </p>
            </div>
          )}
          {creator && (
            <button className="phone-add" onClick={onAdd}>
              <Plus size={15} />
              添加
              {app.engine === "messaging"
                ? "聊天"
                : app.engine === "social"
                  ? "帖子"
                  : app.engine === "media"
                    ? "素材"
                    : "内容"}
            </button>
          )}
        </div>
      )}
      {!detail &&
        !thread &&
        app.id !== "calculator" &&
        app.id !== "settings" && (
          <div className="app-tabs">
            {app.tabs.map((t, i) => (
              <button
                key={t}
                className={tab === t ? "selected" : ""}
                onClick={() => setTab(t)}
              >
                {i === 0 ? (
                  <MessageCircle size={17} />
                ) : i === 1 ? (
                  <Search size={17} />
                ) : (
                  <UsersIcon />
                )}
                <span>{t}</span>
              </button>
            ))}
          </div>
        )}
    </>
  );
}
function UsersIcon() {
  return <PhoneIcon size={17} />;
}
