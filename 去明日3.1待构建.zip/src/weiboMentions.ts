import {fanName,makeFanBatch} from './socialFans';
import type {UiValue} from './schema';

export type WeiboMention = {id:string;name:string;body:string;comments:{id:string;name:string;text:string;parentId?:string}[]};
export type WeiboActivity = {id:string;body:string};
export const mentionCycle = (ui: Record<string, unknown> | undefined) => ui?.gtDay2Active ? 2 : 1;
export function parseSocialArray<T>(raw:unknown):T[]{
  if(typeof raw!=='string')return [];
  try{const value:unknown=JSON.parse(raw);return Array.isArray(value)?value as T[]:[];}catch{return [];}
}
/** Single deterministic mention per tick, with durable cycle-specific cursor. */
export function appendWeiboMention(ui:Record<string,UiValue>,cycle:number){
  const counterKey=`gtWeiboMentionCounter-${cycle}`;
  const mentionsKey=`gtWeiboMentions-${cycle}`;
  const activityKey=`gtWeiboActivity-${cycle}`;
  const cursor=typeof ui[counterKey]==='number'&&Number.isFinite(ui[counterKey])?Math.max(0,Math.floor(ui[counterKey] as number)):0;
  const seed=`weibo-mentions-${cycle}-${Math.floor(cursor/50)}`;
  const name=fanName(seed,cursor%50);
  const body=makeFanBatch(seed,50,'mention')[cursor%50];
  const id=`wm-${cycle}-${cursor}`;
  const oldMentions=parseSocialArray<WeiboMention>(ui[mentionsKey]);
  const oldActivity=parseSocialArray<WeiboActivity>(ui[activityKey]);
  const mentions=oldMentions.some(m=>m.id===id)?oldMentions:[{id,name,body,comments:[]},...oldMentions].slice(0,300);
  const activity=oldActivity.some(a=>a.id===id)?oldActivity:[{id,body:`@${name}提到了你`},...oldActivity].slice(0,300);
  return {ui:{...ui,[counterKey]:cursor+1,[mentionsKey]:JSON.stringify(mentions),[activityKey]:JSON.stringify(activity)},notification:`@${name}提到了你`,id};
}
