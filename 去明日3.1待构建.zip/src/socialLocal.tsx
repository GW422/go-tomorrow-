/** Player-created media only. Story data and save keys are deliberately untouched. */
import { useEffect, useState } from "react";
const DB = "gt-player-social-media-v1";
const STORE = "photos";
export const photoKey = (id: string) => `gt-photo:${id}`;
const isPhotoKey = (src: string) => src.startsWith("gt-photo:");
function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === "undefined") { reject(new Error("此浏览器不支持照片存储")); return; }
    const req = indexedDB.open(DB, 1);
    req.onupgradeneeded = () => { if (!req.result.objectStoreNames.contains(STORE)) req.result.createObjectStore(STORE); };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error || new Error("无法打开照片存储"));
  });
}
export async function savePlayerPhoto(data: Blob): Promise<string> {
  const db = await openDb();
  const id = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
  try {
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE, "readwrite");
      tx.objectStore(STORE).put(data, id);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error || new Error("照片存储失败"));
      tx.onabort = () => reject(tx.error || new Error("照片存储中止"));
    });
    return photoKey(id);
  } finally { db.close(); }
}
export async function readPlayerPhoto(key: string): Promise<Blob | null> {
  if (!isPhotoKey(key)) return null;
  const db = await openDb();
  try {
    return await new Promise<Blob | null>((resolve, reject) => {
      const tx = db.transaction(STORE, "readonly");
      const req = tx.objectStore(STORE).get(key.slice("gt-photo:".length));
      req.onsuccess = () => resolve(req.result instanceof Blob ? req.result : null);
      req.onerror = () => reject(req.error);
    });
  } finally { db.close(); }
}
export async function preparePlayerPhoto(file: File): Promise<{key: string; preview: string}> {
  if (!file.type.startsWith("image/")) throw new Error("请选择图片文件");
  const src = URL.createObjectURL(file);
  try {
    const img = new Image();
    await new Promise<void>((resolve, reject) => { img.onload = () => resolve(); img.onerror = () => reject(new Error("无法读取图片")); img.src = src; });
    const scale = Math.min(1, 1200 / Math.max(img.naturalWidth, img.naturalHeight));
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(img.naturalWidth * scale));
    canvas.height = Math.max(1, Math.round(img.naturalHeight * scale));
    const ctx = canvas.getContext("2d");
    if (!ctx) throw new Error("无法处理图片");
    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
    const blob = await new Promise<Blob>((resolve, reject) => canvas.toBlob(v => v ? resolve(v) : reject(new Error("图片压缩失败")), "image/jpeg", .76));
    const key = await savePlayerPhoto(blob);
    return { key, preview: URL.createObjectURL(blob) };
  } finally { URL.revokeObjectURL(src); }
}
export function usePlayerPhoto(src: string): string {
  const [resolved, setResolved] = useState(isPhotoKey(src) ? "" : src);
  useEffect(() => {
    if (!isPhotoKey(src)) { setResolved(src); return; }
    let active = true;
    let objectUrl = "";
    setResolved("");
    readPlayerPhoto(src).then(blob => {
      if (!active || !blob) return;
      objectUrl = URL.createObjectURL(blob);
      setResolved(objectUrl);
    }).catch(() => { if (active) setResolved(""); });
    return () => { active = false; if (objectUrl) URL.revokeObjectURL(objectUrl); };
  }, [src]);
  return resolved;
}
export function PlayerPhoto({src, alt, className}: {src:string;alt:string;className?:string}) {
  const resolved = usePlayerPhoto(src);
  return resolved ? <img src={resolved} alt={alt} className={className}/> : <div className={className} aria-label={alt} style={{minHeight:80,background:"#eee"}}/>;
}
