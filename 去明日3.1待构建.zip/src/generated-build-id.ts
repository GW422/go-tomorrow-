// Auto-generated content IDs; do not edit by hand.
export const BUILD_FINGERPRINT = "e8741866b256dd5635dbf24afb345f7fae8964de4363b3ec1493af2dbaada3ae";
export const STORY_FINGERPRINT = "44d9ceee7194e5d8138be660ede86eb64f5f39e6d4e580843d5894e0fc025ea8";
