import { itemSchema, type Item } from "../schema";
import { STORY_FINGERPRINT } from "../generated-build-id";

type Manifest = { formatVersion: number; apps: Record<string, string[]> };
const log = (name: string, detail: string) => window.__gtStartupDiag?.log(name, detail);
const cacheName = "gt-lazy-apps-v2";
const pause = () => new Promise<void>(resolve => setTimeout(resolve, 0));
const inFlight = new Map<string, Promise<string>>();

async function fetchVersioned(path: string, signal?: AbortSignal): Promise<string> {
  // Hash-named chunks never change contents; retain across story revisions.
  // Manifest is versioned separately so it always points at the current chunks.
  const isChunk = /\/[a-z0-9_-]+-[0-9a-f]{16}\.json$/.test(path);
  const url = isChunk ? path : `${path}?story=${STORY_FINGERPRINT}`;
  const existing = inFlight.get(url);
  if (existing) return existing;
  const task = (async () => {
    try {
      if ("caches" in window) {
        const cache = await caches.open(cacheName);
        const cached = await cache.match(url);
        if (cached) { log("分包缓存命中", path); return cached.text(); }
      }
    } catch (e) { log("分包缓存不可用", String(e)); }
    log("分包下载开始", path);
    const started = performance.now();
    const response = await fetch(url, { signal });
    if (!response.ok) throw Error(`${path}: HTTP ${response.status}`);
    const text = await response.text();
    log("分包下载完成", `${path}: ${new TextEncoder().encode(text).byteLength} 字节；${Math.round(performance.now()-started)} ms`);
    try {
      if ("caches" in window) {
        const cache = await caches.open(cacheName);
        await cache.put(url, new Response(text, {headers:{"content-type":"application/json"}}));
      }
    } catch (e) { log("分包缓存保存失败", String(e)); }
    return text;
  })();
  inFlight.set(url, task);
  try { return await task; } finally { inFlight.delete(url); }
}

async function parseInWorker(text: string): Promise<unknown> {
  if (typeof Worker === "undefined") return JSON.parse(text);
  const source = `self.onmessage=(e)=>{try{self.postMessage({ok:true,value:JSON.parse(e.data)})}catch(err){self.postMessage({ok:false,error:String(err)})}}`;
  const url = URL.createObjectURL(new Blob([source], {type:"application/javascript"}));
  const worker = new Worker(url);
  try {
    return await new Promise<unknown>((resolve,reject)=>{
      worker.onmessage = ev => ev.data.ok ? resolve(ev.data.value) : reject(Error(ev.data.error));
      worker.onerror = ev => reject(Error(ev.message));
      worker.postMessage(text);
    });
  } finally {worker.terminate();URL.revokeObjectURL(url);}
}
export async function lazyManifest(): Promise<Manifest> {
  const raw = await fetchVersioned("./gt-chunks/manifest.json");
  const parsed = JSON.parse(raw) as Manifest;
  if (parsed.formatVersion !== 1 || !parsed.apps || typeof parsed.apps !== "object") throw Error("分包清单格式错误");
  return parsed;
}
export async function loadAppParts(app: string, files: string[], signal?: AbortSignal): Promise<Item[]> {
  // Three simultaneous requests rather than N sequential network round trips.
  // Keep the result ordered so post order and IDs are unchanged.
  const groups: Item[][] = new Array(files.length);
  let cursor = 0;
  const worker = async () => {
    while (cursor < files.length) {
      if (signal?.aborted) throw new DOMException("Aborted","AbortError");
      const index = cursor++;
      const filename = files[index];
      if (!/^[a-z0-9_-]+\.json$/.test(filename)) throw Error("不安全的分包名称");
      const raw = await fetchVersioned(`./gt-chunks/${filename}`, signal);
      const parsed = await parseInWorker(raw);
      groups[index] = itemSchema.array().parse(parsed);
      log("分包解析完成", `${app} ${index+1}/${files.length} (${groups[index].length} 项)`);
      await pause();
    }
  };
  await Promise.all(Array.from({length:Math.min(3,files.length)},()=>worker()));
  return groups.flat();
}
