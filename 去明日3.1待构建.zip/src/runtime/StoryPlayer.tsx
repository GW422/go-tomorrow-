import { Component, useCallback, useEffect, useRef, useState, type ErrorInfo, type ReactNode } from "react";
import { lazyManifest, loadAppParts } from "./lazyApps";
import { createRoot } from "react-dom/client";
import { Phone } from "../Phone";
import { BUILD_FINGERPRINT, STORY_FINGERPRINT } from "../generated-build-id";
import { validateWork, type Work } from "../schema";
import "../styles.css";
import "./player.css";

declare global { interface Window { __gtStartupDiag?: { log:(phase:string, detail?:string)=>void; done:()=>void; show:()=>void } } }
const startupLog = (phase:string, detail="") => window.__gtStartupDiag?.log(phase, detail);
function PhoneReady({work,onDemandApp,loadingApps}:{work:Work;onDemandApp?:(app:string)=>void;loadingApps?:string[]}) {
  useEffect(()=>{startupLog("React 手机组件已挂载"); requestAnimationFrame(()=>{requestAnimationFrame(()=>window.__gtStartupDiag?.done());});},[]);
  return <Phone work={work} onDemandApp={onDemandApp} loadingApps={loadingApps}/>;
}
// Do not erase saved progress when loading fails. A retry should only reload assets.
class PhoneErrorBoundary extends Component<{children:ReactNode},{error:string}> {
  state = {error:""};
  static getDerivedStateFromError(error:unknown){return {error:String(error)};}
  componentDidCatch(error:Error, info:ErrorInfo){startupLog("手机渲染错误",String(error));console.error("Phone render failed",error,info.componentStack);}
  render(){return this.state.error ? <div role="alert" style={{padding:24,overflowWrap:"anywhere"}}>
    <h3>手机界面暂时无法打开</h3><p>{this.state.error}</p>
    <button onClick={()=>this.setState({error:""})}>重试打开</button>
    <p>你的浏览器本地存档不会因此被清除。</p>
  </div> : this.props.children;}
}
// Only the network/body transfer is abortable. In particular, never leave a
// fetch timeout running while JSON.parse or Zod validates a large story file.
// A 200 response means headers arrived, NOT that the body was read.
type LoadPhase = "request" | "download" | "parse" | "validate";
type LoadProgress = { phase: LoadPhase; attempt: number; received: number; total: number | null; elapsedMs: number; detail: string };
const MB = (bytes:number) => (bytes / 1048576).toFixed(2) + " MB";
const yieldToBrowser = () => new Promise<void>(resolve => setTimeout(resolve, 0));
const STORY_CACHE_NAME = "gt-validated-story-v1";
// This fingerprint is rebuilt from story + source inputs on each deployment.
// Never reuse a previous version's story, even if the filename is unchanged.
async function readStoryCache(url:string):Promise<Work|null>{
  if(!["./work.json","./gt-boot.json"].includes(url) || !("caches" in window))return null;
  try{
    const cache=await caches.open(STORY_CACHE_NAME);
    const key=new URL(`${url}?story=${STORY_FINGERPRINT}`,location.href).href;
    const response=await cache.match(key);
    if(!response)return null;
    startupLog("剧情缓存命中","读取相同剧情版本的本地缓存");
    try{
      const raw=await response.text();
      const work=validateWork(JSON.parse(raw));
      startupLog("剧情缓存验证成功",`${raw.length} 字符`);
      return work;
    }catch(e){
      startupLog("剧情缓存无效，改为联网下载",String(e));
      await cache.delete(key);
      return null;
    }
  }catch(e){startupLog("剧情缓存不可用，改为联网下载",String(e));return null;}
}
async function saveStoryCache(url:string,body:string):Promise<void>{
  if(!["./work.json","./gt-boot.json"].includes(url) || !("caches" in window))return;
  try{
    const cache=await caches.open(STORY_CACHE_NAME);
    const key=new URL(`${url}?story=${STORY_FINGERPRINT}`,location.href).href;
    await cache.put(key,new Response(body,{headers:{"Content-Type":"application/json; charset=utf-8"}}));
    // Keep only newest validated story; never touch localStorage player saves.
    for(const request of await cache.keys())if(request.url!==key)await cache.delete(request);
    startupLog("剧情缓存已保存","下次访问可直接读取本版本剧情");
  }catch(e){startupLog("剧情缓存保存失败（不影响本次游玩）",String(e));}
}

async function loadWork(url:string, signal:AbortSignal, onProgress:(progress:LoadProgress)=>void):Promise<Work>{
  const started=performance.now();
  const report=(phase:LoadPhase,attempt:number,received:number,total:number|null,detail:string)=>{
    onProgress({phase,attempt,received,total,elapsedMs:Math.round(performance.now()-started),detail});
    startupLog("剧情加载/"+phase,`第${attempt}次；${detail}；${received}字节${total?" / "+total+"字节":""}`);
  };
  let lastError:unknown;
  for(let attempt=0;attempt<3;attempt++){
    if(signal.aborted) throw new DOMException("Aborted","AbortError");
    const networkController=new AbortController();
    let timeoutReason:"inactive"|"maximum"|null=null;
    // A slow but progressing download must not be aborted after a fixed 30s.
    // Only restart a stalled transfer; allow up to 15 minutes as a safety ceiling.
    let idleTimer:ReturnType<typeof setTimeout>|undefined;
    const resetIdleTimer=()=>{
      if(idleTimer!==undefined)clearTimeout(idleTimer);
      idleTimer=setTimeout(()=>{timeoutReason="inactive";networkController.abort();},30000);
    };
    resetIdleTimer();
    const maximumTimer=setTimeout(()=>{timeoutReason="maximum";networkController.abort();},900000);
    const abort=()=>networkController.abort();
    signal.addEventListener("abort",abort,{once:true});
    let body:string;
    let received=0;
    let total:number|null=null;
    try{
      report("request",attempt+1,0,null,"准备请求剧情文件");
      // Versioned URL enables the browser HTTP cache without risking old story data.
      const versionedUrl=(url==="./work.json" || url==="./gt-boot.json")?`${url}?story=${STORY_FINGERPRINT}`:url;
      const requestUrl=attempt===0?versionedUrl:`${versionedUrl}${versionedUrl.includes("?")?"&":"?"}retry=${attempt}`;
      const response=await fetch(requestUrl,{signal:networkController.signal,cache:attempt?"reload":"default"});
      if(!response.ok)throw Error(`作品文件加载失败：HTTP ${response.status}`);
      const contentLength=Number(response.headers.get("content-length"));
      total=Number.isFinite(contentLength)&&contentLength>0?contentLength:null;
      report("download",attempt+1,0,total,"已收到 HTTP "+response.status+"，正在读取响应正文");
      if(response.body && typeof response.body.getReader==="function"){
        const reader=response.body.getReader();
        const decoder=new TextDecoder("utf-8");
        const chunks:string[]=[];
        let lastReport=0;
        try{
          while(true){
            const {done,value}=await reader.read();
            if(done)break;
            if(value){
              received+=value.byteLength;
              if(total!==null && received>total){total=null;startupLog("进度提示","服务器报告的压缩传输长度与解压后字节数不同，改用已接收数据量显示");}
              resetIdleTimer();
              chunks.push(decoder.decode(value,{stream:true}));
              const now=performance.now();
              if(now-lastReport>2000){report("download",attempt+1,received,total,"正在接收剧情文件");lastReport=now;}
            }
          }
          chunks.push(decoder.decode());
        }finally{reader.releaseLock();}
        body=chunks.join("");
      }else{
        // Older embedded browsers may not expose a readable response stream.
        // A non-streaming browser cannot report progress; allow the full
        // safety window instead of treating a slow response.text() as idle.
        if(idleTimer!==undefined)clearTimeout(idleTimer);
        idleTimer=undefined;
        body=await response.text();
        received=new TextEncoder().encode(body).byteLength;
      }
      report("download",attempt+1,received,total,"文件正文读取完成");
      if(!body)throw Error("作品文件内容为空");
    }catch(e){
      if(signal.aborted)throw e;
      lastError=timeoutReason?Error(`作品文件下载${timeoutReason==="inactive"?"停滞超过30秒":"超过最长15分钟"}：已接收 ${MB(received)}${total?` / ${MB(total)}`:"（服务器未提供总大小）"}`):e;
      report("download",attempt+1,received,total,`请求失败：${String(lastError)}`);
      if(attempt<2)await new Promise(resolve=>setTimeout(resolve,500*(attempt+1)));
      continue;
    }finally{
      if(idleTimer!==undefined)clearTimeout(idleTimer);
      clearTimeout(maximumTimer);
      signal.removeEventListener("abort",abort);
    }
    // Parsing and validation can be expensive on older mobile devices.
    // They must not be aborted by a fetch timeout or retried as network errors.
    if(signal.aborted)throw new DOMException("Aborted","AbortError");
    await yieldToBrowser();
    report("parse",attempt+1,received,total,"文件已完整读取，开始 JSON.parse");
    let parsed:unknown;
    try{parsed=JSON.parse(body);startupLog("JSON 解析成功",`${received} 字节`);}catch(e){startupLog("JSON 解析失败",String(e));throw Error(`作品 JSON 解析失败：${String(e)}`);}
    if(signal.aborted)throw new DOMException("Aborted","AbortError");
    await yieldToBrowser();
    report("validate",attempt+1,received,total,"JSON 解析完成，开始验证剧情结构");
    try{const validated=validateWork(parsed);report("validate",attempt+1,received,total,"剧情验证成功");await saveStoryCache(url,body);return validated;}catch(e){startupLog("剧情验证失败",String(e));throw Error(`作品数据验证失败：${String(e)}`);}
  }
  throw lastError instanceof Error?lastError:Error(String(lastError));
}
function StoryPlayer(){
  const [work,setWork]=useState<Work|null>(null);
  const [loadingApps,setLoadingApps]=useState<string[]>([]);
  const manifestRef=useRef<Record<string,string[]>>({});
  const loadedRef=useRef(new Set<string>());
  const loadingRef=useRef(new Map<string,Promise<void>>());
  const requestedRef=useRef(new Set<string>());
  const workRef=useRef<Work|null>(null);
  // Load complete app data without replacing the mounted Phone/its saved runtime.
  const requestApp=useCallback((app:string):Promise<void>=>{
    const files=manifestRef.current[app];
    if(!files){requestedRef.current.add(app);return Promise.resolve();}
    if(loadedRef.current.has(app))return Promise.resolve();
    const previous=loadingRef.current.get(app);
    if(previous)return previous;
    startupLog("按需加载优先",app);
    const task=loadAppParts(app,files).then(items=>{
      loadedRef.current.add(app);
      const current=workRef.current;
      if(current){const updated={...current,data:{...current.data,[app]:items}};workRef.current=updated;setWork(updated);}
      startupLog("应用已准备",`${app}：${items.length}条记录`);
    }).catch(e=>{
      startupLog("应用分包加载失败",`${app}: ${String(e)}`);
      // Keep the player intact; opening the app again retries the request.
    }).finally(()=>{
      loadingRef.current.delete(app);
      setLoadingApps([...Object.keys(manifestRef.current).filter(name=>!loadedRef.current.has(name))]);
    });
    loadingRef.current.set(app,task);
    return task;
  },[]);
  const [error,setError]=useState("");
  const [retry,setRetry]=useState(0);
  const [phase,setPhase]=useState<LoadPhase>("request");
  const [progress,setProgress]=useState<LoadProgress>({phase:"request",attempt:1,received:0,total:null,elapsedMs:0,detail:"尚未开始"});
  const [showDiagnostics,setShowDiagnostics]=useState(false);
  const url=new URLSearchParams(location.search).get("preview")==="test"?"./test-work.json":new URLSearchParams(location.search).get("template")==="blank"?"./blank-work.json":"./work.json";
  useEffect(()=>{
    // Legacy workers may keep serving an old JavaScript bundle after deployment.
    // Remove only service-worker registrations (never player saves or story cache).
    // Once per build/session, refresh an already-controlled page so updated code
    // can run without the old worker. The runtime build does not register a new one.
    if (!("serviceWorker" in navigator)) return;
    void navigator.serviceWorker.getRegistrations().then(async regs=>{
      const wasControlled=Boolean(navigator.serviceWorker.controller);
      await Promise.all(regs.map(reg=>reg.unregister()));
      if (!wasControlled) return;
      startupLog("旧资源控制已解除","更新前端运行文件，不会清理存档");
      try {
        const marker="gt-runtime-worker-refresh";
        if(sessionStorage.getItem(marker)===BUILD_FINGERPRINT)return;
        sessionStorage.setItem(marker,BUILD_FINGERPRINT);
        location.reload();
      } catch { /* Private browsing may deny sessionStorage. Do not reload endlessly. */ }
    }).catch(e=>startupLog("旧资源检查失败",String(e)));
  },[]);
  useEffect(()=>{
    const controller=new AbortController();setError("");
    startupLog("前端构建版本", BUILD_FINGERPRINT.slice(0,12));
    startupLog("剧情版本", STORY_FINGERPRINT.slice(0,12));
    startupLog("React 剧情加载开始",url);
    const isFullWork=url!=="./work.json";
    const fastUrl=isFullWork?url:"./gt-boot.json";
    const backgroundController=new AbortController();
    loadedRef.current.clear();
    loadingRef.current.clear();
    manifestRef.current={};
    requestedRef.current.clear();
    workRef.current=null;
    setLoadingApps([]);
    void readStoryCache(fastUrl).then(cached=>{
      if(controller.signal.aborted)throw new DOMException("Aborted","AbortError");
      if(cached)return cached;
      return loadWork(fastUrl,controller.signal,next=>{
        if(!controller.signal.aborted){setPhase(next.phase);setProgress(next);}
      });
    }).then(w=>{
      document.title=w.title==="捡手机"?"捡手机":w.title+" · 捡手机";
      startupLog("剧情加载完成，准备渲染手机");
      workRef.current=w;
      if(!isFullWork){setLoadingApps(["instagram","photos","twitter","x"]);}
      setWork(w);
      if(!isFullWork){
        void lazyManifest().then(manifest=>{
          if(backgroundController.signal.aborted)return;
          manifestRef.current=manifest.apps;
          setLoadingApps(Object.keys(manifest.apps));
          for(const app of requestedRef.current)if(manifest.apps[app])void requestApp(app);
          requestedRef.current.clear();
          startupLog("分包清单就绪",Object.entries(manifest.apps).map(([a,files])=>`${a}:${files.length}`).join(", "));
          // Low-priority prefetch only after the first screen is interactive.
          // Yield between applications and never compete with an explicit request.
          const prefetch=async()=>{
            for(const app of Object.keys(manifest.apps)){
              if(backgroundController.signal.aborted)return;
              if(loadingRef.current.size){await Promise.allSettled([...loadingRef.current.values()]);}
              if(backgroundController.signal.aborted)return;
              await new Promise<void>(r=>setTimeout(r,4000));
              if(backgroundController.signal.aborted)return;
              if(!loadedRef.current.has(app))await requestApp(app);
            }
          };
          const start=()=>{if(!backgroundController.signal.aborted)void prefetch();};
          // Defer optional downloads; do not compete with initial phone, audio or
          // the player's immediate app-open request on a slow connection.
          setTimeout(start,30000);
        }).catch(e=>{
          // The core phone is already usable. Do not download a second full
          // story on an unreliable connection. Keep retrying only the tiny
          // manifest; app-open requests remain queued until it succeeds.
          startupLog("分包清单首次加载失败，启动轻量重试",String(e));
          const retryManifest=async()=>{
            for(let attempt=1;attempt<=3&&!backgroundController.signal.aborted;attempt++){
              await new Promise<void>(resolve=>setTimeout(resolve,attempt*2000));
              if(backgroundController.signal.aborted)return;
              try{
                const manifest=await lazyManifest();
                if(backgroundController.signal.aborted)return;
                manifestRef.current=manifest.apps;
                setLoadingApps(Object.keys(manifest.apps));
                for(const app of requestedRef.current)if(manifest.apps[app])void requestApp(app);
                requestedRef.current.clear();
                startupLog("分包清单重试成功",`第${attempt}次重试`);
                return;
              }catch(err){startupLog("分包清单重试失败",`第${attempt}次: ${String(err)}`);}
            }
            if(!backgroundController.signal.aborted){
              startupLog("分包清单暂不可用","基础手机与聊天保留；刷新页面可重新获取可选应用数据");
              window.__gtStartupDiag?.show();
            }
          };
          void retryManifest();
        });
      }
    }).catch(e=>{if(!controller.signal.aborted){startupLog("剧情加载失败",String(e));setError(String(e));}});
    return ()=>{controller.abort();backgroundController.abort();};
  },[url,retry]);
  const tryAgain=useCallback(()=>setRetry(n=>n+1),[]);
  return <main className="story-runtime">{work?<PhoneErrorBoundary><PhoneReady work={work} onDemandApp={requestApp} loadingApps={loadingApps}/></PhoneErrorBoundary>:
    <div role="status" style={{padding:24}}><p>{error||({request:"正在连接作品文件…",download:"正在下载作品文件…",parse:"正在解析剧情文件…",validate:"正在检查剧情数据…"} as const)[phase]}</p>
    <button type="button" onClick={()=>setShowDiagnostics(v=>!v)} style={{marginTop:12}}>{showDiagnostics?"收起下载诊断":"查看下载诊断"}</button>
    {showDiagnostics&&<div style={{textAlign:"left",maxWidth:520,margin:"12px auto",padding:12,border:"1px solid #777",borderRadius:8,overflowWrap:"anywhere",fontSize:13,lineHeight:1.6}}>
      <div>阶段：{phase}　尝试次数：{progress.attempt}/3</div>
      <div>已接收：{MB(progress.received)}{progress.total?` / ${MB(progress.total)} (${Math.min(100,Math.round(progress.received/progress.total*100))}%)`:" / 总大小未知"}</div>
      <div>启动耗时：{(progress.elapsedMs/1000).toFixed(1)} 秒</div>
      <div>最近事件：{progress.detail}</div>
      <div>浏览器：{navigator.userAgent}</div>
      <button type="button" onClick={()=>{const summary=`《去明日》下载诊断\n阶段：${phase}\n尝试：${progress.attempt}/3\n已接收：${progress.received} 字节\n总大小：${progress.total??"未知"}\n耗时：${progress.elapsedMs} 毫秒\n事件：${progress.detail}\n错误：${error||"无"}\n浏览器：${navigator.userAgent}`;void navigator.clipboard?.writeText(summary).catch(()=>{});}}>复制诊断信息</button>
    </div>}
    {error&&<><button onClick={tryAgain}>重新加载</button><p>不会清除你的本地存档。</p></>}</div>}</main>;
}
createRoot(document.getElementById("root")!).render(<StoryPlayer/>);
