import { createContext, useContext, useEffect, useRef, useState, type ReactNode } from 'react';
import { Play, Pause, SkipBack, SkipForward, ChevronDown } from 'lucide-react';
import { safeMedia, type Item } from './schema';
import './global-music.css';
type MusicState = { item: Item | null; playing: boolean; expanded: boolean; time: number; duration: number; tracks: Item[]; error: string; play: (item: Item, items?: Item[]) => void; toggle: () => void; next: () => void; previous: () => void; close: () => void; open: () => void; seek: (time: number) => void; };
const MusicContext = createContext<MusicState | null>(null);
export function useGlobalMusic() { const ctx = useContext(MusicContext); if (!ctx) throw Error('Music provider missing'); return ctx; }
const cover = (item: Item | null) => {
  const v = String(item?.meta?.cover ?? '');
  return /^\.\/music\/tracks\/track-\d{2}\.webp$/.test(v) ? v : '';
};
export function GlobalMusicProvider({children}: {children: ReactNode}) {
  const audio = useRef<HTMLAudioElement>(null);
  const playRequest = useRef(0);
  useEffect(()=>{window.__gtStartupDiag?.log("音乐全局播放器已挂载","支持跨游戏内应用持续播放");},[]);
  const [item,setItem] = useState<Item|null>(null);
  const itemRef=useRef<Item|null>(null);
  const tracksRef=useRef<Item[]>([]);
  const [tracks,setTracks]=useState<Item[]>([]);
  const [playing,setPlaying]=useState(false);
  const [expanded,setExpanded]=useState(false);
  const [time,setTime]=useState(0);
  const [duration,setDuration]=useState(0);
  const [error,setError]=useState("");
  const play=(selected: Item, queue?: Item[], reveal=true)=>{
    if(!safeMedia(selected.media)){setError("音频资源地址不可用");return;}
    window.__gtStartupDiag?.log("音乐播放请求",`${selected.title} / ${selected.media}`);
    setError("");
    if(queue?.length){tracksRef.current=queue;setTracks(queue);}
    itemRef.current=selected;setItem(selected);if(reveal)setExpanded(true);setTime(0);
    const el=audio.current;
    const request=++playRequest.current;
    if(el){
      const source=safeMedia(selected.media);
      // Cancel a previous pending play operation before changing the source.
      el.pause();
      el.src=source;
      el.load();
      void el.play().then(()=>{if(request===playRequest.current)setPlaying(true);}).catch(e=>{
        if(request!==playRequest.current || e?.name==="AbortError") return;
        setPlaying(false);setError("音乐无法播放："+String(e));
        window.__gtStartupDiag?.log("音乐播放失败",`${selected.title} ${String(e)}`);
      });
    }
  };
  const toggle=()=>{const el=audio.current;if(!el)return;if(el.paused)void el.play().catch(e=>{if(e?.name!=="AbortError")setError("音乐无法播放："+String(e));setPlaying(false);});else el.pause();};
  const shift=(offset:number)=>{const list=tracksRef.current;const current=itemRef.current;if(!current||!list.length)return;const idx=list.findIndex(i=>i.id===current.id);play(list[(idx+offset+list.length)%list.length],undefined,false);};
  const next=()=>shift(1),previous=()=>{if((audio.current?.currentTime??0)>3){if(audio.current)audio.current.currentTime=0;}else shift(-1);};
  const seek=(value:number)=>{if(audio.current&&Number.isFinite(value))audio.current.currentTime=value;};
  useEffect(()=>{
    if(!('mediaSession' in navigator) || typeof MediaMetadata==='undefined')return;
    const session=navigator.mediaSession;
    if(!item){session.metadata=null;return;}
    session.metadata=new MediaMetadata({title:item.title,artist:item.sender,album:String(item.meta?.album??''),artwork:cover(item)?[{src:new URL(cover(item),document.baseURI).href,type:'image/webp'}]:[]});
    const actions: Array<[MediaSessionAction, MediaSessionActionHandler]>=[['play',()=>{void audio.current?.play().catch(()=>{});}],['pause',()=>audio.current?.pause()],['previoustrack',previous],['nexttrack',next],['seekto',(detail)=>{if(typeof detail.seekTime==='number')seek(detail.seekTime);}]];
    actions.forEach(([name,handler])=>{try{session.setActionHandler(name,handler);}catch{}});
    return ()=>{actions.forEach(([name])=>{try{session.setActionHandler(name,null);}catch{}});};
  },[item,tracks]);
  useEffect(()=>{if('mediaSession' in navigator)navigator.mediaSession.playbackState=playing?'playing':'paused';},[playing]);
  const value:MusicState={item,playing,expanded,time,duration,tracks,error,play,toggle,next,previous,close:()=>setExpanded(false),open:()=>{if(item)setExpanded(true);},seek};
  return <MusicContext.Provider value={value}>
    {children}
    <audio ref={audio} preload="none" onPlay={()=>setPlaying(true)} onPause={()=>setPlaying(false)} onTimeUpdate={e=>setTime(e.currentTarget.currentTime)} onLoadedMetadata={e=>setDuration(Number.isFinite(e.currentTarget.duration)?e.currentTarget.duration:0)} onEnded={()=>{if(tracksRef.current.length>1)next();else setPlaying(false);}} onError={()=>{const code=audio.current?.error?.code;setError(`音乐文件加载失败（${code??"未知错误"}），请检查部署的 music/tracks 文件`);window.__gtStartupDiag?.log("音乐资源错误",`${audio.current?.currentSrc ?? ""} / code ${code ?? "unknown"}`);setPlaying(false);}} />
  </MusicContext.Provider>;
}
export function GlobalMusicCard(){
  const m=useGlobalMusic();if(!m.item||!m.expanded)return null;
  return <div className="gt-music-shade" onClick={m.close}>
    <section className="gt-music-card" role="dialog" aria-label="音乐播放器" onClick={e=>e.stopPropagation()}>
      <button className="gt-music-dismiss" onClick={m.close} aria-label="关闭播放器"><ChevronDown/></button>
      {cover(m.item)?<img className="gt-music-art" src={cover(m.item)} alt="专辑封面"/>:<div className="gt-music-art"/>}
      <h2>{m.item.title}</h2><p>{m.item.sender}</p>{m.error && <p className="gt-music-error" role="alert">{m.error}</p>}
      <input aria-label="播放进度" type="range" min={0} max={m.duration||1} step="0.1" value={Math.min(m.time,m.duration||1)} onChange={e=>m.seek(Number(e.target.value))}/>
      <div className="gt-music-time"><span>{clock(m.time)}</span><span>-{clock(Math.max(0,m.duration-m.time))}</span></div>
      <div className="gt-music-actions"><button onClick={m.previous} aria-label="上一首"><SkipBack fill="currentColor"/></button><button onClick={m.toggle} aria-label={m.playing?'暂停':'播放'}>{m.playing?<Pause fill="currentColor"/>:<Play fill="currentColor"/>}</button><button onClick={m.next} aria-label="下一首"><SkipForward fill="currentColor"/></button></div>
    </section>
  </div>;
}
function clock(n:number){return `${Math.floor(n/60)}:${String(Math.floor(n%60)).padStart(2,'0')}`;}
export {cover as musicCover};
