import {useEffect,useRef,useState} from 'react';
import {day2Intro,day2Title,day2Chat,day2Segments} from './day2Story';
import './day2.css';
type Props={mode:'note'|'chat'; chatCount:number; choices:number[]; onChatCount:(n:number)=>void; onChoice:(n:number,v:number)=>void; onExit:()=>void; onChatFinished:()=>void; onNoteFinished:()=>void; noteFinished?:boolean;};
export function Day2Experience(p:Props){
 const scroll=useRef<HTMLDivElement>(null);

 useEffect(()=>{if(p.mode!=='chat')return;const next=day2Chat[p.chatCount];if(!next){p.onChatFinished();return;}if(next[0]==='朴志晟')return;const timer=setTimeout(()=>p.onChatCount(p.chatCount+1),1050);return()=>clearTimeout(timer);},[p.mode,p.chatCount]);
 useEffect(()=>{if(p.mode==='chat')scroll.current?.scrollTo({top:scroll.current.scrollHeight,behavior:'smooth'});},[p.mode,p.chatCount]);
 const showFull=p.chatCount>=day2Chat.length;
 return <div className="day2-root">
 {p.mode==='chat'?<>
  <div className="day2-chat-header"><button onClick={p.onExit}>‹</button><b>재민형</b><span>⋯</span></div>
  <div className="day2-chat-scroll" ref={scroll}><div className="day2-chat-date">2026年10月22日 星期四</div><div className="day2-bubble-row theirs"><div className="day2-avatar">재</div><div className="day2-bubble">志晟啊<br/>看你有黑眼圈了<br/>没休息好吗？</div></div>
   {day2Chat.slice(0,p.chatCount).map(([who,line],i)=><div key={i} className={'day2-bubble-row '+(who==='朴志晟'?'mine':'theirs')}>
    {who!=='朴志晟'&&<div className="day2-avatar">재</div>}
    <div className="day2-bubble">{line}</div>
   </div>)}
  </div>
  <div className="day2-chat-compose">{p.chatCount<day2Chat.length && day2Chat[p.chatCount][0]==='朴志晟'?<button onClick={()=>p.onChatCount(p.chatCount+1)}>发送：{day2Chat[p.chatCount][1]}　➤</button>:<span>正在输入…</span>}</div>
 </>:<>
  <div className="day2-note-header"><button onClick={p.onExit}>‹ 备忘录</button><b>完成</b></div>
  <div className="day2-note-scroll" ref={scroll}>
   <h2>{day2Title}</h2><div className="day2-note-text">{day2Intro}</div>
   {showFull&&day2Segments.map((part,i)=>{
     if(i>0 && day2Segments.slice(0,i).some((seg,j)=>seg.options&&p.choices[j]===undefined))return null;
     const selected=p.choices[i];
     return <div key={i} className="day2-note-section"><div className="day2-note-text">{i===day2Segments.length-1 ? part.text.replace(/今天的记录就到这里\s*$/, '') : part.text}</div>
       {part.options && (selected===undefined?<div className="day2-choices">{part.options.map((option,k)=><button key={k} onClick={()=>p.onChoice(i,k)}>{option}</button>)}</div>:<div className="day2-note-text day2-chosen">{part.options[selected]}{'\n'}{part.results?.[selected]}</div>)}
       {i===day2Segments.length-1 && !part.options && (p.noteFinished ? <div className="day2-note-text">今天的记录就到这里</div> : <div className="day2-choices"><button onClick={p.onNoteFinished}>今天的记录就到这里</button></div>)}
     </div>;
   })}

  </div>

 </>}
 </div>;
}
