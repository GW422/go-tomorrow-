/** Persisted event plans. Reopening an app replays only overdue, not-yet-applied events. */
export type SocialEvent = {id:string; postId:string; kind:string; due:number; index:number; parentId?:string};
export function readEvents(raw:string):SocialEvent[] {
  try { const data:unknown=JSON.parse(raw); return Array.isArray(data) ? data.filter((v):v is SocialEvent => !!v && typeof v.id==="string" && typeof v.postId==="string" && typeof v.due==="number" && typeof v.kind==="string" && typeof v.index==="number") : []; } catch { return []; }
}
export function scheduleEvents(postId:string,kind:string,count:number,delay=1700,spacing=2300,parentId?:string):SocialEvent[] {
  const start=Date.now();
  return Array.from({length:count},(_,index)=>({id:`${postId}:${kind}:${start}:${index}`,postId,kind,due:start+delay+index*spacing,index,parentId}));
}
