import { describe, expect, it } from "vitest";
import { readEvents, scheduleEvents } from "./socialQueue";
describe("persisted social event plans", () => {
  it("survives serialization without changing ids or deadlines", () => {
    const events = scheduleEvents("post-1", "fan", 5, 1800, 2300);
    expect(readEvents(JSON.stringify(events))).toEqual(events);
    expect(new Set(events.map(e => e.id)).size).toBe(5);
    expect(events[4].due-events[0].due).toBe(9200);
  });
  it("ignores invalid or damaged stored queues", () => {
    expect(readEvents("not json")).toEqual([]);
    expect(readEvents('[{"id":3}]')).toEqual([]);
  });
  it("keeps reply parent id", () => {
    expect(scheduleEvents("p", "comment", 1, 100, 100, "parent")[0].parentId).toBe("parent");
  });
});
