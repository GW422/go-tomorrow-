/** Offline, deterministic fan copy. Each batch of 50 contains at most two repeats. */
export const fanAccounts = ["starry_jisung","moonlight_032","jsarchive_23","bluehour_07","only4dream_","nana__daily","jisunglover_","3to3_mo","dreamcloud_22","softest_js","peach_032","sleepy_dream","parkcloud_","daily_7dream","cloudnine_js","tinyplanet_","afterglow_23","dear_jisung","jisungarchive","nightwalk_07"];
const openings = ["宝宝","志晟啊","志晟","小星星","今天","刚刚","突然","最近","好耶","我想说","认真问一下","其实","顺便问问","看到这条","真的","还有","话说","现在","一直想问","想起来了"];
const topics = [
  "好耶是照片","终于等到新照片了","这张我很喜欢","还有库存照片吗","第二张是谁拍的","今天的照片很有秋天的感觉","谢谢分享今天的日常","这次照片拍得好舒服",
  "今天吃了什么","有没有好好吃饭","晚饭吃了吗","记得喝水","最近睡得好吗","今天练习辛苦了","不要太晚睡","今天有没有休息一下",
  "最近在听什么歌","今天做了什么","最近有看到好看的电影吗","这几天忙不忙","有没有什么新发现","最近天气是不是变冷了","今天心情怎么样","有没有想推荐的歌",
  "想看你直播聊天","下次直播想听你讲近况","有空来直播就好了","好想再听你分享歌单","直播的时候想听你聊日常","好久没看到随手拍的生活片段",
  "期待下次舞台","想看你和渽民哥一起拍点日常","最近和成员们都还好吗","有机会想看大家一起拍 vlog",
  "宝宝你知道最近造梦机的事情吗 感觉你会喜欢","看到有人讨论梦里的时间会变慢 好神奇","朋友说自己做了重复一天的梦 还挺有意思","最近那条关于梦境研究的新闻你看了吗",
];
const tails=["ㅎㅎ","ㅋㅋㅋ","ㅠㅠ","呢","呀",""," 我有点好奇"," 有空再说也没关系"," 感觉会很有趣"," 只是突然想到"," 希望你今天开心"," 最近总想到这个"," 想听听你的想法"," 我先去吃饭了"," 期待一下"," 记得休息"," 我会等的"," 今天也加油"," 看着就很开心"," 有点想知道"];
const reactions=["我靠宝宝","居然被回复了我的天","我截图了","啊我现在才看到","不是 我真的被回复了","今天运气也太好了","谢谢宝宝ㅎㅎ","突然不知道回什么了","好 我先冷静一下","收到 我也去吃饭了","好的宝宝","那我放心了","笑死 好的","我现在有点开心","居然看到了我的评论","好耶","那你也早点睡","这个回答我记住了","谢谢你回复我","我会好好听的"];
const hash=(s:string)=>{let h=2166136261;for(let i=0;i<s.length;i++)h=Math.imul(h^s.charCodeAt(i),16777619);return h>>>0;};
export function fanName(seed:string,index:number){return fanAccounts[(hash(seed)+index*7+Math.floor(index/20))%fanAccounts.length];}
/** Stable per-post variations; index 0..49 has no duplicate text. */
export function fanCopy(seed:string,index:number,kind:"comment"|"mention"|"reaction"="comment"){
  const shift=hash(seed)%topics.length;
  if(kind==="reaction")return reactions[(hash(seed)+index*7)%reactions.length];
  const topic=topics[(shift+index*17)%topics.length];
  const opening=openings[(hash(seed+":o")+index*9)%openings.length];
  const tail=tails[(hash(seed+":t")+index*11)%tails.length];
  const body=index%3===0?topic+tail:`${opening} ${topic}${tail}`;
  return kind==="mention"?`@志晟_JISUNG ${body}`:body;
}
export function makeFanBatch(seed:string,count:number,kind:"comment"|"mention"|"reaction"="comment"){
  const seen=new Set<string>();const result:string[]=[];
  for(let i=0;i<count;i++){
    let value=fanCopy(seed,i,kind), attempt=0;
    while(seen.has(value) && attempt++<100) value=fanCopy(seed+":"+attempt,i+attempt*3,kind);
    if(seen.has(value))value+=` ${i+1}`;
    seen.add(value);result.push(value);
  }
  return result;
}
