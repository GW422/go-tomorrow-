// Fictional social posts for the second traversal of October 22.
// Scientific extrapolations in this story are not established experimental results.
export const day2XPosts = [
  {
    id: 'x-day2-glueball-research', title: '', sender: 'science_frontier', time: '2026-10-22 09:16', likes: 18742, media: '',
    body: `Experimental Glueball Program Reports Anomalous Local Timing Effects\n\nResearchers working with a newly stabilized, high-density glueball system report unexpected discrepancies between synchronized clocks placed around the apparatus. The team cautions that calibration errors and environmental interference have not yet been ruled out. The proposed link between the system and local spacetime behavior remains hypothetical.\n\n实验性胶球项目报告异常局部计时现象\n\n研究人员称，在一种新型稳定化高密度胶球系统周围，同步校准的计时设备出现了难以解释的读数差异。团队强调，目前尚未排除校准误差和环境干扰。该系统与局部时空行为之间的联系仍属假说。`,
    comments: ['astro_soup: 时钟读数不一样就能说明时间被改变了吗？', 'quantum_reader: 不能，首先要排除仪器误差。新闻里也说了还没有确认。', 'astro_soup: 但如果是真的也太吓人了吧。', 'physics_nerd: 胶球是强相互作用理论里的东西，时空效应是这里报道的后续实验假设，别混成一件已证实的事。'],
    meta: {handle:'science_frontier',views:'243,100',commentCount:'4',verified:'true'}
  },
  {
    id: 'x-day2-dream-research', title: '', sender: 'science_frontier', time: '2026-10-22 10:05', likes: 28416, media: '',
    body: `High-Density Glueball Systems Prompt New Questions About Local Spacetime

Following recent reports of unusual clock discrepancies near a stabilized glueball apparatus, physicists are investigating whether sufficiently concentrated energy in the experimental system could affect local measurements. The proposed threshold has not been independently verified, and the observed anomalies may still have conventional explanations.

高密度胶球系统引发局部时空研究的新疑问

继稳定化胶球装置附近出现异常计时读数的报告后，研究人员开始探讨：当实验系统中的能量达到一定集中程度时，是否可能影响局部测量结果。目前尚未独立证实所谓的临界条件，已观测到的异常也可能存在常规解释。`,
    comments: ['space_enthusiast: 所以关键不是发现胶球，而是能不能让它们稳定聚集到一定程度？', 'physics_nerd: 这只是研究假说，不能把计时异常直接解释成时空发生了变化。', 'clockmaker: 我更好奇不同位置的设备为什么会出现读数差异，排除干扰了吗？', 'science_frontier: 团队表示仍在复核测量条件，尚无确定结论。'],
    meta:{handle:'science_frontier',views:'382,500',commentCount:'4',verified:'true'}
  },
  {
    id:'x-day2-loop-friend', title:'', sender:'cafe_afterhours', time:'2026-10-22 11:32', likes: 2635, media:'',
    body:'哇疯了，我朋友说他已经经历过一次今天了，这难道不是电影台词吗？但他真的知道我今天出门会被狗咬',
    comments:[
      'puppy_lover: ㅋㅋㅋㅋ说不定他昨天回家时遇见过疯狗，所以提醒你不要走那条路',
      'cafe_afterhours: 可我是在咖啡馆工作的时候被随机一个路人怀里抱着的狗咬的啊？他连路过的人也看到了吗？',
      'latte_ice: 等等，真的咬到了？先去处理伤口啊！！',
      'cafe_afterhours: 已经处理过了ㅠㅠ 我现在比较想知道他为什么连几点都说对。',
      'monday_again: 你朋友是不是偷偷看过监控然后整你？',
      'cafe_afterhours: 监控也不可能提前拍到今天发生的事吧ㅋㅋㅋ',
      'quiet_reader: 那你问问他明天会发生什么。',
      'cafe_afterhours: 他听到“明天”两个字突然不说话了，搞得我更害怕了。'
    ],meta:{handle:'cafe_afterhours',views:'58,900',commentCount:'8',verified:'false'}
  },
  {
    id:'x-day2-what-is-glueball', title:'', sender:'just_asking_22', time:'2026-10-22 12:11', likes: 1328, media:'',
    body:'今天刷到三次胶球新闻了……胶球到底是什么？是胶水做的球吗？',
    comments:[
      'science_student: 不是胶水ㅋㅋㅋ 胶球是粒子物理里假设由胶子束缚形成的复合态。胶子负责传递强相互作用。',
      'just_asking_22: 胶子又是什么啊，我连解释都听不懂ㅠㅠ',
      'science_student: 可以先把它理解成让夸克之间产生强相互作用的粒子。特别的是，理论上胶子自己也可能组成束缚态。',
      'august_archive: 今年八月有关于胶球候选信号的报道，所以大家又开始讨论它；但候选证据和最终确认不是一回事。',
      'just_asking_22: 那今天新闻里说的影响时间也是八月发现的？',
      'august_archive: 不是！今天讲的是这个故事世界里后续稳定化实验的新结果，时空解释还没得到证实。',
      'nightowl_11: 所以从“可能找到胶球”一下跳到“时间会乱掉”，中间也跳太远了吧ㅋㅋㅋ',
      'science_student: 对，严谨点说只是设备附近出现异常计时现象，原因还在排查。',
      'just_asking_22: 明白了，胶球不是胶水球，时间机器也还没造出来。谢谢大家！'
    ],meta:{handle:'just_asking_22',views:'34,600',commentCount:'9',verified:'false'}
  }
];
