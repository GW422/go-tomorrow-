from pathlib import Path
p=Path('/mnt/data/day1_build/src/Phone.tsx');s=p.read_text()
needle='  const read = (i: Item) => {'
addition='''  const kakaoState = state.ui?.kakao ?? {};
  const getCursor = (key: string, fallback: number) => typeof kakaoState[key] === "number" ? Number(kakaoState[key]) : fallback;
  const messagesOf = (title: string) => (work.data.kakao ?? []).filter(m => m.title === title && m.meta.placeholder !== "true");
  const stageEnd = (title: string) => messagesOf(title).length;
  const extraCursors:Record<string,number> = (() => { try { return JSON.parse(String(kakaoState.gtExtraCursors || "{}")); } catch { return {}; } })();
  const initialScript = (title:string) => {const i=messagesOf(title).findIndex(m=>m.meta.scriptedDay === "true");return i<0?messagesOf(title).length:i;};
  const extraInitial = (title:string) => {const i=messagesOf(title).findIndex(m=>m.id.startsWith("gt-day1-v3-"));return i<0?messagesOf(title).length:i;};
  const gtChatComplete = [
    getCursor("mymyKktVisible",initialScript("재민형"))>=stageEnd("재민형"),
    getCursor("mymyHaechanCount",initialScript("해찬형"))>=stageEnd("해찬형"),
    (extraCursors["천러"]??extraInitial("천러"))>=stageEnd("천러"),
    (extraCursors["드림💚"]??extraInitial("드림💚"))>=stageEnd("드림💚"),
  ].every(Boolean);
  const notes = work.data.notes ?? [];
  const mail = work.data.mail ?? [];
  const gtGateReady = gtChatComplete && notes.every(m=>state.read.includes(m.id)) &&
    mail.every(m=>m.outgoing || m.read || state.read.includes(m.id)) &&
    Boolean(state.ui?.mail?.gtOpened) && Boolean(state.ui?.x?.gtOpened) &&
    Boolean(state.ui?.instagram?.gtOpened || state.ui?.ins?.gtOpened) &&
    String(kakaoState.gtClock || "") === "23:59";
'''
s=s.replace(needle,addition+needle)
s=s.replace('              ui={state.ui?.[app.id]}','              ui={app.id === "calendar" ? {...state.ui?.[app.id],gtGateReady} : state.ui?.[app.id]}',1)
p.write_text(s)
p=Path('/mnt/data/day1_build/src/skins/SystemSkins.tsx');s=p.read_text();s=s.replace('  const [tomorrow, setTomorrow] = useState(false);','  const [tomorrow, setTomorrow] = useState(false);\n  const [gtWarning, setGtWarning] = useState(false);\n  const [gtRestartConfirm, setGtRestartConfirm] = useState(false);')
s=s.replace('onClick={() => setTomorrow(true)}','onClick={() => {if (p.ui?.gtGateReady === true) {setGtWarning(false);setTomorrow(true);p.onUi?.("gtTomorrow",true);} else {setGtWarning(true);window.setTimeout(()=>setGtWarning(false),3500);}}}')
s=s.replace('        <Add p={p} label="添加日程" />','        {gtWarning && <div role="alert" style={{textAlign:"center",padding:12,color:"#d65753"}}>您似乎还没有找到全部线索，再看看吧！</div>}\n        <Add p={p} label="添加日程" />',1)
s=s.replace('          <div className="tomorrow-screen-copy"><div className="tomorrow-screen-title">','          <button type="button" onClick={()=>setGtRestartConfirm(true)} style={{position:"absolute",right:18,bottom:22,zIndex:10,background:"transparent",border:0,color:"#ccc",fontSize:12}}>重新开始</button>\n          {gtRestartConfirm && <div style={{position:"absolute",inset:0,zIndex:20,background:"#111e",display:"flex",alignItems:"center",justifyContent:"center",flexDirection:"column",gap:18,color:"white"}}><div>确定从头开始吗？当前进度将被清除。</div><button onClick={()=>{p.onUi?.("gtRestart",true);setTomorrow(false);setGtRestartConfirm(false);}}>确定重新开始</button><button onClick={()=>setGtRestartConfirm(false)}>取消</button></div>}\n          <div className="tomorrow-screen-copy"><div className="tomorrow-screen-title">',1)
p.write_text(s)
