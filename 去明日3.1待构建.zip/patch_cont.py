from pathlib import Path
p=Path('src/Phone.tsx'); s=p.read_text();s='import { day2Scenes } from "./day2Continuation";\n'+s
s=s.replace('  const day2Visible = Number(kakaoUi.gtDay2Visible || 0);','''  const contStage = Number(day2Ui.gtContStage ?? -1);
  const contVisible = Number(kakaoUi.gtContVisible || 0);
  const contStarted = Boolean(day2Ui.gtContStarted);
  const contScene = contStage >= 0 ? day2Scenes[contStage] : undefined;
  // Scene cursor, visibility and timing are persisted with the same runtime save.
  useEffect(()=>{
    if (!day2Active || locked || !ready || !contScene || contStarted) return;
    const timer=window.setTimeout(()=>{
      const current=runtimeRef.current;
      if(Number(current.ui?.calendar?.gtContStage ?? -1)!==contStage)return;
      update({...current,time:contScene.time,ui:{...current.ui,calendar:{...current.ui?.calendar,gtContStarted:true}}});
    },contScene.wait);
    return()=>window.clearTimeout(timer);
  },[day2Active,locked,ready,contStage,contStarted]);
  useEffect(()=>{
    if (!day2Active || locked || !ready || !contScene || !contStarted || contVisible>=contScene.lines.length)return;
    const [who,line]=contScene.lines[contVisible];
    if(who==='朴志晟')return;
    const timer=window.setTimeout(()=>{
      const current=runtimeRef.current;const k=current.ui?.kakao??{};
      if(Number(k.gtContVisible||0)!==contVisible)return;
      update({...current,ui:{...current.ui,kakao:{...k,gtContVisible:contVisible+1}}});
      if(!document.querySelector(`.mymy-kakao .msgs[data-thread="${contScene.thread}"]`))enqueueBanner(`KakaoTalk：${contScene.thread}：${line}`);
    },1200);
    return()=>window.clearTimeout(timer);
  },[day2Active,locked,ready,contStage,contVisible,contStarted]);
  useEffect(()=>{
    if (!day2Active || !contScene || !contStarted || contVisible<contScene.lines.length)return;
    const timer=window.setTimeout(()=>{
      const current=runtimeRef.current;
      if(Number(current.ui?.calendar?.gtContStage??-1)!==contStage)return;
      update({...current,ui:{...current.ui,calendar:{...current.ui?.calendar,gtContStage:contStage+1,gtContStarted:false},kakao:{...current.ui?.kakao,gtContVisible:0}}});
    },contStage===day2Scenes.length-1?0:150);
    return()=>window.clearTimeout(timer);
  },[day2Active,contStage,contVisible,contStarted]);
  const day2Visible = Number(kakaoUi.gtDay2Visible || 0);''')
s=s.replace('                      ...day2Chat.map(([who,line],i)=>', '''                      ...day2Scenes.flatMap((scene,sceneIndex)=>sceneIndex>contStage?[]:scene.lines.map(([who,line],i)=>({...((work.data.kakao??[]).find(m=>m.title===scene.thread)??(work.data.kakao??[])[0]),id:`gt-cont-${sceneIndex}-${i}`,title:scene.thread,body:line,time:`2026-10-22 ${scene.time}`,sender:who,outgoing:who==='朴志晟',meta:{scriptedDay:'true',scriptedReply:who==='朴志晟'?'true':'false',gtStage:'day2-cont'}}))),
                      ...day2Chat.map(([who,line],i)=>''')
s=s.replace('onNoteFinished={()=>day2Set({gtDay2NoteComplete:true})}', '''onNoteFinished={()=>{
                const current=runtimeRef.current;
                if(current.ui?.calendar?.gtDay2NoteComplete)return;
                update({...current,time:'07:36',ui:{...current.ui,calendar:{...current.ui?.calendar,gtDay2NoteComplete:true,gtContStage:0,gtContStarted:false},kakao:{...current.ui?.kakao,gtContVisible:0}}});
              }}''')
s=s.replace('              onExit={()=>{setDay2NoteVisible(false);', '              noteFinished={Boolean(day2Ui.gtDay2NoteComplete)}\n              onExit={()=>{setDay2NoteVisible(false);')
p.write_text(s)
p=Path('src/Day2Experience.tsx');s=p.read_text().replace('onNoteFinished:()=>void;};','onNoteFinished:()=>void; noteFinished?:boolean;};')
s=s.replace('<div className="day2-note-text">{part.text}</div>', '''<div className="day2-note-text">{i===day2Segments.length-1 ? part.text.replace(/今天的记录就到这里\\s*$/, '') : part.text}</div>''')
s=s.replace('     </div>;','''       {i===day2Segments.length-1 && !part.options && (p.noteFinished ? <div className="day2-note-text">今天的记录就到这里</div> : <div className="day2-choices"><button onClick={p.onNoteFinished}>今天的记录就到这里</button></div>)}
     </div>;''')
p.write_text(s)
