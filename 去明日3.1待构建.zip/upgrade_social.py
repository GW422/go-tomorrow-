from pathlib import Path
w=Path('src/skins/SocialSkins.tsx');s=w.read_text()
# independent mention feed and reply, persisted per cycle
s=s.replace('const [mentionOpen,setMentionOpen]=useState(false);','''const [mentionOpen,setMentionOpen]=useState(false);
  const [mentionRepliesRaw,setMentionRepliesRaw]=useSkinState<string>(p,`gtWeiboMentionReplies-${p.cycleIndex||1}`,"{}");
  const [mentionReplyDraft,setMentionReplyDraft]=useState("");
  const [mentionTarget,setMentionTarget]=useState("");
  const [likedPlayerPosts,setLikedPlayerPosts]=useSkinState<string[]>(p,`gtWeiboPlayerLikes-${p.cycleIndex||1}`,[]);
  const [socialToast,setSocialToast]=useState("");
  const mentionUsers=["starry_jisung","softcloud_032","nctdream_daily","moonwalk_js","cloudy_park23"];
  const mentionBodies=["@志晟_JISUNG 今天有好好吃饭吗？看到你发微博就安心了ㅠㅠ","@志晟_JISUNG 下次直播可以聊聊最近听的歌吗？","@志晟_JISUNG 真的好想念舞台上的你！","@志晟_JISUNG 今天的天空很漂亮，想分享给你","@志晟_JISUNG 希望你和成员们都好好休息ㅎㅎ"];
  let mentionReplies:Record<string,string>={};try{const x=JSON.parse(mentionRepliesRaw);if(x&&typeof x==="object"&&!Array.isArray(x))mentionReplies=x;}catch{}
  const mentionEntries=mentionUsers.map((name,index)=>({id:`mention-${index}`,name,body:mentionBodies[index]}));''')
s=s.replace('const events=scheduleEvents(post.id,"fan",4+Math.floor(Math.random()*4),1600,2300,parentId||id);','const events=scheduleEvents(post.id,"fan",4+Math.floor(Math.random()*4),1600,2300,id);')
s=s.replace('queueRef.current=next;setQueueRaw(JSON.stringify(next));applyEvent(due);','applyEvent(due);queueRef.current=next;setQueueRaw(JSON.stringify(next));')
s=s.replace('setDraft("");setPhoto("");setComposer(false);setProfile(true);setTab("我");','setDraft("");setPhoto("");setComposer(false);setProfile(true);setTab("我");setSocialToast("微博发布成功");')
s=s.replace('{egg&&<div className="gt-wb-egg">♡ n8_3m 赞了你的微博</div>}','{egg&&<div className="gt-wb-egg">♡ n8_3m 赞了你的微博</div>}{socialToast&&<button className="gt-wb-toast" onClick={()=>setSocialToast("")}>{socialToast} ×</button>}')
start=s.index('      {tab==="消息"&&!profile?')
end=s.index('      profile||tab==="我"?',start)
s=s[:start]+'''      {tab==="消息"&&!profile?<div className="gt-wb-notifications"><h2>消息 <small>{(activity[0]?.id===lastSeenActivityId?0:activity.length)} 条未读</small></h2>
        <div className="gt-wb-message-categories"><button onClick={()=>setMentionOpen(false)}>♡ 赞与评论</button><button onClick={()=>setMentionOpen(true)}>＠ 提及我的</button></div>
        {mentionOpen?<div className="gt-wb-mentions"><h3>提及我的</h3>{mentionEntries.map(m=><article className="gt-wb-mention-post" key={m.id}><div className="gt-wb-author"><span className="gt-wb-fan-avatar">{m.name[0].toUpperCase()}</span><div><b>{m.name}</b><small>10月22日 · 来自微博</small></div></div><p>{m.body}</p><div className="gt-wb-mention-actions"><button onClick={()=>setMentionTarget(mentionTarget===m.id?"":m.id)}>回复</button><span>♡　评论　转发</span></div>{mentionReplies[m.id]&&<p className="gt-wb-mention-reply"><b>志晟_JISUNG：</b>{mentionReplies[m.id]}</p>}{mentionTarget===m.id&&<form className="gt-wb-mention-form" onSubmit={e=>{e.preventDefault();if(!mentionReplyDraft.trim())return;setMentionRepliesRaw(JSON.stringify({...mentionReplies,[m.id]:mentionReplyDraft.trim()}));setMentionReplyDraft("");setMentionTarget("");setSocialToast("回复已发布");}}><input aria-label="回复粉丝提及" value={mentionReplyDraft} onChange={e=>setMentionReplyDraft(e.target.value)} placeholder={`回复 @${m.name}`}/><button type="submit">发送</button></form>}</article>)}</div>:<div className="gt-wb-activity-feed">{activity.map(a=><div className="gt-wb-activity" key={a.id}><span>♡</span>{a.body}<small>刚刚</small></div>)}{!activity.length&&<p>暂时没有新消息</p>}</div>}
      </div>:
''' + s[end:]
s=s.replace('<button onClick={()=>notify("你赞了这条微博")}>♡ {post.likes||"赞"}</button>','<button aria-pressed={likedPlayerPosts.includes(post.id)} onClick={()=>setLikedPlayerPosts(likedPlayerPosts.includes(post.id)?likedPlayerPosts.filter(v=>v!==post.id):[...likedPlayerPosts,post.id])}>♡ {post.likes+(likedPlayerPosts.includes(post.id)?1:0)||"赞"}</button>')
s=s.replace('setActivityRead(activity.length);setLastSeenActivityId(activity[0]?.id||"");}}>▣','setActivityRead(activity.length);setLastSeenActivityId(activity[0]?.id||"");setMentionOpen(false);}}>▣')
w.write_text(s)
# Instagram: idempotent event handling, better comment and activity controls
w=Path('src/vendor/mymy/Apps.tsx');s=w.read_text()
s=s.replace('igQueueRef.current=next;setIgQueueRaw(JSON.stringify(next));\n      const names=', 'const names=')
s=s.replace('      else if(due.kind==="member")addActivity(`${ownPostsRef.current.find(v=>v.id===due.postId)?.members[due.index]||"dream_member"} liked your photo`,due.id);\n    },650);','''      else if(due.kind==="member")addActivity(`${ownPostsRef.current.find(v=>v.id===due.postId)?.members[due.index]||"dream_member"} liked your photo`,due.id);
      igQueueRef.current=next;setIgQueueRaw(JSON.stringify(next));
    },650);''')
# remove early return on duplicate comment so event is cleared
s=s.replace('if(igThreadRef.current.some(c=>c.id===due.id))return;','if(igThreadRef.current.some(c=>c.id===due.id)){igQueueRef.current=next;setIgQueueRaw(JSON.stringify(next));return;}')
s=s.replace('const [replyTarget,setReplyTarget]=useState("");','''const [replyTarget,setReplyTarget]=useState("");
  const [expandedReplies,setExpandedReplies]=useState<string[]>([]);
  const [igActivityToast,setIgActivityToast]=useState("");''')
s=s.replace('const unreadActivity=activity.length>0 && activity[0].id!==lastSeenActivityId;', 'const unreadActivity=activity.length>0 && activity[0].id!==lastSeenActivityId;')
s=s.replace('const next=[{id,text,time:"刚刚"},...activityRef.current].slice(0,70);','const next=[{id,text,time:"刚刚"},...activityRef.current].slice(0,70);setIgActivityToast(text);')
s=s.replace('{postNotice&&<div className="gt-ig-post-toast"', '{igActivityToast&&!activityOpen&&<button className="gt-ig-live-activity" role="status" onClick={()=>{setActivityOpen(true);setLastSeenActivityId(activity[0]?.id||"");setIgActivityToast("");}}>{igActivityToast} · 查看通知</button>}\n      {postNotice&&<div className="gt-ig-post-toast"')
# replace comments list with grouped threaded comments; parent replies initially collapsed
old='''{igThread.filter(c=>c.postId===commentsPost.id).map(c=><div key={c.id} className="gt-ig-thread-comment" style={{paddingLeft:c.parentId?24:0}}><span className="gt-ig-thread-avatar">{c.name.slice(0,1).toUpperCase()}</span><div><b>{c.name}</b> {c.text}<small>刚刚　<button type="button" onClick={()=>{setReplyTarget(c.id);setCommentDraft(`@${c.name} `);}}>Reply</button>{c.parentId&&<span className="gt-ig-reply-indicator"> ↳ 回复</span>}</small></div><button type="button" className="gt-ig-comment-like" aria-label="点赞评论" aria-pressed={likedCommentIds.includes(c.id)} onClick={()=>setLikedCommentIds(likedCommentIds.includes(c.id)?likedCommentIds.filter(v=>v!==c.id):[...likedCommentIds,c.id])}><Heart size={14} fill={likedCommentIds.includes(c.id)?"#e54465":"none"}/></button></div>)}'''
new='''{igThread.filter(c=>c.postId===commentsPost.id&&!c.parentId).map(c=>{const replies=igThread.filter(r=>r.postId===commentsPost.id&&r.parentId===c.id);const renderComment=(entry:ThreadComment,nested=false)=><div key={entry.id} className={`gt-ig-thread-comment ${nested?"gt-ig-thread-nested":""}`}><span className="gt-ig-thread-avatar">{entry.name.slice(0,1).toUpperCase()}</span><div><b>{entry.name}</b> {entry.text}<small>刚刚　<button type="button" onClick={()=>{setReplyTarget(entry.id);setCommentDraft(`@${entry.name} `);}}>Reply</button></small></div><button type="button" className="gt-ig-comment-like" aria-label="点赞评论" aria-pressed={likedCommentIds.includes(entry.id)} onClick={()=>setLikedCommentIds(likedCommentIds.includes(entry.id)?likedCommentIds.filter(v=>v!==entry.id):[...likedCommentIds,entry.id])}><Heart size={14} fill={likedCommentIds.includes(entry.id)?"#e54465":"none"}/></button></div>;return <div className="gt-ig-comment-thread" key={c.id}>{renderComment(c)}{replies.length>0&&<><button type="button" className="gt-ig-view-replies" onClick={()=>setExpandedReplies(expandedReplies.includes(c.id)?expandedReplies.filter(v=>v!==c.id):[...expandedReplies,c.id])}>{expandedReplies.includes(c.id)?"隐藏回复":`── 查看 ${replies.length} 条回复`}</button>{expandedReplies.includes(c.id)&&replies.map(r=>renderComment(r,true))}</>}</div>;})}'''
assert old in s
s=s.replace(old,new)
s=s.replace('setCommentDraft("");setReplyTarget("");}}>', 'setCommentDraft("");setReplyTarget("");if(replyTarget)setExpandedReplies(v=>v.includes(replyTarget)?v:[...v,replyTarget]);}}>')
w.write_text(s)
# Styles
css=Path('src/skins/skins.css');css.write_text(css.read_text()+'''\n/* Social feed and mentions: scoped; no effect on startup or other applications. */
.gt-wb-message-categories{display:flex;gap:8px;margin:14px 0}.gt-wb-message-categories button{flex:1;background:#fff4eb;border:1px solid #ffe3c9;border-radius:12px;padding:12px 5px;color:#b96023;font-size:12px}.gt-wb-mention-post{padding:15px 0;border-bottom:1px solid #eee;background:white}.gt-wb-mention-post>p{line-height:1.7;font-size:13px;white-space:pre-wrap}.gt-wb-mention-actions{display:flex;align-items:center;justify-content:space-between;color:#999}.gt-wb-mention-actions button{border:0;background:none;color:#e77d34}.gt-wb-mention-reply{background:#f8f8f8;padding:10px;border-radius:8px}.gt-wb-mention-form{display:flex;gap:8px;margin-top:12px}.gt-wb-mention-form input{flex:1;min-width:0;padding:9px;border:1px solid #ddd;border-radius:14px}.gt-wb-mention-form button{border:0;background:#ff8b36;color:white;border-radius:14px;padding:8px 14px}.gt-wb-toast{width:100%;padding:10px;border:0;background:#fff0e2;color:#a85e20}.gt-ig-comment-thread{border-bottom:1px solid #f5f5f5;padding:6px 0}.gt-ig-thread-nested{margin-left:38px}.gt-ig-view-replies{margin:4px 0 10px 45px;border:0;background:none;color:#777;font-size:12px}.gt-ig-live-activity{position:absolute;z-index:55;top:53px;left:12px;right:12px;border:1px solid #eee;border-radius:14px;padding:12px;background:#fff;box-shadow:0 4px 20px #0002;text-align:left;color:#222;font-size:12px}\n''')
