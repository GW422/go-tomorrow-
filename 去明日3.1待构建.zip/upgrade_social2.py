from pathlib import Path
w=Path('src/skins/SocialSkins.tsx');s=w.read_text()
s=s.replace('const events=scheduleEvents(id,"fan",4,1800,2400);','const events=[...scheduleEvents(id,"fan",4+Math.floor(Math.random()*4),1800,2400),...scheduleEvents(id,"mention",1,11000)];')
s=s.replace('else if(event.kind==="egg-like") {setEgg(true);notify("n8_3m 赞了你的微博",event.id);}', 'else if(event.kind==="mention") {notify("@starry_jisung 在微博中提及了你",event.id);}\n    else if(event.kind==="egg-like") {setEgg(true);notify("n8_3m 赞了你的微博",event.id);}')
s=s.replace('{tab==="消息"&&!profile?', '{tab==="消息"&&!profile?')
s=s.replace('profile||tab==="我"?<>','profile||tab==="我"?<>')
s=s.replace('</>:<><div className="gt-wb-feed-tabs">','</>:<>{tab==="发现"&&<div className="gt-wb-discover"><h3>发现 · 热门话题</h3><button onClick={()=>setDraft("#今天的天空# ")}>#今天的天空#</button><button onClick={()=>setDraft("#最近在听的歌# ")}>#最近在听的歌#</button><button onClick={()=>setDraft("#记录生活# ")}>#记录生活#</button><p>看看大家正在讨论什么</p></div>}<div className="gt-wb-feed-tabs">')
s=s.replace('<button onClick={()=>setTab("发现")}>发现</button>','<button onClick={()=>setTab("发现")}>发现</button>')
w.write_text(s)
w=Path('src/vendor/mymy/Apps.tsx');s=w.read_text()
s=s.replace('const [eggNotice,setEggNotice]=useState(false);','const [eggNotice,setEggNotice]=useState(false);\n  const [eggLikedPostIds,setEggLikedPostIds]=useSkinState<string[]>(p,`gtIgEggLikes-${p.cycleIndex||1}`,[]);')
s=s.replace('else if(due.kind==="egg-like") {setEggNotice(true);addActivity("n8_3m liked your photo",due.id);}', 'else if(due.kind==="egg-like") {setEggNotice(true);setEggLikedPostIds(v=>v.includes(due.postId)?v:[...v,due.postId]);addActivity("n8_3m liked your photo",due.id);}')
s=s.replace('else if(due.kind==="egg-unlike") {setEggNotice(false);addActivity("n8_3m unliked your photo",due.id);}', 'else if(due.kind==="egg-unlike") {setEggNotice(false);setEggLikedPostIds(v=>v.filter(id=>id!==due.postId));addActivity("n8_3m unliked your photo",due.id);}')
s=s.replace('value={post.likes} />','value={post.likes} />')
# don't hardcode 1 + member likes as visible immediately: actual events are gradual
s=s.replace('likes:String(1+v.members.length),comments:String(igThread.filter(c=>c.postId===v.id).length)', 'likes:String(activity.filter(a=>a.text.includes("liked your photo")&&a.id.startsWith(v.id+":")).length-(eggLikedPostIds.includes(v.id)?0:activity.filter(a=>a.text.includes("n8_3m liked your photo")&&a.id.startsWith(v.id+":")).length)),comments:String(igThread.filter(c=>c.postId===v.id).length)')
# existing notification activity UI should not be text-only; show names and post thumbnails from ownPosts
old='''{activity.length?activity.map(a=><div key={a.id}><span className="gt-ig-activity-avatar">{a.text.slice(0,1).toUpperCase()}</span><span>{a.text}<small>{a.time}</small></span><Heart size={17}/></div>):<p>No new activity yet.</p>}'''
new='''{activity.length?activity.map(a=>{const author=a.text.split(" ")[0];const post=ownPosts.find(v=>a.id.startsWith(v.id+":"));return <div key={a.id} className="gt-ig-notification-row"><span className="gt-ig-activity-avatar">{author.slice(0,1).toUpperCase()}</span><span><b>{author}</b> {a.text.slice(author.length).trim()}<small>{a.time}</small></span>{post?<button type="button" aria-label="查看被互动的帖子" onClick={()=>{setActivityOpen(false);setSelectedPostId(post.id);setSelectedUser(ownProfileName);setView("detail");}}><PlayerPhoto src={post.media} alt="帖子缩略图"/></button>:<Heart size={17}/>}</div>}):<p>No new activity yet.</p>}'''
assert old in s;s=s.replace(old,new)
w.write_text(s)
css=Path('src/skins/skins.css');css.write_text(css.read_text()+'''\n.gt-wb-discover{padding:15px;background:#fff;margin-bottom:8px}.gt-wb-discover h3{font-size:15px}.gt-wb-discover button{display:inline-block;margin:4px;border:0;background:#fff4e9;border-radius:14px;color:#bd642b;padding:8px}.gt-wb-discover p{color:#999;font-size:12px}.gt-ig-notification-row>button{padding:0;border:0;background:none;width:42px;height:42px;flex-shrink:0}.gt-ig-notification-row>button img{width:42px;height:42px;object-fit:cover;border-radius:5px}.gt-ig-notification-row>span:nth-child(2){flex:1;min-width:0}.gt-ig-notification-row small{display:block;color:#999}\n''')
