from pathlib import Path
p=Path('/mnt/data/gt_fix/src/skins/SocialSkins.tsx');s=p.read_text()
s=s.replace('import { compactXCount } from "./compactXCount";', 'import { compactXCount } from "./compactXCount";\nimport {PlayerPhoto,preparePlayerPhoto} from "../socialLocal";\nimport {readEvents,scheduleEvents} from "../socialQueue";')
s=s.replace('  const [photo,setPhoto]=useState("");','  const [photo,setPhoto]=useState("");\n  const [photoError,setPhotoError]=useState("");\n  const [queueRaw,setQueueRaw]=useSkinState<string>(p,`gtWeiboQueue-${p.cycleIndex||1}`,"[]");\n  const queueRef=useRef(readEvents(queueRaw));queueRef.current=readEvents(queueRaw);')
s=s.replace('  type FanComment={id:string;name:string;text:string};','  type FanComment={id:string;name:string;text:string;parentId?:string};')
s=s.replace('  const notify=(body:string)=>{const next=[{id:`n-${Date.now()}-${Math.random()}`,body},...activityRef.current].slice(0,90);activityRef.current=next;setActivityRaw(JSON.stringify(next));};','  const notify=(body:string,id=`n-${Date.now()}-${Math.random()}`)=>{if(activityRef.current.some(a=>a.id===id))return;const next=[{id,body},...activityRef.current].slice(0,90);activityRef.current=next;setActivityRaw(JSON.stringify(next));};')
start=s.index('  const addFan=(id:string,step:number)=>{')
end=s.index('  const avatar=',start)
s=s[:start]+'''  const applyEvent=(event:ReturnType<typeof readEvents>[number])=>{
    const post=postsRef.current.find(v=>v.id===event.postId);
    if(!post)return;
    if(event.kind==="fan"){
      if(post.comments.some(c=>c.id===event.id))return;
      const name=fanIds[(event.index+post.comments.length)%fanIds.length];
      const comment={id:event.id,name,text:fanText[(event.index*3+post.comments.length)%fanText.length],parentId:event.parentId};
      const next=postsRef.current.map(v=>v.id===event.postId?{...v,likes:v.likes+1,comments:[...v.comments,comment]}:v);
      postsRef.current=next;setPostedRaw(JSON.stringify(next.slice(0,24)));
      notify(`${name} 评论了你的微博`,event.id);
    }else if(event.kind==="egg-like") {setEgg(true);notify("n8_3m 赞了你的微博",event.id);}
    else if(event.kind==="egg-unlike") {setEgg(false);notify("n8_3m 取消了对你微博的赞",event.id);}
  };
  useEffect(()=>{
    const timer=window.setInterval(()=>{
      const due=queueRef.current.find(e=>e.due<=Date.now());if(!due)return;
      const next=queueRef.current.filter(e=>e.id!==due.id);
      queueRef.current=next;setQueueRaw(JSON.stringify(next));applyEvent(due);
    },650);
    return ()=>window.clearInterval(timer);
  },[p.cycleIndex]);
  const publish=()=>{
    if(!draft.trim())return;
    const id=`wb-${Date.now()}`;
    const next=[{id,body:draft.trim(),comments:[],likes:0,image:photo},...postsRef.current];postsRef.current=next;setPostedRaw(JSON.stringify(next.slice(0,24)));
    const events=scheduleEvents(id,"fan",4,1800,2400);
    if(Math.random()<.7)events.push(...scheduleEvents(id,"egg-like",1,11500),...scheduleEvents(id,"egg-unlike",1,13600));
    queueRef.current=[...queueRef.current,...events];setQueueRaw(JSON.stringify(queueRef.current));
    setDraft("");setPhoto("");setComposer(false);setProfile(true);setTab("我");
  };
  const reply=(post:PlayerPost,parentId?:string)=>{
    if(!replyDraft.trim())return;
    const id=`self-${Date.now()}`;
    const next=postsRef.current.map(v=>v.id===post.id?{...v,comments:[...v.comments,{id,name:"志晟_JISUNG",text:replyDraft.trim(),parentId}]}:v);
    postsRef.current=next;setPostedRaw(JSON.stringify(next));setReplyDraft("");
    const events=scheduleEvents(post.id,"fan",4+Math.floor(Math.random()*4),1600,2300,id);
    queueRef.current=[...queueRef.current,...events];setQueueRaw(JSON.stringify(queueRef.current));
  };
''' +s[end:]
old='''<label className="gt-wb-photo-label">▧ 从相册选择图片<input type="file" accept="image/*" onChange={e=>{const file=e.target.files?.[0];if(!file)return;const reader=new FileReader();reader.onload=()=>{const img=new Image();img.onload=()=>{const c=document.createElement("canvas");const r=Math.min(1,650/Math.max(img.width,img.height));c.width=Math.round(img.width*r);c.height=Math.round(img.height*r);c.getContext("2d")?.drawImage(img,0,0,c.width,c.height);setPhoto(c.toDataURL("image/jpeg",.55));};img.src=String(reader.result||"");};reader.readAsDataURL(file);}}/></label>{photo&&<img className="gt-wb-photo-preview" src={photo} alt="选择的图片"/>}'''
new='''<label className="gt-wb-photo-label">▧ 从相册选择图片<input type="file" accept="image/*" onChange={async e=>{const file=e.target.files?.[0];if(!file)return;setPhotoError("");try{const saved=await preparePlayerPhoto(file);setPhoto(saved.key);}catch(error){setPhotoError(error instanceof Error?error.message:"图片保存失败");}}}/></label>{photoError&&<p role="alert">{photoError}</p>}{photo&&<PlayerPhoto className="gt-wb-photo-preview" src={photo} alt="选择的图片"/>}'''
assert old in s
s=s.replace(old,new)
s=s.replace('{post.image&&<img className="gt-wb-post-image" src={post.image} alt="微博配图"/>}','{post.image&&<PlayerPhoto className="gt-wb-post-image" src={post.image} alt="微博配图"/>}')
s=s.replace('onClick={()=>setReplyDraft(`@${c.name} `)}>回复</button>','onClick={()=>{setReplyDraft(`@${c.name} `);setReplyParent(c.id);}}>回复</button>')
s=s.replace('  const [replyDraft,setReplyDraft]=useState("");','  const [replyDraft,setReplyDraft]=useState("");\n  const [replyParent,setReplyParent]=useState("");')
s=s.replace('reply(post);','reply(post,replyParent||undefined);setReplyParent("");')
s=s.replace('<div key={c.id}><span className="gt-wb-fan-avatar">','<div key={c.id} style={{paddingLeft:c.parentId?24:0}}><span className="gt-wb-fan-avatar">')
p.write_text(s)
print('WB modified',len(s))
