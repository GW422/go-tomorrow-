import json
from pathlib import Path
p=Path('stories/template/story.json'); d=json.loads(p.read_text()); chats={c['id']:c for c in d['chats']}
blocks={
'chele-chat':'''천러|你人呢
천러|拿外卖拿丢了？
천러|呀你不会是偷吃了吧
:|你以为我是你
:|我刚想来找你
천러|干嘛语气这么严肃
:|辰乐
:|你是不是帮我报名什么了
천러|？没有啊
천러|你报名什么了吗
:|我也不知道 我邮箱有一条邮件
:|说我报名成功什么的
:|但是我什么都没干啊 点它发我的邮件也打不开
:|提示权限不够
천러|权限不够？
천러|好奇怪啊 会不会是发错了
:|有可能
천러|或者是那种骚扰邮件 骚扰信息
천러|不是有很多这样的嘛
천러|别担心
천러|哎你还敢点链接啊？朴志晟
천러|仁俊知道得骂死你
천러|万一是病毒链接呢？
천러|都是多少年前的诈骗手段了
천러|你还上当呢
:|啊可是
천러|jeno找你了 ㅋㅋㅋ
천러|他们快要饿扁了
천러|快点上来吧我们忙内
천러|哥哥们在等你哦
:|你算什么哥哥啊
천러|呀朴志晟
천러|我哪里不算哥哥？
:|我要上楼了辰乐呀
천러|快点''',
'dream-group-chat':'''제노형|朴志晟去哪了
:|我回来了
:|人太多了ㅠ 差点没找到外卖员
제노형|少装了
:|啊哥；；；
RJ|志晟啊！！！！！
RJ|肚子饿扁了啊！！！！！
천러|他眼睛都饿绿了
해찬형|我发现我不在的时候你们会格外活跃呢^
재민형|知道就好
해찬형|呀为什么一到这种时候你又冒出来了
제노형|你值得
해찬형|呀呀呀jeno呀
제노형|ㅎㅎ
제노형|你在的时候都忙着和你玩呢
제노형|哪有时间群聊
RJ|哇
해찬형|jeno呀🥺🥺
천러|幼稚死了真是！
RJ|你最成熟了 大头他爹''',
'haechan-chat':'''해찬형|志晟哥🥺🥺🥺
해찬형|我们小志晟🥺🥺
해찬형|我们最可爱的忙内🥺😭
:|？？？？？？
해찬형|志晟啊🥺
:|不是 哥
:|你怎么了？
해찬형|我们可怜的楷灿哥哥想吃泡菜汤😭
해찬형|你满足他吧😭
:|什么意思 要吃我做的吗
해찬형|不是这个意思
해찬형|你别冲动
:|…
해찬형|今晚应该轮到bothsides做饭了
해찬형|帮我求求他们
:|哦
해찬형|谢谢志晟哥！
:|可是帮你有什么用呢 我们楷灿
해찬형|？
해찬형|哇…
해찬형|黑心忙内 仓鼠
해찬형|和哥哥们生活了这么多年
해찬형|终于露出真面目了
:|啊 ㅋㅋㅋㅋ
해찬형|别用拳场当家那种语气和我说话啊^^
:|ㅋㅋㅋㅋㅋㅋㅋ好
:|等我到宿舍问问好吗哥
해찬형|当然好啦我们透明心脏的仓鼠忙内
:|呃…
---
해찬형|怎么样了？？？
:|bothsides让你当面跪下来求他们
해찬형|？
해찬형|额
:|哥 真的绝了
:|我又因为嘲笑你肚子痛了
해찬형|你的笑点有点过于高了
:|这句也很好笑怎么办
해찬형|他们俩这叫狼狈为奸
:|？啊 嗯
해찬형|不讲道理 毫无章法
해찬형|权力垄断！
해찬형|等我回来好好理论
해찬형|这次一定要拉上辰乐帮我才行
:|好呢哥
해찬형|别想置身事外 你也帮我
해찬형|干嘛这么冷淡啊
:|又要伤心了吗？
해찬형|什么啊
해찬형|你是不是又想起梦里什么了
:|ㅎㅎㅎ 对
해찬형|给我闭嘴 不要说
:|好冤枉 我没打算说来着呢
해찬형|哦
:|但是渽民哥和帝努哥好奇怪
해찬형|哦？
:|刚刚我楼上 他们突然变得很警惕跟上来
:|我帮你问了泡菜汤的事情 他们又马上变得疏离了
:|尤其是渽民哥 ㅜㅜ
:|五天前他就这样了
해찬형|你确定是五天前吗志晟啊
:|好吧 我知道了😭
해찬형|ㅋㅋㅋㅋ
해찬형|他们是特工啊！志晟！
해찬형|情绪收放自如是基本素养！
:|好无语 哥
해찬형|ㅎㅎ他们的关系变好了
:|他们的关系一直很好啊
해찬형|我知道啊
해찬형|变得更好不行吗
:|可以
해찬형|总给人一种同一阵营的感觉
:|bothsides应该是对家才对
해찬형|志晟啊
해찬형|你也没救了
:|啊😭''',
'jaemin-chat':'''재민형|志晟啊
재민형|准备睡觉了吗？？？
:|啊哥 是呢 我准备睡了
:|刚刚看了会儿ig
:|今天决定早睡💪
재민형|哎咦
재민형|好棒
재민형|我们宝宝
:|哎呀哥
재민형|不要害羞^
:|可是 哥怎么会突然想起来
재민형|什么啊什么啊
:|突然想起来问我睡觉的事
:|终于下定决心和西珍妮统一战线了吗！
:|西珍妮天天骂我睡得晚
재민형|什么啊
재민형|我们志晟不是一般睡的挺早的嘛
:|是啊是啊我也觉得
재민형|早上就睡了 挺早的
:|啊…
재민형|ㅎㅎㅎ
재민형|久违地关心一下
재민형|不可以吗？？
:|哎没有啦哥我要睡觉了
재민형|晚安哦^^
:|晚安 哥
---
재민형|睡着了吗？'''}
mapids={'천러':'chele','제노형':'jeno','RJ':'ren','해찬형':'haechan','재민형':'jaemin'}
for cid, block in blocks.items():
 chat=chats[cid]; prev=chat['messages']; avatar={m['senderId']:m.get('avatar') for m in prev if m.get('avatar') and m.get('senderId')!='owner'}
 # use avatars from all chats
 for c in d['chats']:
  for m in c['messages']:
   if m.get('avatar') and m.get('senderId')!='owner':avatar.setdefault(m['senderId'],m['avatar'])
 stage=1; index=0
 for line in block.splitlines():
  if line=='---':stage+=1;continue
  who,body=line.split('|',1);index+=1;sender='owner' if who==':' else mapids[who];clock={'chele-chat':'13:56','dream-group-chat':'13:57','haechan-chat':'20:12' if stage==1 else '20:28','jaemin-chat':'23:29' if stage==1 else '23:59'}[cid]
  m={'id':f'gt-day1-v3-{cid}-{index:03}', 'title':chat['title'] if 'title' in chat else prev[0]['title'],'body':body,'time':f'2026-10-22 {clock}','senderId':sender,'meta':str({'scriptedDay':'true','scriptedReply':'true' if sender=='owner' else 'false','gtStage':f'{cid}-{stage}'})}
  if sender in avatar:m['avatar']=avatar[sender]
  prev.append(m)
d['revision']=3
p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
print({k:len(v['messages']) for k,v in chats.items()})
