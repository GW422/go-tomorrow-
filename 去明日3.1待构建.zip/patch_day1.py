from pathlib import Path
import json
root=Path('/mnt/data/day1_build'); story=root/'stories/template/story.json'; d=json.loads(story.read_text())
# Correct generated message metadata, and preserve all original text.
for chat in d['chats']:
 for m in chat['messages']:
  if m['id'].startswith('gt-day1-v3-'):
   import ast
   if isinstance(m['meta'],str):m['meta']=ast.literal_eval(m['meta'])
   m['meta']['scriptedDay']='true';m['meta']['scriptedReply']='true' if m['senderId']=='owner' else 'false'
   if m['body']=='啊可是':m['meta']['triggerGroup']='true'
   if m['body']=='朴志晟去哪了':m['meta']['groupTrigger']='true'
story.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
p=root/'src/vendor/mymy/Apps.tsx';t=p.read_text()
t=t.replace('    [haechanCount, setHaechanCount] = useSkinState<number>(p, "mymyHaechanCount", -1),','    [haechanCount, setHaechanCount] = useSkinState<number>(p, "mymyHaechanCount", -1),\n    [extraCursorsJson, setExtraCursorsJson] = useSkinState<string>(p, "gtExtraCursors", "{}"),')
t=t.replace('    activeVisibleCount = p.thread === "해찬형" ? haechanEffectiveCount : effectiveVisibleCount,','    extraCursors: Record<string,number> = (() => { try { return JSON.parse(extraCursorsJson); } catch { return {}; } })(),\n    extraStart = Math.max(0, sourceMessages.findIndex(i => i.id.startsWith("gt-day1-v3-"))),\n    activeVisibleCount = p.thread === "해찬형" ? haechanEffectiveCount : p.thread === "재민형" ? effectiveVisibleCount : (scriptedMode ? (extraCursors[p.thread] ?? extraStart) : sourceMessages.length),')
t=t.replace('      if (sourceMessages[haechanEffectiveCount + 1]?.meta.delayedFollowup === "true") p.onUi?.("mymyHaechanFinishedAt", Date.now());','      if (sourceMessages[haechanEffectiveCount + 1]?.meta.delayedFollowup === "true") p.onUi?.("mymyHaechanFinishedAt", Date.now());')
t=t.replace('    } else setVisibleCount(effectiveVisibleCount + 1);','    } else if (p.thread === "재민형") setVisibleCount(effectiveVisibleCount + 1);\n    else setExtraCursorsJson(JSON.stringify({...extraCursors,[p.thread]:activeVisibleCount+1}));')
t=t.replace('    } else if (p.thread === "해찬형" && readCursors[p.thread] !== haechanEffectiveCount) {','    } else if (p.thread !== "재민형" && p.thread !== "해찬형" && readCursors[p.thread] !== activeVisibleCount) {\n      setReadCursors({...readCursors, [p.thread]: activeVisibleCount});\n    } else if (p.thread === "해찬형" && readCursors[p.thread] !== haechanEffectiveCount) {')
t=t.replace('g.title === "해찬형" ? hcVisible : displayedItems.length','g.title === "해찬형" ? hcVisible : displayedItems.length')
# All scripted threads must be sliced by their own cursor; not just Jaemin/Haechan.
p.write_text(t)
# Runtime extra stage delivery; keep the original first-day delivery intact, gate v3 additions.
p=root/'src/Phone.tsx';t=p.read_text(); needle='  const event = (event: string, target: string) => {'
insert='''  // Day 1 v3 staged conversations. All cursors live in the existing Dexie save.
  const gtExtra: Record<string, number> = (() => { try { return JSON.parse(String(kakaoUi.gtExtraCursors || "{}")); } catch { return {}; } })();
  const gtThreads = ["천러", "드림💚"];
  const gtGroup = (title: string) => (work.data.kakao ?? []).filter(m => m.title === title && m.meta.placeholder !== "true");
  const gtCount = (title: string) => { const items = gtGroup(title); const start = items.findIndex(m => m.id.startsWith("gt-day1-v3-")); return gtExtra[title] ?? (start < 0 ? items.length : start); };
  const gtDone = (title: string) => gtCount(title) >= gtGroup(title).length;
  const gtStageDone = (title: string, stage: string, count: number) => {
    const items = gtGroup(title);
    const last = items.findLastIndex(m => m.meta.gtStage === stage);
    return last >= 0 && count > last;
  };
  const gtOldDone = deliveredCount >= (kakaoItems.findIndex(m => m.id.startsWith("gt-day1-v3-")) < 0 ? kakaoItems.length : kakaoItems.findIndex(m => m.id.startsWith("gt-day1-v3-"))) &&
    hcVisibleCount >= (hcItems.findIndex(m => m.id.startsWith("gt-day1-v3-")) < 0 ? hcItems.length : hcItems.findIndex(m => m.id.startsWith("gt-day1-v3-")));
  const gtMailOpened = Boolean(s.ui?.mail?.gtOpened);
  const gtInstagramOpened = Boolean(s.ui?.instagram?.gtOpened || s.ui?.ins?.gtOpened);
  const gtClock = String(kakaoUi.gtClock || "");
  useEffect(() => {
    if (creator || !ready || locked) return;
    let target = "";
    if (gtOldDone && !gtClock) target = "13:56";
    else if (gtStageDone("천러", "chele-chat-1", gtCount("천러")) && gtDone("드림💚") && gtInstagramOpened && gtClock === "13:56") target = "20:12";
    else if (gtStageDone("해찬형", "haechan-chat-1", hcVisibleCount) && gtClock === "20:12") target = "20:28";
    else if (gtStageDone("해찬형", "haechan-chat-2", hcVisibleCount) && gtClock === "20:28") target = "23:29";
    else if (gtStageDone("재민형", "jaemin-chat-1", deliveredCount) && gtClock === "23:29") target = "23:59";
    if (!target) return;
    const current = runtimeRef.current;
    update({...current,time:target,ui:{...current.ui,kakao:{...current.ui?.kakao,gtClock:target}}});
  }, [creator,ready,locked,gtOldDone,gtClock,gtInstagramOpened,hcVisibleCount,deliveredCount,JSON.stringify(gtExtra)]);
  useEffect(() => {
    if (creator || !ready || locked || !gtClock) return;
    for (const title of gtThreads) {
      const items = gtGroup(title), cursor = gtCount(title), next = items[cursor];
      if (!next || next.meta.scriptedReply === "true") continue;
      if (title === "천러" && (!gtMailOpened || gtClock !== "13:56" && !gtDone("천러"))) continue;
      if (title === "드림💚" && next.meta.groupTrigger === "true" && !kakaoUi.gtGroupTriggered) continue;
      if (title === "드림💚" && next.meta.groupTrigger !== "true" && !kakaoUi.gtGroupTriggered) continue;
      const timer = window.setTimeout(() => {
        const current = runtimeRef.current, ui = current.ui?.kakao ?? {};
        let cursors:Record<string,number> = {};try { cursors=JSON.parse(String(ui.gtExtraCursors || "{}")); } catch { /* old save */ }
        if ((cursors[title] ?? items.findIndex(m=>m.id.startsWith("gt-day1-v3-"))) !== cursor) return;
        update({...current,ui:{...current.ui,kakao:{...ui,gtExtraCursors:JSON.stringify({...cursors,[title]:cursor+1})}}});
        if (!document.querySelector(`.mymy-kakao .msgs[data-thread="${title}"]`) && work.phone.notifications) enqueueBanner(`KakaoTalk：${title}：${next.body}`);
      },next.meta.groupTrigger === "true" ? 500 : 1400);
      return () => window.clearTimeout(timer);
    }
  },[creator,ready,locked,gtClock,gtMailOpened,kakaoUi.gtGroupTriggered,JSON.stringify(gtExtra)]);
  useEffect(() => {
    if (creator || !ready || !gtClock) return;
    const incoming = kakaoItems[deliveredCount];
    const hcIncoming = hcItems[hcVisibleCount];
    // Existing delivery effects are paused at v3 boundaries until the required clock stage.
    if (incoming?.id.startsWith("gt-day1-v3-") && incoming.meta.gtStage === "jaemin-chat-1" && gtClock !== "23:29") return;
    if (hcIncoming?.id.startsWith("gt-day1-v3-") && hcIncoming.meta.gtStage === "haechan-chat-1" && gtClock !== "20:12") return;
  },[creator,ready,gtClock,deliveredCount,hcVisibleCount]);
  useEffect(() => {
    if (creator || !ready || !gtClock) return;
    const last = gtGroup("천러").slice(0,gtCount("천러")).at(-1);
    if (last?.meta.triggerGroup === "true" && !kakaoUi.gtGroupTriggered) {
      const current=runtimeRef.current;
      update({...current,ui:{...current.ui,kakao:{...current.ui?.kakao,gtGroupTriggered:true}}});
    }
  },[creator,ready,gtClock,JSON.stringify(gtExtra),kakaoUi.gtGroupTriggered]);
'''
t=t.replace(needle,insert+needle)
# Prevent original effects from delivering v3 before their respective stage.
t=t.replace('    if (!next || next.meta.scriptedDay !== "true" || next.meta.scriptedReply === "true") return;','    if (!next || next.meta.scriptedDay !== "true" || next.meta.scriptedReply === "true") return;\n    if (next.id.startsWith("gt-day1-v3-") && (next.meta.gtStage === "jaemin-chat-1" ? gtClock !== "23:29" : gtClock !== "23:59")) return;',1)
pos=t.find('    if (!next || next.meta.scriptedDay !== "true" || next.meta.scriptedReply === "true") return;',t.find('// Haechan uses'))
t=t[:pos]+t[pos:].replace('    if (!next || next.meta.scriptedDay !== "true" || next.meta.scriptedReply === "true") return;','    if (!next || next.meta.scriptedDay !== "true" || next.meta.scriptedReply === "true") return;\n    if (next.id.startsWith("gt-day1-v3-") && (next.meta.gtStage === "haechan-chat-1" ? gtClock !== "20:12" : gtClock !== "20:28")) return;',1)
# Add app opened flags.
t=t.replace('    event("openApp", id);','    event("openApp", id);\n    if (["mail","instagram","ins","x"].includes(id)) {\n      const current=runtimeRef.current;update({...current,ui:{...current.ui,[id]:{...current.ui?.[id],gtOpened:true}}});\n    }')
p.write_text(t)
